import Foundation
import NetworkExtension
import Combine

@MainActor
final class TunnelManager: ObservableObject {
    @Published private(set) var state: VPNConnectionState = .unavailable
    @Published private(set) var statusMessage = "正在读取系统 VPN 状态"
    private var manager: NETunnelProviderManager?
    nonisolated(unsafe) private var statusObserver: NSObjectProtocol?
    private var connectionAttempted = false
    private var connectedDuringAttempt = false
    private var failureLookupTask: Task<Void, Never>?
    private let reloadGate = TunnelReloadGate()

    var isConfigured: Bool { manager != nil }

    init() {
        statusObserver = NotificationCenter.default.addObserver(
            forName: .NEVPNStatusDidChange,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.refreshState() }
        }
    }

    deinit {
        if let statusObserver { NotificationCenter.default.removeObserver(statusObserver) }
    }

    func load() async {
        do {
            manager = try await TunnelPreferences.loadManagers().first
            refreshState()
        } catch {
            state = .unavailable
            statusMessage = Redactor.clean(error.localizedDescription)
        }
    }

    func toggle(runtimeConfiguration: String) async throws {
        switch state {
        case .connected, .connecting, .reasserting:
            manager?.connection.stopVPNTunnel()
        case .disconnecting:
            return
        case .disconnected, .invalid, .unavailable:
            let manager = try await prepareManager()
            failureLookupTask?.cancel()
            failureLookupTask = nil
            TunnelFailureReader.clear()
            connectionAttempted = true
            connectedDuringAttempt = false
            do {
                try manager.connection.startVPNTunnel(
                    options: TunnelPayloadCodec.startOptions(runtimeConfiguration: runtimeConfiguration)
                )
            } catch {
                connectionAttempted = false
                statusMessage = "连接失败：\(SensitiveTextRedactor.failureMessage(error))"
                throw error
            }
        }
        refreshState()
    }

    func reload(runtimeConfiguration: String) async throws {
        await reloadGate.acquire()
        do {
            try Task.checkCancellation()
            try await reloadUnlocked(runtimeConfiguration: runtimeConfiguration)
            await reloadGate.release()
        } catch {
            await reloadGate.release()
            throw error
        }
    }

    private func reloadUnlocked(runtimeConfiguration: String) async throws {
        let session = try await reloadSessionWhenReady()
        let payload = try TunnelPayloadCodec.encode(runtimeConfiguration: runtimeConfiguration)
        let response = try await TunnelPreferences.send(payload, through: session)
        if let response, !response.isEmpty {
            let message = String(data: response, encoding: .utf8) ?? "隧道拒绝了新配置"
            throw TunnelManagerError.extensionRejected(Redactor.clean(message))
        }
    }

    private func reloadSessionWhenReady() async throws -> NETunnelProviderSession {
        for attempt in 0..<50 {
            try Task.checkCancellation()
            guard let session = manager?.connection as? NETunnelProviderSession else {
                throw TunnelManagerError.notConnected
            }
            switch session.status {
            case .connected:
                return session
            case .connecting, .reasserting:
                if attempt == 49 { throw TunnelManagerError.notConnected }
                try await Task.sleep(nanoseconds: 100_000_000)
            default:
                throw TunnelManagerError.notConnected
            }
        }
        throw TunnelManagerError.notConnected
    }

    private func prepareManager() async throws -> NETunnelProviderManager {
        let current = manager ?? NETunnelProviderManager()
        let tunnelProtocol: NETunnelProviderProtocol
        if let existing = current.protocolConfiguration as? NETunnelProviderProtocol {
            tunnelProtocol = existing
        } else {
            tunnelProtocol = NETunnelProviderProtocol()
        }
        tunnelProtocol.providerBundleIdentifier = AppConfiguration.tunnelBundleIdentifier
        tunnelProtocol.serverAddress = "SwiftGate 本机隧道"
        tunnelProtocol.includeAllNetworks = false
        // Route everything through the packet tunnel first. Private destinations are sent
        // DIRECT by the runtime rules, while the tunnel's synthetic DNS address must remain
        // reachable inside NetworkExtension instead of being excluded by the OS beforehand.
        tunnelProtocol.excludeLocalNetworks = false
        current.protocolConfiguration = tunnelProtocol
        current.localizedDescription = "SwiftGate"
        current.isEnabled = true
        try await TunnelPreferences.save(current)
        try await TunnelPreferences.reload(current)
        manager = current
        return current
    }

    private func refreshState() {
        guard let manager else {
            state = .disconnected
            statusMessage = "首次连接时会请求添加 VPN 配置"
            return
        }
        state = VPNConnectionState(manager.connection.status)
        if state == .connected {
            connectedDuringAttempt = true
            statusMessage = state.title
            return
        }
        if state == .disconnected, connectionAttempted {
            if connectedDuringAttempt {
                statusMessage = "连接已断开"
            } else if let failure = TunnelFailureReader.read() {
                statusMessage = "连接失败：\(failure)"
            } else {
                statusMessage = "连接失败：Packet Tunnel 未返回启动错误"
                fetchSystemDisconnectFailure(from: manager.connection)
            }
            connectionAttempted = false
            return
        }
        statusMessage = state.title
    }

    private func fetchSystemDisconnectFailure(from connection: NEVPNConnection) {
        guard #available(iOS 16.0, *) else {
            statusMessage = "连接失败：Packet Tunnel 启动后立即退出；iOS 15 无法读取系统断开原因，请检查扩展权限与核心兼容性"
            return
        }

        failureLookupTask?.cancel()
        failureLookupTask = Task { [weak self] in
            do {
                try await connection.fetchLastDisconnectError()
            } catch {
                guard !Task.isCancelled,
                      let self,
                      self.state == .disconnected,
                      !self.connectionAttempted
                else { return }
                self.statusMessage = "连接失败：\(SensitiveTextRedactor.failureMessage(error))"
            }
        }
    }
}

private actor TunnelReloadGate {
    private var busy = false
    private var waiters: [CheckedContinuation<Void, Never>] = []

    func acquire() async {
        if !busy {
            busy = true
            return
        }
        await withCheckedContinuation { continuation in
            waiters.append(continuation)
        }
    }

    func release() {
        if waiters.isEmpty {
            busy = false
        } else {
            waiters.removeFirst().resume()
        }
    }
}

private enum TunnelFailureReader {
    private static let fileName = "tunnel-last-error.txt"

    private static var fileURL: URL? {
        AppConfiguration.sharedContainerURL?.appendingPathComponent(fileName)
    }

    static func clear() {
        guard let fileURL else { return }
        try? FileManager.default.removeItem(at: fileURL)
    }

    static func read() -> String? {
        guard let fileURL else { return nil }
        defer { try? FileManager.default.removeItem(at: fileURL) }
        guard
            let data = try? Data(contentsOf: fileURL),
            let value = String(data: data, encoding: .utf8)
        else { return nil }
        let cleaned = Redactor.clean(value).trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? nil : String(cleaned.prefix(1_000))
    }
}

enum TunnelManagerError: LocalizedError {
    case notConnected
    case providerMessageTimeout
    case extensionRejected(String)

    var errorDescription: String? {
        switch self {
        case .notConnected: "VPN 尚未连接"
        case .providerMessageTimeout: "VPN 扩展未在 12 秒内响应配置更新，请断开后重新连接"
        case .extensionRejected(let message): message
        }
    }
}

private final class ProviderMessageAttempt: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Data?, Error>?
    private var terminalResult: Result<Data?, Error>?

    /// Returns false when cancellation or another terminal event won the race
    /// before the continuation was installed. In that case this method resumes it.
    @discardableResult
    func install(_ continuation: CheckedContinuation<Data?, Error>) -> Bool {
        lock.lock()
        if let terminalResult {
            lock.unlock()
            continuation.resume(with: terminalResult)
            return false
        }
        self.continuation = continuation
        lock.unlock()
        return true
    }

    /// Completes the operation exactly once. Later provider callbacks and timeout
    /// events are ignored, preventing a checked continuation from being resumed twice.
    @discardableResult
    func finish(_ result: Result<Data?, Error>) -> Bool {
        lock.lock()
        guard terminalResult == nil else {
            lock.unlock()
            return false
        }
        terminalResult = result
        let continuation = continuation
        self.continuation = nil
        lock.unlock()
        continuation?.resume(with: result)
        return true
    }
}

private enum TunnelPreferences {
    static func loadManagers() async throws -> [NETunnelProviderManager] {
        try await withCheckedThrowingContinuation { continuation in
            NETunnelProviderManager.loadAllFromPreferences { managers, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: managers ?? []) }
            }
        }
    }

    static func save(_ manager: NETunnelProviderManager) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            manager.saveToPreferences { error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume() }
            }
        }
    }

    static func reload(_ manager: NETunnelProviderManager) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            manager.loadFromPreferences { error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume() }
            }
        }
    }

    static func send(_ data: Data, through session: NETunnelProviderSession) async throws -> Data? {
        let attempt = ProviderMessageAttempt()
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Data?, Error>) in
                guard attempt.install(continuation) else { return }

                if Task.isCancelled {
                    _ = attempt.finish(.failure(CancellationError()))
                    return
                }

                DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 12) {
                    _ = attempt.finish(.failure(TunnelManagerError.providerMessageTimeout))
                }

                do {
                    try session.sendProviderMessage(data) { response in
                        _ = attempt.finish(.success(response))
                    }
                } catch {
                    _ = attempt.finish(.failure(error))
                }
            }
        } onCancel: {
            _ = attempt.finish(.failure(CancellationError()))
        }
    }
}
