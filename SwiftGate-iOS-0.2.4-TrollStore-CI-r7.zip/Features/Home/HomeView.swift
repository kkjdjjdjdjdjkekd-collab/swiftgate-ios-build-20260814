import SwiftUI

@MainActor
struct HomeView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                connectionStatusCard
                nodeCard
                routingCard
            }
            .padding(SwiftGateTheme.pagePadding)
            .padding(.bottom, 96)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("SwiftGate")
        .safeAreaInset(edge: .bottom) {
            connectionAction
        }
    }

    private var connectionStatusCard: some View {
        SurfaceCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 12) {
                    Image(systemName: model.connectionState.statusSymbol)
                        .font(.title2)
                        .foregroundStyle(effectiveStatusColor)
                        .accessibilityHidden(true)

                    VStack(alignment: .leading, spacing: 3) {
                        Text(model.connectionStatusText)
                            .font(.title3.weight(.semibold))
                        Text(connectionDetailText)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }

                HStack(spacing: 8) {
                    Circle()
                        .fill(effectiveStatusColor)
                        .frame(width: 8, height: 8)
                        .accessibilityHidden(true)
                    Text(networkProtectionText)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .accessibilityElement(children: .combine)
    }

    private var nodeCard: some View {
        SurfaceCard {
            VStack(alignment: .leading, spacing: 12) {
                Label("节点", systemImage: "server.rack")
                    .font(.headline)

                KeyValueRow("当前连接") {
                    Text(model.currentNode?.name ?? "无")
                        .foregroundStyle(model.currentNode == nil ? .secondary : .primary)
                        .multilineTextAlignment(.trailing)
                }

                Divider()

                KeyValueRow("下次连接") {
                    Text(model.preferredNode?.name ?? "尚未选择")
                        .foregroundStyle(model.preferredNode == nil ? .secondary : .primary)
                        .multilineTextAlignment(.trailing)
                }

                if model.preferredNode == nil {
                    Label("请到“节点”页选择一个节点", systemImage: "arrow.down.circle")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var routingCard: some View {
        SurfaceCard {
            VStack(alignment: .leading, spacing: 12) {
                Label("路由模式", systemImage: "arrow.triangle.branch")
                    .font(.headline)

                Picker("路由模式", selection: routingModeBinding) {
                    ForEach(RoutingMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }
                .pickerStyle(.segmented)

                Text(routingDescription)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var connectionAction: some View {
        Button {
            Task { await model.toggleConnection() }
        } label: {
            HStack(spacing: 10) {
                if model.connectionState.isBusy {
                    ProgressView()
                        .tint(.white)
                } else {
                    Image(systemName: model.connectionState == .connected ? "stop.fill" : "power")
                }
                Text(model.connectionState.connectionActionTitle)
                    .fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity, minHeight: 52)
        }
        .buttonStyle(.borderedProminent)
        .buttonBorderShape(.roundedRectangle(radius: 16))
        .disabled(!isConnectionActionEnabled)
        .padding(.horizontal, SwiftGateTheme.pagePadding)
        .padding(.vertical, 10)
        .background(.bar)
        .accessibilityHint(model.connectionState == .connected ? "停止系统 VPN" : "使用所选节点启动系统 VPN")
    }

    private var isConnectionActionEnabled: Bool {
        guard model.connectionState.canToggleConnection else { return false }
        guard model.connectionState == .disconnected else { return true }
        if model.settings.routingMode == .direct {
            return true
        }
        return model.preferredNode != nil
    }

    private var routingModeBinding: Binding<RoutingMode> {
        Binding(
            get: { model.settings.routingMode },
            set: { model.setRoutingMode($0) }
        )
    }

    private var connectionDetailText: String {
        switch model.connectionState {
        case .connected:
            return model.currentNode?.name ?? "VPN 已连接"
        case .connecting:
            return model.preferredNode.map { "正在连接 \($0.name)" } ?? "正在准备隧道"
        case .reasserting:
            return "网络变化，正在恢复连接"
        case .disconnecting:
            return "正在安全关闭隧道"
        case .invalid:
            return "请先导入并选择可用节点"
        case .unavailable:
            return "请检查 VPN 权限与系统设置"
        case .disconnected:
            return model.preferredNode.map { "已选择 \($0.name)" } ?? "选择节点后即可连接"
        }
    }

    private var routingDescription: String {
        switch model.settings.routingMode {
        case .rule:
            return "按规则智能分流，日常使用推荐。"
        case .global:
            return "除本地网络外，所有流量都通过所选节点。"
        case .direct:
            return "所有流量直接访问，不经过节点。"
        }
    }

    private var effectiveStatusColor: Color {
        guard model.connectionState == .connected else {
            return model.connectionState.statusColor
        }
        switch model.tunnelNetworkAvailable {
        case .some(true): return .green
        case .some(false): return .red
        case .none: return .orange
        }
    }

    private var networkProtectionText: String {
        guard model.connectionState == .connected else {
            return "未连接时仍可选择和测试节点"
        }
        switch model.tunnelNetworkAvailable {
        case .some(true): return "实际网络已验证，系统 VPN 正在保护流量"
        case .some(false): return "隧道已建立，但实际网络检查失败"
        case .none: return "正在检查 DNS 和网页流量"
        }
    }
}
