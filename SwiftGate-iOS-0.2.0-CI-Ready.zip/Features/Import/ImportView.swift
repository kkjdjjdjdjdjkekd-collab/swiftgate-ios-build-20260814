import SwiftUI
import UniformTypeIdentifiers
import UIKit

@MainActor
struct ImportView: View {
    @Environment(AppModel.self) private var model
    @FocusState private var isEditorFocused: Bool
    @State private var isFileImporterPresented = false
    @State private var isImporting = false

    var body: some View {
        Form {
            Section {
                TextEditor(text: importTextBinding)
                    .frame(minHeight: 150)
                    .focused($isEditorFocused)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .font(.body.monospaced())
                    .accessibilityLabel("分享链接或订阅地址")

                HStack {
                    Button {
                        pasteFromClipboard()
                    } label: {
                        Label("粘贴", systemImage: "doc.on.clipboard")
                            .frame(minHeight: SwiftGateTheme.minimumTapHeight)
                    }

                    Spacer()

                    Button(role: .destructive) {
                        model.importText = ""
                    } label: {
                        Label("清空", systemImage: "trash")
                            .frame(minHeight: SwiftGateTheme.minimumTapHeight)
                    }
                    .disabled(model.importText.isEmpty)
                }
            } header: {
                Text("从文本导入")
            } footer: {
                Text("支持 Clash/Mihomo YAML、订阅 URL，以及 VLESS、VMess、Trojan、Shadowsocks、Hysteria 2、TUIC 分享链接。")
            }

            Section {
                Button {
                    importFromText()
                } label: {
                    HStack {
                        Label("导入文本内容", systemImage: "square.and.arrow.down")
                        Spacer()
                        if isImporting {
                            ProgressView()
                        }
                    }
                    .frame(minHeight: SwiftGateTheme.minimumTapHeight)
                }
                .disabled(!canImportText || isImporting)

                Button {
                    isFileImporterPresented = true
                } label: {
                    Label("选择配置文件", systemImage: "folder")
                        .frame(minHeight: SwiftGateTheme.minimumTapHeight)
                }
                .disabled(isImporting)
            }

            if model.hasSavedSubscription {
                Section("已保存的订阅") {
                    Button {
                        Task { await model.updateSubscription() }
                    } label: {
                        HStack {
                            Label("立即更新订阅", systemImage: "arrow.clockwise")
                            Spacer()
                            if model.isUpdatingSubscription { ProgressView() }
                        }
                        .frame(minHeight: SwiftGateTheme.minimumTapHeight)
                    }
                    .disabled(model.isUpdatingSubscription || isImporting)
                } footer: {
                    Text("更新失败时继续使用上一份有效配置。")
                }
            }

            if let summary = model.importSummary, !summary.isEmpty {
                Section("最近一次导入") {
                    Label(summary, systemImage: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                        .accessibilityElement(children: .combine)
                }
            }

            Section("安全提示") {
                Label("订阅地址与认证信息只保存在本机安全存储中。", systemImage: "lock.shield")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("导入")
        .scrollDismissesKeyboard(.interactively)
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("完成") {
                    isEditorFocused = false
                }
            }
        }
        .fileImporter(
            isPresented: $isFileImporterPresented,
            allowedContentTypes: [.plainText, .json, .data],
            allowsMultipleSelection: false
        ) { result in
            guard case .success(let urls) = result, let url = urls.first else { return }
            importFile(url)
        }
    }

    private var importTextBinding: Binding<String> {
        Binding(
            get: { model.importText },
            set: { model.importText = $0 }
        )
    }

    private var canImportText: Bool {
        !model.importText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    private func pasteFromClipboard() {
        guard let text = UIPasteboard.general.string, !text.isEmpty else { return }
        model.importText = text
    }

    private func importFromText() {
        guard canImportText, !isImporting else { return }
        isEditorFocused = false
        isImporting = true
        Task {
            await model.importTextContent()
            isImporting = false
        }
    }

    private func importFile(_ url: URL) {
        guard !isImporting else { return }
        isImporting = true
        Task {
            let didAccess = url.startAccessingSecurityScopedResource()
            await model.importFile(url)
            if didAccess {
                url.stopAccessingSecurityScopedResource()
            }
            isImporting = false
        }
    }
}
