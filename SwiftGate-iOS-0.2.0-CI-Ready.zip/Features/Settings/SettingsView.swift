import SwiftUI

@MainActor
struct SettingsView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        Form {
            Section("连接") {
                Picker("默认路由模式", selection: routingModeBinding) {
                    ForEach(RoutingMode.allCases) { mode in
                        Text(mode.title).tag(mode)
                    }
                }

                Toggle("节点故障时自动切换", isOn: autoSwitchBinding)

                if model.settings.autoSwitchEnabled {
                    Text("只有当前节点连续失败后才会切换，避免频繁跳节点。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }

            Section("订阅") {
                Picker("自动更新时间", selection: updateIntervalBinding) {
                    Text("每 6 小时").tag(6)
                    Text("每 12 小时").tag(12)
                    Text("每 24 小时").tag(24)
                }
            } footer: {
                Text("App 在前台时按所选周期检查；新配置验证失败会继续使用上一份有效配置。")
            }

            Section("状态") {
                LabeledContent("VPN") {
                    Label(model.connectionStatusText, systemImage: model.connectionState.statusSymbol)
                        .foregroundStyle(model.connectionState.statusColor)
                }

                LabeledContent("已导入节点") {
                    Text("\(model.nodes.count) 个")
                }

                LabeledContent("当前选择") {
                    Text(model.preferredNode?.name ?? "无")
                        .foregroundStyle(model.preferredNode == nil ? .secondary : .primary)
                        .lineLimit(1)
                }
            }

            Section("工具") {
                NavigationLink {
                    DiagnosticsView()
                } label: {
                    Label("一键诊断", systemImage: "stethoscope")
                        .frame(minHeight: SwiftGateTheme.minimumTapHeight)
                }

                NavigationLink {
                    LicensesView()
                } label: {
                    Label("第三方许可", systemImage: "doc.text")
                        .frame(minHeight: SwiftGateTheme.minimumTapHeight)
                }
            }

            Section("隐私与安全") {
                Label("订阅地址和凭据使用系统安全存储。", systemImage: "lock.shield")
                Label("诊断信息导出前会自动脱敏。", systemImage: "eye.slash")
            }
            .font(.subheadline)
            .foregroundStyle(.secondary)

            Section {
                VStack(alignment: .leading, spacing: 4) {
                    Text("SwiftGate for iPhone")
                        .font(.subheadline.weight(.medium))
                    Text("仅用于你有权访问的网络与合法用途")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 4)
                .accessibilityElement(children: .combine)
            }
        }
        .navigationTitle("设置")
    }

    private var routingModeBinding: Binding<RoutingMode> {
        Binding(
            get: { model.settings.routingMode },
            set: { model.setRoutingMode($0) }
        )
    }

    private var autoSwitchBinding: Binding<Bool> {
        Binding(
            get: { model.settings.autoSwitchEnabled },
            set: { model.setAutoSwitchEnabled($0) }
        )
    }

    private var updateIntervalBinding: Binding<Int> {
        Binding(
            get: { model.settings.updateIntervalHours },
            set: { model.setUpdateInterval($0) }
        )
    }
}
