import SwiftUI

@MainActor
struct NodesView: View {
    @Environment(AppModel.self) private var model
    @State private var testingNodeIDs: Set<UUID> = []
    @State private var isTestingAll = false
    @State private var searchText = ""

    var body: some View {
        let preferredNodeID = model.settings.preferredNodeID
        let currentNodeID = model.currentNode?.id
        Group {
            if model.nodes.isEmpty {
                EmptyStateView(
                    icon: "server.rack",
                    title: "还没有节点",
                    message: "请先从“导入”页添加分享链接或配置文件。"
                )
            } else {
                List {
                    Section {
                        selectionSummary
                    }

                    Section("可用节点") {
                        ForEach(filteredNodes) { node in
                            NodeRow(
                                node: node,
                                isPreferred: preferredNodeID == node.id,
                                isCurrent: currentNodeID == node.id,
                                isTesting: testingNodeIDs.contains(node.id),
                                onSelect: { select(node) },
                                onTest: { test(node) }
                            )
                        }
                    } footer: {
                        Text("无需先连接：选择会用于下次连接，测速只检查节点的网络延迟。")
                    }
                }
                .listStyle(.insetGrouped)
                .searchable(text: $searchText, prompt: "搜索节点")
                .refreshable {
                    await testAll()
                }
            }
        }
        .navigationTitle("节点")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    Task { await testAll() }
                } label: {
                    if isTestingAll {
                        ProgressView()
                    } else {
                        Label("全部测速", systemImage: "speedometer")
                    }
                }
                .disabled(model.nodes.isEmpty || isTestingAll)
                .accessibilityLabel(isTestingAll ? "正在测试全部节点" : "测试全部节点")
            }
        }
    }

    private var selectionSummary: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("下次连接")
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(model.preferredNode?.name ?? "尚未选择")
                .font(.headline)
                .foregroundStyle(model.preferredNode == nil ? .secondary : .primary)
            if model.connectionState == .connected, let current = model.currentNode {
                Label("当前连接：\(current.name)", systemImage: "checkmark.shield.fill")
                    .font(.footnote)
                    .foregroundStyle(.green)
            } else {
                Text("点击节点即可选择，不需要先连接。")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .combine)
    }

    private var filteredNodes: [ProxyNode] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return model.nodes }
        return model.nodes.filter { node in
            node.name.localizedCaseInsensitiveContains(query)
                || node.server.localizedCaseInsensitiveContains(query)
                || node.protocolTitle.localizedCaseInsensitiveContains(query)
        }
    }

    private func select(_ node: ProxyNode) {
        Task {
            await model.selectNode(node)
        }
    }

    private func test(_ node: ProxyNode) {
        guard !testingNodeIDs.contains(node.id) else { return }
        testingNodeIDs.insert(node.id)
        Task {
            await model.testLatency(node)
            testingNodeIDs.remove(node.id)
        }
    }

    private func testAll() async {
        guard !isTestingAll else { return }
        isTestingAll = true
        await model.testAllLatencies()
        isTestingAll = false
    }
}

private struct NodeRow: View {
    let node: ProxyNode
    let isPreferred: Bool
    let isCurrent: Bool
    let isTesting: Bool
    let onSelect: () -> Void
    let onTest: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Button(action: onSelect) {
                HStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(isPreferred ? SwiftGateTheme.tint.opacity(0.15) : Color.secondary.opacity(0.1))
                        Image(systemName: isPreferred ? "checkmark" : "network")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(isPreferred ? SwiftGateTheme.tint : .secondary)
                    }
                    .frame(width: 36, height: 36)
                    .accessibilityHidden(true)

                    VStack(alignment: .leading, spacing: 5) {
                        HStack(spacing: 6) {
                            Text(node.name)
                                .font(.body.weight(.medium))
                                .lineLimit(1)
                            if isCurrent {
                                BadgeView(text: "当前", tint: .green)
                            } else if isPreferred {
                                BadgeView(text: "已选")
                            }
                        }

                        Text("\(node.protocolTitle) · \(node.endpointSummary)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                            .privacySensitive()
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(minHeight: SwiftGateTheme.minimumTapHeight)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("\(node.name)，\(node.protocolTitle)\(isPreferred ? "，已选择" : "")")
            .accessibilityHint("选择为下次连接节点")

            Button(action: onTest) {
                Group {
                    if isTesting {
                        ProgressView()
                    } else {
                        Text(node.latencyText)
                            .font(.subheadline.monospacedDigit().weight(.medium))
                            .foregroundStyle(latencyColor)
                    }
                }
                .frame(minWidth: 60, minHeight: SwiftGateTheme.minimumTapHeight)
                .contentShape(Rectangle())
            }
            .buttonStyle(.borderless)
            .disabled(isTesting)
            .accessibilityLabel(isTesting ? "正在测试 \(node.name)" : "测试 \(node.name) 延迟，当前\(node.latencyText)")
        }
        .padding(.vertical, 4)
    }

    private var latencyColor: Color {
        guard let latency = node.tcpLatencyMilliseconds else { return SwiftGateTheme.tint }
        switch latency {
        case ..<150: return .green
        case ..<350: return .orange
        default: return .red
        }
    }
}
