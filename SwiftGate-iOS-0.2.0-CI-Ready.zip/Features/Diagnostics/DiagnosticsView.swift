import SwiftUI

@MainActor
struct DiagnosticsView: View {
    @Environment(AppModel.self) private var model
    @State private var isRunning = false

    var body: some View {
        List {
            Section {
                Button {
                    runDiagnostics()
                } label: {
                    HStack {
                        Label(isRunning ? "正在检查…" : "开始诊断", systemImage: "stethoscope")
                        Spacer()
                        if isRunning {
                            ProgressView()
                        }
                    }
                    .frame(minHeight: SwiftGateTheme.minimumTapHeight)
                }
                .disabled(isRunning)

                if let url = model.diagnosticExportURL, !isRunning {
                    ShareLink(item: url) {
                        Label("导出脱敏诊断包", systemImage: "square.and.arrow.up")
                            .frame(minHeight: SwiftGateTheme.minimumTapHeight)
                    }
                }
            } footer: {
                Text("会检查 VPN 配置、系统状态、DNS、节点握手与测试网址，不会导出完整凭据或订阅地址。")
            }

            if model.diagnosticItems.isEmpty {
                Section {
                    EmptyStateView(
                        icon: "checklist",
                        title: "尚未运行诊断",
                        message: "遇到无法连接或速度异常时，可以从这里开始检查。"
                    )
                    .listRowBackground(Color.clear)
                }
            } else {
                Section("检查结果") {
                    ForEach(model.diagnosticItems) { item in
                        DiagnosticRow(item: item)
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle("一键诊断")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func runDiagnostics() {
        guard !isRunning else { return }
        isRunning = true
        Task {
            await model.runDiagnostics()
            isRunning = false
        }
    }
}

private struct DiagnosticRow: View {
    let item: DiagnosticItem

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: item.passed ? "checkmark.circle.fill" : "xmark.circle.fill")
                .font(.title3)
                .foregroundStyle(item.passed ? .green : .red)
                .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 4) {
                Text(item.name)
                    .font(.body.weight(.medium))
                Text(item.message)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .privacySensitive()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.vertical, 5)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(item.name)，\(item.passed ? "通过" : "未通过")，\(item.message)")
    }
}
