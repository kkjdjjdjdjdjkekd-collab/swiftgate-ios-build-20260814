import Foundation
import Observation

@MainActor
@Observable
final class AppModel {
    private let store: AtomicConfigurationStore
    private let tunnel: TunnelManager
    private let importService: ImportService
    private let latency: LatencyService
    private let runtimeBuilder: RuntimeConfigBuilder
    private let keychain: KeychainStore
    private let diagnostics: DiagnosticService

    private var initialized = false
    private var settingsRevision = 0
    private var healthTask: Task<Void, Never>?
    private var subscriptionTask: Task<Void, Never>?
    private var consecutiveHealthFailures = 0

    var nodes: [ProxyNode] = []
    var settings = AppSettings()
    var importText = ""
    var importSummary: String?
    var diagnosticItems: [DiagnosticItem] = []
    var diagnosticExportURL: URL?
    var notice: String?
    private(set) var isUpdatingSubscription = false

    var connectionState: VPNConnectionState { tunnel.state }
    var connectionStatusText: String { tunnel.statusMessage }
    var hasSavedSubscription: Bool { settings.subscriptionURLKey != nil }

    var preferredNode: ProxyNode? {
        guard let id = settings.preferredNodeID else { return nil }
        return nodes.first(where: { $0.id == id })
    }

    var currentNode: ProxyNode? {
        switch connectionState {
        case .connected, .reasserting: preferredNode
        default: nil
        }
    }

    init(
        store: AtomicConfigurationStore? = nil,
        tunnel: TunnelManager = TunnelManager(),
        importService: ImportService = ImportService(),
        latency: LatencyService = LatencyService(),
        runtimeBuilder: RuntimeConfigBuilder = RuntimeConfigBuilder(),
        keychain: KeychainStore = KeychainStore(),
        diagnostics: DiagnosticService = DiagnosticService()
    ) {
        self.store = store ?? AtomicConfigurationStore()
        self.tunnel = tunnel
        self.importService = importService
        self.latency = latency
        self.runtimeBuilder = runtimeBuilder
        self.keychain = keychain
        self.diagnostics = diagnostics
    }

    func initialize() async {
        guard !initialized else { return }
        initialized = true
        do {
            var configuration = try await store.load()
            if let id = configuration.settings.preferredNodeID,
               !configuration.nodes.contains(where: { $0.id == id }) {
                configuration.settings.preferredNodeID = configuration.nodes.first?.id
                configuration.updatedAt = Date()
                try await store.save(configuration)
            } else if configuration.settings.preferredNodeID == nil,
                      let first = configuration.nodes.first {
                configuration.settings.preferredNodeID = first.id
                configuration.updatedAt = Date()
                try await store.save(configuration)
            }
            nodes = configuration.nodes
            settings = configuration.settings
        } catch {
            notice = "读取配置失败：\(Redactor.clean(error.localizedDescription))"
        }
        await tunnel.load()
        restartHealthMonitor()
        restartSubscriptionMonitor()
    }

    func toggleConnection() async {
        do {
            switch connectionState {
            case .connected, .connecting, .reasserting:
                try await tunnel.toggle(runtimeConfiguration: "{}")
            case .disconnecting:
                return
            case .disconnected, .invalid, .unavailable:
                let runtime = try runtimeBuilder.build(snapshot())
                try await tunnel.toggle(runtimeConfiguration: runtime)
            }
        } catch {
            notice = "连接失败：\(Redactor.clean(error.localizedDescription))"
        }
    }

    func selectNode(_ node: ProxyNode) async {
        guard nodes.contains(where: { $0.id == node.id }) else {
            notice = "该节点已不在当前配置中"
            return
        }
        let previous = snapshot()
        var candidate = previous
        candidate.settings.preferredNodeID = node.id
        candidate.updatedAt = Date()

        do {
            let runtime = try runtimeBuilder.build(candidate)
            if connectionState == .connected {
                try await tunnel.reload(runtimeConfiguration: runtime)
            }
            try await store.save(candidate)
            settingsRevision += 1
            settings = candidate.settings
            consecutiveHealthFailures = 0
            notice = connectionState == .connected
                ? "已切换到 \(node.name)"
                : "已选择 \(node.name)，下次连接时使用"
        } catch {
            if connectionState == .connected,
               let previousRuntime = try? runtimeBuilder.build(previous) {
                try? await tunnel.reload(runtimeConfiguration: previousRuntime)
            }
            notice = "无法切换节点：\(Redactor.clean(error.localizedDescription))"
        }
    }

    func testLatency(_ node: ProxyNode) async {
        do {
            let delay = try await latency.test(node)
            guard let index = nodes.firstIndex(where: { $0.id == node.id }) else { return }
            nodes[index].tcpLatencyMilliseconds = delay
            try await store.save(snapshot())
        } catch {
            notice = "\(node.name) 测速失败"
        }
    }

    func testAllLatencies() async {
        let results = await measureNodes(nodes)
        for index in nodes.indices {
            nodes[index].tcpLatencyMilliseconds = results[nodes[index].id]
        }
        do { try await store.save(snapshot()) }
        catch { notice = "测速完成，但保存结果失败" }
    }

    func importTextContent() async {
        let source = importText.trimmingCharacters(in: .whitespacesAndNewlines)
        do {
            let resolved = try await importService.resolve(source)
            try await applyImport(resolved)
            importText = ""
        } catch {
            notice = "导入失败：\(Redactor.clean(error.localizedDescription))"
        }
    }

    func importFile(_ url: URL) async {
        do {
            let service = importService
            let resolved = try await Task.detached(priority: .userInitiated) {
                try service.resolveFile(url)
            }.value
            try await applyImport(resolved)
        } catch {
            notice = "导入失败：\(Redactor.clean(error.localizedDescription))"
        }
    }

    func setRoutingMode(_ mode: RoutingMode) {
        updateSettings(reloadTunnel: true) { $0.routingMode = mode }
    }

    func setAutoSwitchEnabled(_ enabled: Bool) {
        updateSettings(reloadTunnel: false) { $0.autoSwitchEnabled = enabled }
        restartHealthMonitor()
    }

    func setUpdateInterval(_ hours: Int) {
        guard [6, 12, 24].contains(hours) else { return }
        updateSettings(reloadTunnel: false) { $0.updateIntervalHours = hours }
        restartSubscriptionMonitor()
    }

    func updateSubscription() async {
        await refreshSubscription(showSuccessNotice: true, onlyWhenDue: false)
    }

    func runDiagnostics() async {
        let raw = try? await store.rawConfigurationData()
        let encrypted = raw.map { !$0.isEmpty && $0.first != 0x7B } ?? false
        let output = await diagnostics.run(
            configuration: snapshot(),
            connectionState: connectionState,
            vpnConfigured: tunnel.isConfigured,
            encryptedStore: encrypted
        )
        diagnosticItems = output.items
        diagnosticExportURL = output.exportURL
    }

    func clearNotice() {
        notice = nil
    }

    private func applyImport(_ resolved: ResolvedImport, announce: Bool = true) async throws {
        let previous = snapshot()
        var candidate = previous
        var merged = nodes
        var added = 0

        for incoming in resolved.result.nodes {
            if let index = merged.firstIndex(where: { $0.stableIdentity == incoming.stableIdentity }) {
                var replacement = incoming
                replacement.id = merged[index].id
                replacement.tcpLatencyMilliseconds = merged[index].tcpLatencyMilliseconds
                merged[index] = replacement
            } else {
                merged.append(incoming)
                added += 1
            }
        }

        candidate.nodes = merged
        if candidate.settings.preferredNodeID == nil { candidate.settings.preferredNodeID = merged.first?.id }
        if let url = resolved.subscriptionURL {
            let key = "active-subscription-url"
            try keychain.set(url.absoluteString, for: key)
            candidate.settings.subscriptionURLKey = key
            candidate.settings.lastSubscriptionUpdateAt = Date()
        }
        candidate.updatedAt = Date()
        let runtime = try runtimeBuilder.build(candidate)

        if connectionState == .connected {
            try await tunnel.reload(runtimeConfiguration: runtime)
        }
        do {
            try await store.save(candidate)
        } catch {
            if connectionState == .connected,
               let previousRuntime = try? runtimeBuilder.build(previous) {
                try? await tunnel.reload(runtimeConfiguration: previousRuntime)
            }
            throw error
        }

        settingsRevision += 1
        nodes = candidate.nodes
        settings = candidate.settings
        let duplicates = resolved.result.duplicateCount
        let rejected = resolved.result.rejectedCount
        importSummary = "新增 \(added) 个，更新 \(resolved.result.nodes.count - added) 个，重复 \(duplicates) 个，不支持/无效 \(rejected) 个"
        if announce { notice = "导入成功" }
    }

    private func updateSettings(
        reloadTunnel: Bool,
        mutation: (inout AppSettings) -> Void
    ) {
        let previous = settings
        mutation(&settings)
        guard settings != previous else { return }
        settingsRevision += 1
        let revision = settingsRevision
        let candidate = snapshot()
        Task { [weak self] in
            await self?.commitSettings(
                candidate,
                previous: previous,
                revision: revision,
                reloadTunnel: reloadTunnel
            )
        }
    }

    private func commitSettings(
        _ candidate: StoredConfiguration,
        previous: AppSettings,
        revision: Int,
        reloadTunnel: Bool
    ) async {
        guard revision == settingsRevision else { return }
        var didReload = false
        do {
            if reloadTunnel, connectionState == .connected {
                try await tunnel.reload(runtimeConfiguration: runtimeBuilder.build(candidate))
                didReload = true
            }
            try await store.save(candidate)
        } catch {
            guard revision == settingsRevision else { return }
            settings = previous
            var rollback = snapshot()
            rollback.settings = previous
            rollback.updatedAt = Date()
            try? await store.save(rollback)
            if didReload, let runtime = try? runtimeBuilder.build(rollback) {
                try? await tunnel.reload(runtimeConfiguration: runtime)
            }
            notice = "设置未保存：\(Redactor.clean(error.localizedDescription))"
        }
    }

    private func restartHealthMonitor() {
        healthTask?.cancel()
        healthTask = nil
        consecutiveHealthFailures = 0
        guard settings.autoSwitchEnabled else { return }
        healthTask = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(30)) }
                catch { return }
                guard let self else { return }
                await self.runHealthCheck()
            }
        }
    }

    private func restartSubscriptionMonitor() {
        subscriptionTask?.cancel()
        subscriptionTask = nil
        guard hasSavedSubscription else { return }
        subscriptionTask = Task { [weak self] in
            await self?.refreshSubscription(showSuccessNotice: false, onlyWhenDue: true)
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(15 * 60)) }
                catch { return }
                guard let self else { return }
                await self.refreshSubscription(showSuccessNotice: false, onlyWhenDue: true)
            }
        }
    }

    private func refreshSubscription(showSuccessNotice: Bool, onlyWhenDue: Bool) async {
        guard !isUpdatingSubscription,
              let key = settings.subscriptionURLKey
        else { return }
        if onlyWhenDue,
           let lastUpdate = settings.lastSubscriptionUpdateAt,
           Date().timeIntervalSince(lastUpdate) < TimeInterval(settings.updateIntervalHours * 3600) {
            return
        }

        isUpdatingSubscription = true
        defer { isUpdatingSubscription = false }
        do {
            guard let source = try keychain.value(for: key), !source.isEmpty else {
                throw ImportError.malformed("已保存的订阅地址")
            }
            let resolved = try await importService.resolve(source)
            try await applyImport(resolved, announce: showSuccessNotice)
            if showSuccessNotice { notice = "订阅更新成功" }
        } catch {
            if showSuccessNotice {
                notice = "订阅更新失败，仍在使用上一份配置：\(Redactor.clean(error.localizedDescription))"
            }
        }
    }

    private func runHealthCheck() async {
        guard settings.autoSwitchEnabled,
              settings.routingMode != .direct,
              connectionState == .connected,
              let current = preferredNode
        else {
            consecutiveHealthFailures = 0
            return
        }

        do {
            _ = try await latency.testCurrentTunnel(timeout: .seconds(7))
            consecutiveHealthFailures = 0
            return
        } catch {
            consecutiveHealthFailures += 1
        }

        guard consecutiveHealthFailures >= 3 else { return }
        let originalID = current.id
        let candidates = nodes.filter { $0.id != originalID }
        let delays = await measureNodes(candidates)
        guard settings.autoSwitchEnabled,
              connectionState == .connected,
              preferredNode?.id == originalID,
              let replacement = candidates
                .filter({ delays[$0.id] != nil })
                .min(by: { (delays[$0.id] ?? .max) < (delays[$1.id] ?? .max) })
        else { return }
        consecutiveHealthFailures = 0
        await selectNode(replacement)
    }

    private func measureNodes(_ values: [ProxyNode]) async -> [UUID: Int] {
        var results: [UUID: Int] = [:]
        for start in stride(from: 0, to: values.count, by: 4) {
            let end = min(start + 4, values.count)
            let batch = Array(values[start..<end])
            await withTaskGroup(of: (UUID, Int?).self) { group in
                for node in batch {
                    group.addTask { [latency] in
                        (node.id, try? await latency.test(node))
                    }
                }
                for await (id, delay) in group {
                    if let delay { results[id] = delay }
                }
            }
        }
        return results
    }

    private func snapshot() -> StoredConfiguration {
        StoredConfiguration(nodes: nodes, settings: settings, updatedAt: Date())
    }
}
