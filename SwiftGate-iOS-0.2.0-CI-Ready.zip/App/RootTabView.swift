import SwiftUI

enum AppTab: Hashable {
    case home
    case nodes
    case importContent
    case settings
}

@MainActor
struct RootTabView: View {
    @Environment(AppModel.self) private var model
    @State private var selectedTab: AppTab = .home

    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack {
                HomeView()
            }
            .tabItem {
                Label("首页", systemImage: "house.fill")
            }
            .tag(AppTab.home)

            NavigationStack {
                NodesView()
            }
            .tabItem {
                Label("节点", systemImage: "point.3.connected.trianglepath.dotted")
            }
            .tag(AppTab.nodes)

            NavigationStack {
                ImportView()
            }
            .tabItem {
                Label("导入", systemImage: "square.and.arrow.down")
            }
            .tag(AppTab.importContent)

            NavigationStack {
                SettingsView()
            }
            .tabItem {
                Label("设置", systemImage: "gearshape.fill")
            }
            .tag(AppTab.settings)
        }
        .tint(SwiftGateTheme.tint)
        .task {
            await model.initialize()
        }
        .overlay(alignment: .top) {
            if let notice = model.notice {
                NoticeBanner(message: notice) {
                    model.clearNotice()
                }
                .padding(.horizontal, SwiftGateTheme.pagePadding)
                .padding(.top, 8)
                .transition(.move(edge: .top).combined(with: .opacity))
                .zIndex(10)
            }
        }
        .animation(.snappy, value: model.notice != nil)
    }
}
