import Foundation

enum Redactor {
    private static let patterns: [(String, String)] = [
        (#"(?i)(vless|vmess|trojan|ss|hysteria2|tuic)://[^\s]+"#, "$1://<redacted>"),
        (#"(?i)(uuid|password|token|secret|authorization|id)\s*[:=]\s*[\"']?[^\s,\"'}]+"#, "$1=<redacted>"),
        (#"(?i)(\"?(?:server|address|host|password|uuid|id)\"?\s*:\s*)\"[^\"]+\""#, "$1\"<redacted>\""),
        (#"(?i)(https?://[^?\s]+)\?[^\s]+"#, "$1?<redacted>"),
        (#"(?i)[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}"#, "<uuid>"),
    ]

    static func clean(_ input: String) -> String {
        patterns.reduce(input) { value, pattern in
            value.replacingOccurrences(
                of: pattern.0,
                with: pattern.1,
                options: .regularExpression
            )
        }
    }
}
