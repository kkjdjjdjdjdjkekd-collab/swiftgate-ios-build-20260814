import Foundation
import NetworkExtension
import Observation

@MainActor
@Observable
final class TunnelManager {
    private(set) var state: VPNConnectionState = .unavailable
    private(set) var statusMessage = "正在读取系统 VPN 状态"
    private var manager: NETunnelProviderManager?
    private var statusObserver: NSObjectProtocol?

    var isConfigured: Bool { manager != nil }

    init() {
        statusObserver = NotificationCenter.default.addObserver(
            forName: .NEVPNStatusDidChange,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.refreshState() }
        }
    }

    deinit {
        if let statusObserver { NotificationCenter.default.removeObserver(statusObserver) }
    }

    func load() async {
        do {
            manager = try await TunnelPreferences.loadManagers().first
            refreshState()
        } catch {
            state = .unavailable
            statusMessage = Redactor.clean(error.localizedDescription)
        }
    }

    func toggle(runtimeConfiguration: String) async throws {
        switch state {
        case .connected, .connecting, .reasserting:
            manager?.connection.stopVPNTunnel()
        case .disconnecting:
            return
        case .disconnected, .invalid, .unavailable:
            let manager = try await prepareManager()
            try await TunnelPreferences.reload(manager)
            try manager.connection.startVPNTunnel(
                options: TunnelPayloadCodec.startOptions(runtimeConfiguration: runtimeConfiguration)
            )
        }
        refreshState()
    }

    func reload(runtimeConfiguration: String) async throws {
        guard state == .connected,
              let session = manager?.connection as? NETunnelProviderSession
        else { throw TunnelManagerError.notConnected }
        let payload = try TunnelPayloadCodec.encode(runtimeConfiguration: runtimeConfiguration)
        let response = try await TunnelPreferences.send(payload, through: session)
        if let response, !response.isEmpty {
            let message = String(data: response, encoding: .utf8) ?? "隧道拒绝了新配置"
            throw TunnelManagerError.extensionRejected(Redactor.clean(message))
        }
    }

    private func prepareManager() async throws -> NETunnelProviderManager {
        let current = manager ?? NETunnelProviderManager()
        let tunnelProtocol: NETunnelProviderProtocol
        if let existing = current.protocolConfiguration as? NETunnelProviderProtocol {
            tunnelProtocol = existing
        } else {
            tunnelProtocol = NETunnelProviderProtocol()
        }
        tunnelProtocol.providerBundleIdentifier = AppConfiguration.tunnelBundleIdentifier
        tunnelProtocol.serverAddress = "SwiftGate 本机隧道"
        tunnelProtocol.includeAllNetworks = false
        tunnelProtocol.excludeLocalNetworks = true
        current.protocolConfiguration = tunnelProtocol
        current.localizedDescription = "SwiftGate"
        current.isEnabled = true
        try await TunnelPreferences.save(current)
        try await TunnelPreferences.reload(current)
        manager = current
        return current
    }

    private func refreshState() {
        guard let manager else {
            state = .disconnected
            statusMessage = "首次连接时会请求添加 VPN 配置"
            return
        }
        state = VPNConnectionState(manager.connection.status)
        statusMessage = state.title
    }
}

enum TunnelManagerError: LocalizedError {
    case notConnected
    case extensionRejected(String)

    var errorDescription: String? {
        switch self {
        case .notConnected: "VPN 尚未连接"
        case .extensionRejected(let message): message
        }
    }
}

private enum TunnelPreferences {
    static func loadManagers() async throws -> [NETunnelProviderManager] {
        try await withCheckedThrowingContinuation { continuation in
            NETunnelProviderManager.loadAllFromPreferences { managers, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: managers ?? []) }
            }
        }
    }

    static func save(_ manager: NETunnelProviderManager) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            manager.saveToPreferences { error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume() }
            }
        }
    }

    static func reload(_ manager: NETunnelProviderManager) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            manager.loadFromPreferences { error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume() }
            }
        }
    }

    static func send(_ data: Data, through session: NETunnelProviderSession) async throws -> Data? {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Data?, Error>) in
            do {
                try session.sendProviderMessage(data) { response in
                    continuation.resume(returning: response)
                }
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}
