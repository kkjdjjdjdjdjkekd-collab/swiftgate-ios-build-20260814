import Foundation
import CryptoKit

actor AtomicConfigurationStore {
    private let configurationURL: URL
    private let keychain: KeychainStore
    private let encryptionKeyName = "configuration-encryption-key-v1"

    init(
        containerURL: URL = AppConfiguration.sharedContainerURL,
        keychain: KeychainStore = KeychainStore()
    ) {
        configurationURL = containerURL.appendingPathComponent(AppConfiguration.activeConfigurationFile)
        self.keychain = keychain
    }

    func load() throws -> StoredConfiguration {
        guard FileManager.default.fileExists(atPath: configurationURL.path) else {
            return StoredConfiguration()
        }
        let encrypted = try Data(contentsOf: configurationURL)
        let data: Data
        if encrypted.first == 0x7B {
            // One-time migration for early development builds that wrote JSON directly.
            data = encrypted
        } else {
            let sealed = try AES.GCM.SealedBox(combined: encrypted)
            data = try AES.GCM.open(sealed, using: try encryptionKey())
        }
        let configuration = try JSONDecoder.swiftGate.decode(StoredConfiguration.self, from: data)
        if encrypted.first == 0x7B { try save(configuration) }
        return configuration
    }

    func save(_ configuration: StoredConfiguration) throws {
        let plaintext = try JSONEncoder.swiftGate.encode(configuration)
        guard let encrypted = try AES.GCM.seal(plaintext, using: encryptionKey()).combined else {
            throw CocoaError(.fileWriteUnknown)
        }
        try encrypted.write(to: configurationURL, options: [.atomic, .completeFileProtection])
    }

    func rawConfigurationData() throws -> Data {
        try Data(contentsOf: configurationURL)
    }

    private func encryptionKey() throws -> SymmetricKey {
        if let saved = try keychain.data(for: encryptionKeyName) {
            return SymmetricKey(data: saved)
        }
        let key = SymmetricKey(size: .bits256)
        try keychain.set(key.withUnsafeBytes { Data($0) }, for: encryptionKeyName)
        return key
    }
}

extension JSONEncoder {
    static var swiftGate: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }
}

extension JSONDecoder {
    static var swiftGate: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
