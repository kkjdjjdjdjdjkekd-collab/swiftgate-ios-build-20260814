import Foundation

struct DiagnosticOutput: Sendable {
    let items: [DiagnosticItem]
    let exportURL: URL
}

struct DiagnosticService: Sendable {
    private let runtimeBuilder = RuntimeConfigBuilder()
    private let latency = LatencyService()

    func run(
        configuration: StoredConfiguration,
        connectionState: VPNConnectionState,
        vpnConfigured: Bool,
        encryptedStore: Bool
    ) async -> DiagnosticOutput {
        var items: [DiagnosticItem] = []
        items.append(DiagnosticItem(
            name: "VPN 配置",
            passed: vpnConfigured || connectionState == .disconnected,
            message: vpnConfigured ? "系统 VPN 配置已安装" : "首次连接时会请求系统授权"
        ))
        items.append(DiagnosticItem(
            name: "安全存储",
            passed: encryptedStore,
            message: encryptedStore ? "节点配置已加密保存" : "没有发现已加密的配置文件"
        ))

        do {
            _ = try runtimeBuilder.build(configuration)
            items.append(DiagnosticItem(name: "运行配置", passed: true, message: "配置结构有效"))
        } catch {
            items.append(DiagnosticItem(
                name: "运行配置",
                passed: false,
                message: Redactor.clean(error.localizedDescription)
            ))
        }

        let corePresent = hasEmbeddedCore()
        items.append(DiagnosticItem(
            name: "隧道核心",
            passed: corePresent,
            message: corePresent ? "Libbox 已嵌入应用扩展" : "需要在 Mac 构建并嵌入 Libbox.xcframework"
        ))

        if let preferredID = configuration.settings.preferredNodeID,
           let node = configuration.nodes.first(where: { $0.id == preferredID }) {
            do {
                let delay = try await latency.test(node, timeout: .seconds(6))
                items.append(DiagnosticItem(name: "节点握手", passed: true, message: "TCP 握手 \(delay) ms"))
            } catch {
                items.append(DiagnosticItem(name: "节点握手", passed: false, message: "连接节点服务器失败"))
            }
        } else {
            items.append(DiagnosticItem(name: "节点握手", passed: false, message: "尚未选择节点"))
        }

        if connectionState == .connected {
            do {
                let delay = try await latency.testCurrentTunnel()
                items.append(DiagnosticItem(name: "测试网址", passed: true, message: "代理链路响应 \(delay) ms"))
            } catch {
                items.append(DiagnosticItem(name: "测试网址", passed: false, message: "代理链路未返回有效响应"))
            }
        } else {
            items.append(DiagnosticItem(name: "测试网址", passed: false, message: "连接后可检查完整代理链路"))
        }

        let exportURL = writeReport(items: items, state: connectionState)
        return DiagnosticOutput(items: items, exportURL: exportURL)
    }

    private func hasEmbeddedCore() -> Bool {
        guard let plugInsURL = Bundle.main.builtInPlugInsURL,
              let extensionURL = try? FileManager.default.contentsOfDirectory(
                  at: plugInsURL,
                  includingPropertiesForKeys: nil
              ).first(where: { $0.pathExtension == "appex" }),
              let bundle = Bundle(url: extensionURL),
              let value = bundle.object(forInfoDictionaryKey: "SwiftGateEmbeddedCore") as? String
        else { return false }
        return value.caseInsensitiveCompare("YES") == .orderedSame
    }

    private func writeReport(items: [DiagnosticItem], state: VPNConnectionState) -> URL {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "开发版"
        var lines = [
            "SwiftGate iOS 诊断",
            "版本：\(version)",
            "系统：iOS",
            "VPN：\(state.title)",
            "时间：\(ISO8601DateFormatter().string(from: Date()))",
            "",
        ]
        lines.append(contentsOf: items.map { "[\($0.passed ? "通过" : "未通过")] \($0.name)：\($0.message)" })
        let safe = Redactor.clean(lines.joined(separator: "\n"))
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("SwiftGate-Diagnostic.txt")
        try? Data(safe.utf8).write(to: url, options: [.atomic, .completeFileProtection])
        return url
    }
}
