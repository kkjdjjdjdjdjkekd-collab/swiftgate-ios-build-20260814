import Foundation

enum AppConfiguration {
    static var appGroupIdentifier: String {
        Bundle.main.object(forInfoDictionaryKey: "AppGroupIdentifier") as? String
            ?? "group.com.swiftgate.shared"
    }

    static var tunnelBundleIdentifier: String {
        "\(Bundle.main.bundleIdentifier ?? "com.swiftgate.ios").PacketTunnel"
    }

    static var keychainService: String {
        "\(Bundle.main.bundleIdentifier ?? "com.swiftgate.ios").secrets"
    }
    static let activeConfigurationFile = "active.json"
    static let settingsFile = "settings.json"
    static let tunnelStateFile = "tunnel-state.json"

    static var sharedContainerURL: URL {
        guard let url = FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: appGroupIdentifier
        ) else {
            preconditionFailure("App Group is unavailable. Check signing and entitlements.")
        }
        return url
    }
}
