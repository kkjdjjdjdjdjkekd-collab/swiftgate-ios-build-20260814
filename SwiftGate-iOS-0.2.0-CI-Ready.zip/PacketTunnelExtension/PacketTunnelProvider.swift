#if SWIFTGATE_EMBEDDED_CORE
final class PacketTunnelProvider: ExtensionProvider {}
#else
import Foundation
import NetworkExtension

final class PacketTunnelProvider: NEPacketTunnelProvider {
    override func startTunnel(options: [String: NSObject]?) async throws {
        throw NSError(
            domain: "com.swiftgate.ios.PacketTunnel",
            code: 1,
            userInfo: [
                NSLocalizedDescriptionKey:
                    "代理核心尚未嵌入。请在 Mac 上运行 Scripts/prepare-core.sh 后重新生成工程。",
            ]
        )
    }

    override func stopTunnel(with reason: NEProviderStopReason) async {}

    override func handleAppMessage(_ messageData: Data) async -> Data? {
        Data("代理核心尚未嵌入".utf8)
    }
}
#endif
