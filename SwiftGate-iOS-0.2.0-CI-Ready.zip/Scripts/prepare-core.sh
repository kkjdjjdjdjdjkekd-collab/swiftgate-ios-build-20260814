#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_ROOT="$ROOT/.build/core"
CORE_DIR="$BUILD_ROOT/sing-box"
APPLE_DIR="$BUILD_ROOT/sing-box-for-apple"
APPLE_REF="${SWIFTGATE_APPLE_REF:-b1daf888efa6a5b80d668257ba540e600384d626}"
CORE_REF="${SWIFTGATE_CORE_REF:-3e16ce764818796996c1be3f12b0c6008808cf34}"
LIBBOX_PLATFORMS="${SWIFTGATE_LIBBOX_PLATFORMS:-ios,iossimulator}"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "The iOS core can only be built on macOS with Xcode." >&2
  exit 1
fi

for tool in git go make xcodebuild; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "Missing required tool: $tool" >&2
    exit 1
  fi
done

mkdir -p "$BUILD_ROOT" "$ROOT/Frameworks"

if [[ ! -d "$CORE_DIR/.git" ]]; then
  git clone https://github.com/SagerNet/sing-box.git "$CORE_DIR"
fi
git -C "$CORE_DIR" fetch --tags origin
git -C "$CORE_DIR" fetch origin "$CORE_REF"
git -C "$CORE_DIR" checkout --detach FETCH_HEAD

if [[ ! -d "$APPLE_DIR/.git" ]]; then
  git clone https://github.com/SagerNet/sing-box-for-apple.git "$APPLE_DIR"
fi
git -C "$APPLE_DIR" fetch origin "$APPLE_REF"
git -C "$APPLE_DIR" checkout --detach "$APPLE_REF"
git -C "$APPLE_DIR" submodule update --init --recursive

echo "Building the official Libbox XCFramework..."
(
  cd "$CORE_DIR"
  make lib_install
  export PATH="$PATH:$(go env GOPATH)/bin"
  go run ./cmd/internal/build_libbox -target apple -platform "$LIBBOX_PLATFORMS"
)

if [[ ! -d "$APPLE_DIR/Libbox.xcframework" && -d "$CORE_DIR/Libbox.xcframework" ]]; then
  ditto "$CORE_DIR/Libbox.xcframework" "$APPLE_DIR/Libbox.xcframework"
fi
if [[ ! -d "$APPLE_DIR/Libbox.xcframework" ]]; then
  echo "Libbox.xcframework was not produced at the expected path." >&2
  exit 1
fi

if [[ ! -d "$APPLE_DIR/Library" || ! -f "$APPLE_DIR/Localizable.xcstrings" ]]; then
  echo "The official Apple bridge sources are incomplete." >&2
  exit 1
fi

rm -rf "$ROOT/Frameworks/Libbox.xcframework"
ditto "$APPLE_DIR/Libbox.xcframework" "$ROOT/Frameworks/Libbox.xcframework"

{
  echo "sing-box $(git -C "$CORE_DIR" rev-parse HEAD)"
  echo "sing-box-for-apple $(git -C "$APPLE_DIR" rev-parse HEAD)"
  echo "built-at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "$ROOT/Frameworks/SOURCE-REVISIONS.txt"

echo "Native core and official Apple bridge sources are ready."
"$ROOT/Scripts/generate-project.sh"
