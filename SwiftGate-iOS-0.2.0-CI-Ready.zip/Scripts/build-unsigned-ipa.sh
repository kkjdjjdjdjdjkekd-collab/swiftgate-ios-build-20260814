#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_ROOT="${SWIFTGATE_BUILD_ROOT:-$ROOT/.build/ipa}"
DERIVED_DATA="$BUILD_ROOT/DerivedData"
SOURCE_PACKAGES="$BUILD_ROOT/SourcePackages"
STAGING="$BUILD_ROOT/staging"
OUTPUT_DIR="${SWIFTGATE_OUTPUT_DIR:-$ROOT/.build/artifacts}"
APP_PATH="$DERIVED_DATA/Build/Products/Release-iphoneos/SwiftGate.app"
IPA_PATH="$OUTPUT_DIR/SwiftGate-Unsigned.ipa"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "A real iPhone IPA requires macOS, Xcode and the iOS SDK." >&2
  exit 1
fi

for tool in xcodebuild xcodegen ditto shasum lipo unzip; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "Missing required tool: $tool" >&2
    exit 1
  fi
done

if [[ ! -d "$ROOT/Frameworks/Libbox.xcframework" || \
      ! -d "$ROOT/.build/core/sing-box-for-apple/Library" ]]; then
  echo "Building the native iPhone tunnel core (device slice only)..."
  SWIFTGATE_LIBBOX_PLATFORMS="${SWIFTGATE_LIBBOX_PLATFORMS:-ios}" \
    "$ROOT/Scripts/prepare-core.sh"
else
  "$ROOT/Scripts/generate-project.sh"
fi

rm -rf "$BUILD_ROOT"
mkdir -p "$DERIVED_DATA" "$SOURCE_PACKAGES" "$STAGING/Payload" "$OUTPUT_DIR"

echo "Resolving pinned Swift package dependencies..."
xcodebuild \
  -resolvePackageDependencies \
  -project "$ROOT/SwiftGateiOS.xcodeproj" \
  -scheme SwiftGate \
  -derivedDataPath "$DERIVED_DATA" \
  -clonedSourcePackagesDirPath "$SOURCE_PACKAGES"

echo "Building SwiftGate for a generic iPhone without code signing..."
xcodebuild \
  -project "$ROOT/SwiftGateiOS.xcodeproj" \
  -scheme SwiftGate \
  -configuration Release \
  -sdk iphoneos \
  -destination "generic/platform=iOS" \
  -derivedDataPath "$DERIVED_DATA" \
  -clonedSourcePackagesDirPath "$SOURCE_PACKAGES" \
  -disableAutomaticPackageResolution \
  ARCHS=arm64 \
  ONLY_ACTIVE_ARCH=NO \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  DEVELOPMENT_TEAM="" \
  PROVISIONING_PROFILE_SPECIFIER="" \
  COMPILER_INDEX_STORE_ENABLE=NO \
  build

if [[ ! -d "$APP_PATH" ]]; then
  echo "SwiftGate.app was not produced at the expected path: $APP_PATH" >&2
  exit 1
fi
if [[ ! -d "$APP_PATH/PlugIns/PacketTunnel.appex" ]]; then
  echo "The Packet Tunnel extension is missing from the app bundle." >&2
  exit 1
fi
if [[ ! -f "$APP_PATH/SwiftGate" || ! -f "$APP_PATH/PlugIns/PacketTunnel.appex/PacketTunnel" ]]; then
  echo "The app or Packet Tunnel executable is missing." >&2
  exit 1
fi
if ! lipo -archs "$APP_PATH/SwiftGate" | grep -qw arm64 || \
   ! lipo -archs "$APP_PATH/PlugIns/PacketTunnel.appex/PacketTunnel" | grep -qw arm64; then
  echo "The app or Packet Tunnel executable is missing the arm64 device slice." >&2
  exit 1
fi

APP_ID="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP_PATH/Info.plist")"
EXT_ID="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP_PATH/PlugIns/PacketTunnel.appex/Info.plist")"
if [[ "$EXT_ID" != "$APP_ID.PacketTunnel" ]]; then
  echo "Bundle identifier mismatch: expected $APP_ID.PacketTunnel, found $EXT_ID" >&2
  exit 1
fi

ditto "$APP_PATH" "$STAGING/Payload/SwiftGate.app"
find "$STAGING/Payload" -type d -name _CodeSignature -prune -exec rm -rf {} +
find "$STAGING/Payload" -type f -name embedded.mobileprovision -delete
rm -f "$IPA_PATH" "$IPA_PATH.sha256" "$OUTPUT_DIR/Build-Info.txt"
(
  cd "$STAGING"
  ditto -c -k --sequesterRsrc --keepParent Payload "$IPA_PATH"
)

shasum -a 256 "$IPA_PATH" > "$IPA_PATH.sha256"
unzip -tq "$IPA_PATH"
{
  echo "artifact SwiftGate-Unsigned.ipa"
  echo "signing unsigned"
  echo "configuration Release"
  echo "sdk iphoneos"
  echo "built-at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  if [[ -f "$ROOT/Frameworks/SOURCE-REVISIONS.txt" ]]; then
    cat "$ROOT/Frameworks/SOURCE-REVISIONS.txt"
  fi
} > "$OUTPUT_DIR/Build-Info.txt"

echo "Unsigned IPA ready: $IPA_PATH"
echo "You must sign the app, PacketTunnel.appex and embedded frameworks with matching entitlements before installation."
