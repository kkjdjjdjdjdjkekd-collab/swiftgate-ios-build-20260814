import Foundation

struct ResolvedImport: Sendable {
    let result: ImportResult
    let subscriptionURL: URL?
}

struct ImportService: Sendable {
    private let parser = ShareLinkParser()
    private let yamlParser = ClashYAMLParser()
    private let maximumBytes = 5 * 1024 * 1024

    func resolve(_ source: String) async throws -> ResolvedImport {
        let trimmed = source.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw ImportError.empty }

        if let url = singleSubscriptionURL(trimmed) {
            let content = try await download(url)
            return ResolvedImport(result: try parseContent(content), subscriptionURL: url)
        }
        return ResolvedImport(result: try parseContent(trimmed), subscriptionURL: nil)
    }

    func resolveFile(_ url: URL) throws -> ResolvedImport {
        let values = try url.resourceValues(forKeys: [.fileSizeKey])
        if let size = values.fileSize, size > maximumBytes { throw ImportServiceError.tooLarge }
        let data = try Data(contentsOf: url, options: [.mappedIfSafe])
        guard data.count <= maximumBytes else { throw ImportServiceError.tooLarge }
        guard let content = String(data: data, encoding: .utf8) else {
            throw ImportServiceError.unsupportedEncoding
        }
        return ResolvedImport(result: try parseContent(content), subscriptionURL: nil)
    }

    private func singleSubscriptionURL(_ value: String) -> URL? {
        guard !value.contains(where: { $0.isWhitespace }),
              let url = URL(string: value),
              ["https", "http"].contains(url.scheme?.lowercased() ?? ""),
              url.host != nil
        else { return nil }
        return url
    }

    private func download(_ url: URL) async throws -> String {
        guard url.scheme?.lowercased() == "https" else {
            throw ImportServiceError.insecureSubscription
        }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        request.setValue("SwiftGate-iOS/0.2", forHTTPHeaderField: "User-Agent")
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        let (data, response) = try await URLSession(configuration: configuration).data(for: request)
        guard let http = response as? HTTPURLResponse,
              (200...299).contains(http.statusCode)
        else { throw ImportServiceError.badResponse }
        guard http.url?.scheme?.lowercased() == "https" else {
            throw ImportServiceError.insecureRedirect
        }
        guard data.count <= maximumBytes else { throw ImportServiceError.tooLarge }
        guard let content = String(data: data, encoding: .utf8) else {
            throw ImportServiceError.unsupportedEncoding
        }
        return content
    }

    private func parseContent(_ content: String) throws -> ImportResult {
        let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)

        if ClashYAMLParser.looksLikeClashConfiguration(trimmed) {
            return try yamlParser.parse(trimmed)
        }

        if let configuration = try? JSONDecoder.swiftGate.decode(
            StoredConfiguration.self,
            from: Data(trimmed.utf8)
        ), !configuration.nodes.isEmpty {
            return ImportResult(nodes: configuration.nodes, duplicateCount: 0, rejectedCount: 0)
        }
        if let nodes = try? JSONDecoder.swiftGate.decode([ProxyNode].self, from: Data(trimmed.utf8)),
           !nodes.isEmpty {
            return ImportResult(nodes: nodes, duplicateCount: 0, rejectedCount: 0)
        }

        let decoded = decodeBase64Subscription(trimmed) ?? trimmed
        return try parser.parse(decoded)
    }

    private func decodeBase64Subscription(_ value: String) -> String? {
        let knownSchemes = ["vless://", "vmess://", "trojan://", "ss://", "hysteria2://", "hy2://", "tuic://"]
        if knownSchemes.contains(where: { value.localizedCaseInsensitiveContains($0) }) { return nil }
        let compact = value.components(separatedBy: .whitespacesAndNewlines).joined()
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let remainder = compact.count % 4
        let padded = remainder == 0 ? compact : compact + String(repeating: "=", count: 4 - remainder)
        guard let data = Data(base64Encoded: padded),
              let decoded = String(data: data, encoding: .utf8),
              knownSchemes.contains(where: { decoded.localizedCaseInsensitiveContains($0) })
        else { return nil }
        return decoded
    }
}

enum ImportServiceError: LocalizedError {
    case insecureSubscription
    case insecureRedirect
    case tooLarge
    case badResponse
    case unsupportedEncoding

    var errorDescription: String? {
        switch self {
        case .insecureSubscription: "订阅必须使用 HTTPS，避免节点凭据被截获"
        case .insecureRedirect: "订阅地址跳转到了不安全的连接"
        case .tooLarge: "配置文件超过 5 MB"
        case .badResponse: "订阅服务器没有返回有效内容"
        case .unsupportedEncoding: "配置文件不是 UTF-8 文本"
        }
    }
}
