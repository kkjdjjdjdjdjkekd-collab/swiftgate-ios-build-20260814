import Foundation
import Network

actor LatencyService {
    private let httpSession: URLSession

    init() {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 8
        configuration.timeoutIntervalForResource = 10
        httpSession = URLSession(configuration: configuration)
    }

    func test(_ node: ProxyNode, timeout: TimeInterval = 5) async throws -> Int {
        try await measure(node, timeout: timeout)
    }

    func testCurrentTunnel(timeout: TimeInterval = 8) async throws -> Int {
        let urls = [
            URL(string: "https://cp.cloudflare.com/generate_204")!,
            URL(string: "https://www.gstatic.com/generate_204")!,
        ]
        var lastError: Error = URLError(.cannotConnectToHost)
        for url in urls {
            do { return try await measureHTTP(url, timeout: timeout) }
            catch { lastError = error }
        }
        throw lastError
    }

    private func measureHTTP(_ url: URL, timeout: TimeInterval) async throws -> Int {
        let start = DispatchTime.now().uptimeNanoseconds
        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.timeoutInterval = timeout
        let (_, response) = try await httpSession.data(for: request)
        guard let http = response as? HTTPURLResponse, [200, 204].contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        return Int((DispatchTime.now().uptimeNanoseconds - start) / 1_000_000)
    }

    private func measure(_ node: ProxyNode, timeout: TimeInterval) async throws -> Int {
        let start = DispatchTime.now().uptimeNanoseconds
        let connection = NWConnection(
            host: NWEndpoint.Host(node.server),
            port: NWEndpoint.Port(rawValue: node.port)!,
            using: .tcp
        )
        let queue = DispatchQueue(label: "SwiftGate.Latency.\(node.id.uuidString)")
        let timeoutSeconds = max(0.1, timeout)
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                let attempt = LatencyAttempt(continuation)
                connection.stateUpdateHandler = { state in
                    switch state {
                    case .ready:
                        let milliseconds = Int(
                            (DispatchTime.now().uptimeNanoseconds - start) / 1_000_000
                        )
                        if attempt.finish(.success(milliseconds)) { connection.cancel() }
                    case .failed(let error):
                        _ = attempt.finish(.failure(error))
                    case .cancelled:
                        _ = attempt.finish(.failure(CancellationError()))
                    default:
                        break
                    }
                }
                queue.asyncAfter(deadline: .now() + timeoutSeconds) {
                    if attempt.finish(.failure(URLError(.timedOut))) { connection.cancel() }
                }
                connection.start(queue: queue)
            }
        } onCancel: {
            connection.cancel()
        }
    }
}

private final class LatencyAttempt: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Int, Error>?

    init(_ continuation: CheckedContinuation<Int, Error>) {
        self.continuation = continuation
    }

    @discardableResult
    func finish(_ result: Result<Int, Error>) -> Bool {
        lock.lock()
        guard let continuation else {
            lock.unlock()
            return false
        }
        self.continuation = nil
        lock.unlock()
        continuation.resume(with: result)
        return true
    }
}
