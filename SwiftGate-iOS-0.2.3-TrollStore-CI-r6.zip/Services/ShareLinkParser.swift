import Foundation

enum ImportError: LocalizedError {
    case empty
    case unsupported(String)
    case malformed(String)

    var errorDescription: String? {
        switch self {
        case .empty: "没有找到可导入的内容"
        case .unsupported(let value): "暂不支持：\(Redactor.clean(value))"
        case .malformed(let value): "链接格式不正确：\(Redactor.clean(value))"
        }
    }
}

struct ImportResult: Sendable {
    let nodes: [ProxyNode]
    let duplicateCount: Int
    let rejectedCount: Int
}

struct ShareLinkParser: Sendable {
    func parse(_ text: String) throws -> ImportResult {
        let candidates = text
            .split(whereSeparator: { $0.isWhitespace })
            .map(String.init)
            .filter { !$0.isEmpty }
        guard !candidates.isEmpty else { throw ImportError.empty }

        var nodes: [ProxyNode] = []
        var rejected = 0
        var firstError: ImportError?
        for candidate in candidates {
            do {
                nodes.append(try parseLink(candidate))
            } catch let error as ImportError {
                rejected += 1
                if firstError == nil { firstError = error }
            } catch {
                rejected += 1
            }
        }
        guard !nodes.isEmpty else { throw firstError ?? ImportError.unsupported(candidates[0]) }

        var identities = Set<String>()
        var unique: [ProxyNode] = []
        for node in nodes where identities.insert(node.stableIdentity).inserted {
            unique.append(node)
        }
        return ImportResult(
            nodes: unique,
            duplicateCount: nodes.count - unique.count,
            rejectedCount: rejected
        )
    }

    private func parseLink(_ value: String) throws -> ProxyNode {
        guard let scheme = URLComponents(string: value)?.scheme?.lowercased() else {
            throw ImportError.malformed(value)
        }
        if scheme == "vmess" { return try parseVMess(value) }
        if scheme == "ss" { return try parseShadowsocks(value) }
        guard let components = URLComponents(string: value),
              let host = components.host,
              let portValue = components.port,
              let port = UInt16(exactly: portValue),
              port > 0
        else { throw ImportError.malformed(value) }

        let query = Dictionary(
            components.queryItems?.map { ($0.name.lowercased(), $0.value ?? "") } ?? [],
            uniquingKeysWith: { _, last in last }
        )
        if let transport = (query["type"] ?? query["network"])?.lowercased(),
           !["", "tcp", "ws", "http", "httpupgrade", "grpc"].contains(transport) {
            throw ImportError.unsupported("\(scheme.uppercased()) / \(transport)")
        }
        let name = components.fragment?.removingPercentEncoding?.nonEmpty
            ?? "\(scheme.uppercased()) · \(host)"
        let credential = components.user?.removingPercentEncoding ?? ""
        let type: ProxyProtocol
        switch scheme {
        case "vless": type = .vless
        case "trojan": type = .trojan
        case "hysteria2", "hy2": type = .hysteria2
        case "tuic": type = .tuic
        default: throw ImportError.unsupported(scheme)
        }
        guard !credential.isEmpty else { throw ImportError.malformed(value) }
        var normalizedQuery = query
        if type == .tuic,
           let password = components.password?.removingPercentEncoding,
           !password.isEmpty {
            normalizedQuery["password"] = password
        }
        return ProxyNode(
            name: name,
            type: type,
            server: host,
            port: port,
            credential: credential,
            transport: query["type"] ?? query["network"],
            tls: ["tls", "reality"].contains(query["security"]?.lowercased() ?? "")
                || type == .hysteria2 || type == .tuic,
            serverName: query["sni"],
            host: query["host"],
            path: (query["path"] ?? query["servicename"] ?? query["service_name"])?
                .removingPercentEncoding,
            query: normalizedQuery
        )
    }

    private func parseShadowsocks(_ value: String) throws -> ProxyNode {
        let parts = value.split(separator: "#", maxSplits: 1)
        let fragment = parts.count > 1 ? String(parts[1]).removingPercentEncoding : nil
        let withoutFragment = String(parts[0])
        guard var body = withoutFragment.split(separator: ":", maxSplits: 1).dropFirst().first.map(String.init) else {
            throw ImportError.malformed(value)
        }
        body = body.removingLeadingSlashes

        let queryText: String?
        if let index = body.firstIndex(of: "?") {
            queryText = String(body[body.index(after: index)...])
            body = String(body[..<index])
        } else {
            queryText = nil
        }

        let decodedAuthority: String
        if body.contains("@") {
            decodedAuthority = body
        } else if let decoded = Data(base64Encoded: body.base64Padded)
            .flatMap({ String(data: $0, encoding: .utf8) }) {
            decodedAuthority = decoded
        } else {
            throw ImportError.malformed(value)
        }

        guard let at = decodedAuthority.lastIndex(of: "@") else { throw ImportError.malformed(value) }
        var credentials = String(decodedAuthority[..<at])
        let endpoint = String(decodedAuthority[decodedAuthority.index(after: at)...])
        if !credentials.contains(":"),
           let decoded = Data(base64Encoded: credentials.base64Padded)
            .flatMap({ String(data: $0, encoding: .utf8) }) {
            credentials = decoded
        }
        guard let separator = credentials.firstIndex(of: ":") else { throw ImportError.malformed(value) }
        let method = String(credentials[..<separator]).removingPercentEncoding ?? ""
        let password = String(credentials[credentials.index(after: separator)...]).removingPercentEncoding ?? ""
        guard !method.isEmpty, !password.isEmpty,
              let endpointComponents = URLComponents(string: "ss://placeholder@\(endpoint)"),
              let host = endpointComponents.host,
              let portValue = endpointComponents.port,
              let port = UInt16(exactly: portValue),
              port > 0
        else { throw ImportError.malformed(value) }

        var query = Dictionary(
            URLComponents(string: "ss://x.invalid/?\(queryText ?? "")")?.queryItems?
                .map { ($0.name.lowercased(), $0.value ?? "") } ?? [],
            uniquingKeysWith: { _, last in last }
        )
        query["method"] = method
        return ProxyNode(
            name: fragment?.nonEmpty ?? "SS · \(host)",
            type: .shadowsocks,
            server: host,
            port: port,
            credential: password,
            query: query
        )
    }

    private func parseVMess(_ value: String) throws -> ProxyNode {
        guard let rawPayload = value.split(separator: ":", maxSplits: 1).last else {
            throw ImportError.malformed(value)
        }
        let payload = String(rawPayload).removingLeadingSlashes
        guard let data = Data(base64Encoded: payload.base64Padded),
              let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let host = json["add"] as? String,
              let id = json["id"] as? String,
              let port = UInt16(String(describing: json["port"] ?? "")),
              port > 0
        else { throw ImportError.malformed(value) }
        let tls = (json["tls"] as? String)?.lowercased() == "tls"
        let transport = (json["net"] as? String)?.lowercased()
        if let transport, !["", "tcp", "ws", "http", "httpupgrade", "grpc"].contains(transport) {
            throw ImportError.unsupported("VMess / \(transport)")
        }
        return ProxyNode(
            name: (json["ps"] as? String)?.nonEmpty ?? "VMess · \(host)",
            type: .vmess,
            server: host,
            port: port,
            credential: id,
            transport: transport,
            tls: tls,
            serverName: json["sni"] as? String,
            host: json["host"] as? String,
            path: json["path"] as? String,
            query: [
                "scy": json["scy"] as? String ?? "auto",
                "aid": String(describing: json["aid"] ?? "0"),
                "fp": json["fp"] as? String ?? "",
                "alpn": json["alpn"] as? String ?? "",
                "packet_encoding": json["packetEncoding"] as? String
                    ?? json["packet_encoding"] as? String
                    ?? "",
            ]
        )
    }
}

private extension String {
    var nonEmpty: String? { isEmpty ? nil : self }
    var removingLeadingSlashes: String { String(drop(while: { $0 == "/" })) }
    var base64Padded: String {
        let normalized = replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let remainder = normalized.count % 4
        return remainder == 0 ? normalized : normalized + String(repeating: "=", count: 4 - remainder)
    }
}
