import Foundation

enum TunnelPayloadCodec {
    static func startOptions(runtimeConfiguration: String) -> [String: NSObject] {
        [
            "configContent": NSString(string: runtimeConfiguration),
            "systemProxyEnabled": NSNumber(value: true),
            "includeAllNetworks": NSNumber(value: false),
            "excludeDefaultRoute": NSNumber(value: false),
        ]
    }

    static func encode(runtimeConfiguration: String) throws -> Data {
        try PropertyListSerialization.data(
            fromPropertyList: startOptions(runtimeConfiguration: runtimeConfiguration),
            format: .binary,
            options: 0
        )
    }

    static func decode(_ data: Data) throws -> [String: NSObject] {
        let propertyList = try PropertyListSerialization.propertyList(
            from: data,
            options: [],
            format: nil
        )
        guard let options = propertyList as? [String: NSObject],
              options["configContent"] as? String != nil
        else { throw TunnelPayloadError.invalidPayload }
        return options
    }
}

enum TunnelPayloadError: LocalizedError {
    case invalidPayload

    var errorDescription: String? { "收到的隧道配置无效" }
}
