import Foundation

enum Redactor {
    static func clean(_ input: String) -> String {
        SensitiveTextRedactor.clean(input)
    }
}
