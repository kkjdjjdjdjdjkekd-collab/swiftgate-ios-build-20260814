import SwiftUI

extension VPNConnectionState {
    var statusColor: Color {
        switch self {
        case .connected:
            return .green
        case .connecting, .reasserting, .disconnecting:
            return .orange
        case .invalid, .unavailable:
            return .red
        case .disconnected:
            return .secondary
        }
    }

    var statusSymbol: String {
        switch self {
        case .connected:
            return "checkmark.shield.fill"
        case .connecting, .reasserting:
            return "arrow.triangle.2.circlepath"
        case .disconnecting:
            return "pause.circle.fill"
        case .invalid, .unavailable:
            return "exclamationmark.triangle.fill"
        case .disconnected:
            return "shield.slash.fill"
        }
    }

    var connectionActionTitle: String {
        switch self {
        case .connected:
            return "断开连接"
        case .connecting:
            return "正在连接…"
        case .reasserting:
            return "正在恢复…"
        case .disconnecting:
            return "正在断开…"
        case .invalid:
            return "完成配置后连接"
        case .unavailable:
            return "VPN 暂不可用"
        case .disconnected:
            return "连接"
        }
    }

    var canToggleConnection: Bool {
        switch self {
        case .connected, .disconnected:
            return true
        case .connecting, .reasserting, .disconnecting, .invalid, .unavailable:
            return false
        }
    }
}
