#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

for plist in Config/*.plist Config/*.entitlements; do
  plutil -lint "$plist"
done

bash "$ROOT/Scripts/generate-project.sh"

xcodebuild \
  -project SwiftGateiOS.xcodeproj \
  -scheme SwiftGate \
  -configuration Debug \
  -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  CODE_SIGNING_ALLOWED=NO \
  test
