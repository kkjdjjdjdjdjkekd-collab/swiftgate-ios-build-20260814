#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "SwiftGate iOS projects must be generated on macOS." >&2
  exit 1
fi

if ! command -v xcodegen >/dev/null 2>&1; then
  echo "XcodeGen is required. Install it with: brew install xcodegen" >&2
  exit 1
fi

if [[ -d Frameworks/Libbox.xcframework && \
      -d .build/core/sing-box-for-apple/Library && \
      -f .build/core/sing-box-for-apple/Localizable.xcstrings ]]; then
  echo "Generating the real tunnel project with the embedded core..."
  xcodegen generate --spec project-with-core.yml
else
  echo "Generating the UI-only project. Run Scripts/prepare-core.sh for a real tunnel build."
  xcodegen generate --spec project.yml
fi

echo "Generated: $ROOT/SwiftGateiOS.xcodeproj"
