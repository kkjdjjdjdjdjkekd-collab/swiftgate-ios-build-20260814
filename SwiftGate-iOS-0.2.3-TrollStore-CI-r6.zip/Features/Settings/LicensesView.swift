import SwiftUI

struct LicensesView: View {
    private let documents = [
        LicenseDocument(name: "sing-box / Apple bridge", resource: "GPL-3.0"),
        LicenseDocument(name: "Yams / LibYAML", resource: "Yams-MIT"),
    ]

    var body: some View {
        List(documents) { document in
            NavigationLink(document.name) {
                LicenseDocumentView(document: document)
            }
        }
        .navigationTitle("第三方许可")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct LicenseDocument: Identifiable {
    let name: String
    let resource: String
    var id: String { resource }

    var contents: String {
        guard let url = Bundle.main.url(forResource: resource, withExtension: "txt"),
              let text = try? String(contentsOf: url, encoding: .utf8)
        else { return "许可文件未包含在当前构建中。" }
        return text
    }
}

private struct LicenseDocumentView: View {
    let document: LicenseDocument

    var body: some View {
        ScrollView {
            Text(document.contents)
                .font(.caption.monospaced())
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
        }
        .navigationTitle(document.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

