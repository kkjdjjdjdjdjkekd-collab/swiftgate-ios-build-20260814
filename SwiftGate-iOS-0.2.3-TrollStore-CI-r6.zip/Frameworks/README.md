# Embedded core

This directory intentionally contains no binary core in source archives.

On a Mac, run `Scripts/prepare-core.sh`. It creates `Libbox.xcframework` from
the pinned official sing-box source and writes `SOURCE-REVISIONS.txt`.

The official Apple bridge is compiled directly from the pinned
`.build/core/sing-box-for-apple/Library` sources. This keeps all required Swift
package modules in the Packet Tunnel target and avoids an incomplete prebuilt
bridge framework.
