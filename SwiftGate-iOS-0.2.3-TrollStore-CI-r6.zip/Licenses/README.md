# Third-party source and license obligations

The real packet tunnel build uses these upstream projects:

- sing-box: <https://github.com/SagerNet/sing-box>
- sing-box-for-apple: <https://github.com/SagerNet/sing-box-for-apple>

Both are distributed under GPL-3.0. Their full GPL-3.0 license text is included
beside this file. Before any TestFlight, App Store, or other distribution, ship
the complete corresponding source, the exact revision record, build scripts,
local modifications, and all required notices. Obtain a license/legal review for
Apple distribution terms before public release.

The app also uses Yams and its bundled LibYAML parser under the MIT license:
<https://github.com/jpsim/Yams>. Include its exact resolved source revision and
license notice in distributed builds.
