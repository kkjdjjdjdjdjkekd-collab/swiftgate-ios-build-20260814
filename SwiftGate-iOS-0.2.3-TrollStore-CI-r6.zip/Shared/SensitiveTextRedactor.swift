import Foundation

/// Shared by the app and Packet Tunnel extension so a failure is sanitized
/// before it is written and again before it is displayed.
enum SensitiveTextRedactor {
    private static let replacements: [(pattern: String, replacement: String)] = [
        (
            #"(?i)\b(vless|vmess|trojan|ss|hysteria2|hy2|tuic)://[^\s<>\"']+"#,
            "$1://<redacted>"
        ),
        (
            #"(?i)\b(https?://[^\s?#\"'<>]+(?:/[^\s?#\"'<>]*)?)\?[^\s\"'<>]*"#,
            "$1?<redacted>"
        ),
        (
            #"(?i)\b([a-z][a-z0-9+.-]*://)([^/@\s]+)@"#,
            "$1<credentials>@"
        ),
        (
            #"(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+"#,
            "$1 <redacted>"
        ),
        (
            #"(?i)(\"?\b(?:uuid|password|passwd|token|secret|authorization|api[-_]?key|credential|id)\b\"?\s*[:=]\s*)(?:\"[^\"]*\"|'[^']*'|[^\s,;}\]]+)"#,
            "$1<redacted>"
        ),
        (
            #"(?i)(\"?\b(?:server|address|host)\b\"?\s*:\s*)\"[^\"]+\""#,
            "$1\"<redacted>\""
        ),
        (
            #"(?i)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"#,
            "<uuid>"
        ),
    ]

    static func clean(_ input: String) -> String {
        replacements.reduce(input) { value, replacement in
            guard let expression = try? NSRegularExpression(pattern: replacement.pattern) else {
                return value
            }
            let range = NSRange(value.startIndex..., in: value)
            return expression.stringByReplacingMatches(
                in: value,
                range: range,
                withTemplate: replacement.replacement
            )
        }
    }

    /// Produces a useful, bounded error description without dumping userInfo,
    /// which may contain a complete proxy configuration. Including the domain
    /// and code lets us distinguish signing, provider and core failures while
    /// the redactor still removes credentials from human-readable messages.
    static func failureMessage(_ error: Error) -> String {
        var messages: [String] = []
        var current: NSError? = error as NSError

        for _ in 0..<3 {
            guard let value = current else { break }
            let description = clean(value.localizedDescription)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let identifier = "\(clean(value.domain)):\(value.code)"
            let line = description.isEmpty ? identifier : "\(description) [\(identifier)]"
            if !messages.contains(line) { messages.append(line) }
            current = value.userInfo[NSUnderlyingErrorKey] as? NSError
        }

        let result = messages.joined(separator: " → ")
        return String((result.isEmpty ? "未知隧道错误" : result).prefix(1_000))
    }
}
