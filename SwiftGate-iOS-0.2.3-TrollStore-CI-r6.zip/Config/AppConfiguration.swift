import Foundation

enum AppConfiguration {
    static var appGroupIdentifier: String {
        Bundle.main.object(forInfoDictionaryKey: "AppGroupIdentifier") as? String
            ?? "group.com.swiftgate.shared"
    }

    static var tunnelBundleIdentifier: String {
        "\(Bundle.main.bundleIdentifier ?? "com.swiftgate.ios").PacketTunnel"
    }

    static var keychainService: String {
        "\(Bundle.main.bundleIdentifier ?? "com.swiftgate.ios").secrets"
    }
    static let activeConfigurationFile = "active.json"
    static let settingsFile = "settings.json"
    static let tunnelStateFile = "tunnel-state.json"

    static var sharedContainerURL: URL? {
        FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: appGroupIdentifier
        )
    }

    static var isSharedContainerAvailable: Bool {
        sharedContainerURL != nil
    }

    /// TrollStore and ad-hoc signing tools may strip or rewrite the App Group
    /// entitlement. The main app must still be able to launch so it can explain
    /// the missing capability instead of terminating before the first screen.
    static var storageContainerURL: URL {
        if let sharedContainerURL {
            return sharedContainerURL
        }

        let baseURL = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first ?? FileManager.default.temporaryDirectory
        let fallbackURL = baseURL.appendingPathComponent("SwiftGate", isDirectory: true)
        try? FileManager.default.createDirectory(
            at: fallbackURL,
            withIntermediateDirectories: true
        )
        return fallbackURL
    }
}
