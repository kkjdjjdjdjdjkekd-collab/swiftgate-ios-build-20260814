#if SWIFTGATE_EMBEDDED_CORE
import Foundation

final class PacketTunnelProvider: ExtensionProvider {
    override func startTunnel(options: [String: NSObject]?) async throws {
        guard TunnelFailureStore.sharedContainerURL != nil else {
            throw NSError(
                domain: "com.swiftgate.ios.PacketTunnel",
                code: 2,
                userInfo: [
                    NSLocalizedDescriptionKey:
                        "App Group 共享容器不可用，请在 TrollStore 中重新安装保留权限的安装包。",
                ]
            )
        }

        TunnelFailureStore.clear()
        do {
            try await super.startTunnel(options: options)
            TunnelFailureStore.clear()
        } catch {
            TunnelFailureStore.save(error)
            throw error
        }
    }
}
#else
import Foundation
import NetworkExtension

final class PacketTunnelProvider: NEPacketTunnelProvider {
    override func startTunnel(options: [String: NSObject]?) async throws {
        throw NSError(
            domain: "com.swiftgate.ios.PacketTunnel",
            code: 1,
            userInfo: [
                NSLocalizedDescriptionKey:
                    "代理核心尚未嵌入。请在 Mac 上运行 Scripts/prepare-core.sh 后重新生成工程。",
            ]
        )
    }

    override func stopTunnel(with reason: NEProviderStopReason) async {}

    override func handleAppMessage(_ messageData: Data) async -> Data? {
        Data("代理核心尚未嵌入".utf8)
    }
}
#endif

private enum TunnelFailureStore {
    private static let appGroupIdentifier =
        Bundle.main.object(forInfoDictionaryKey: "AppGroupIdentifier") as? String
            ?? "group.com.swiftgate.shared"
    private static let fileName = "tunnel-last-error.txt"

    static var sharedContainerURL: URL? {
        FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: appGroupIdentifier
        )
    }

    static func clear() {
        guard let url = sharedContainerURL?.appendingPathComponent(fileName) else { return }
        try? FileManager.default.removeItem(at: url)
    }

    static func save(_ error: Error) {
        guard let url = sharedContainerURL?.appendingPathComponent(fileName) else { return }
        let message = SensitiveTextRedactor.failureMessage(error)
        let data = Data(message.prefix(1_000).utf8)
        do {
            try data.write(to: url, options: [.atomic, .completeFileProtection])
            try FileManager.default.setAttributes(
                [.protectionKey: FileProtectionType.complete],
                ofItemAtPath: url.path
            )
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            var protectedURL = url
            try? protectedURL.setResourceValues(values)
        } catch {
            try? FileManager.default.removeItem(at: url)
        }
    }
}
