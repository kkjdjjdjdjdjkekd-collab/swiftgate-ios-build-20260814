import NetworkExtension

enum VPNConnectionState: String, Codable, Sendable {
    case unavailable
    case disconnected
    case connecting
    case connected
    case reasserting
    case disconnecting
    case invalid

    init(_ status: NEVPNStatus, reasserting: Bool = false) {
        if reasserting, status == .connected {
            self = .reasserting
            return
        }
        switch status {
        case .invalid: self = .invalid
        case .disconnected: self = .disconnected
        case .connecting: self = .connecting
        case .connected: self = .connected
        case .reasserting: self = .reasserting
        case .disconnecting: self = .disconnecting
        @unknown default: self = .unavailable
        }
    }

    var title: String {
        switch self {
        case .unavailable: "不可用"
        case .disconnected: "未连接"
        case .connecting: "正在连接"
        case .connected: "已连接"
        case .reasserting: "正在恢复"
        case .disconnecting: "正在断开"
        case .invalid: "需要配置"
        }
    }

    var isBusy: Bool {
        self == .connecting || self == .disconnecting || self == .reasserting
    }
}

