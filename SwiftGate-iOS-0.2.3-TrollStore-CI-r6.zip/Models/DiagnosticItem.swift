import Foundation

struct DiagnosticItem: Identifiable, Codable, Sendable {
    let id: UUID
    let name: String
    let passed: Bool
    let message: String

    init(id: UUID = UUID(), name: String, passed: Bool, message: String) {
        self.id = id
        self.name = name
        self.passed = passed
        self.message = message
    }
}

