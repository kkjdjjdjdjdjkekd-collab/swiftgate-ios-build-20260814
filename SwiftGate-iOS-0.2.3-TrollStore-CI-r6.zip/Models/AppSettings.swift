import Foundation

enum RoutingMode: String, Codable, CaseIterable, Identifiable, Sendable {
    case rule
    case global
    case direct

    var id: String { rawValue }
    var title: String {
        switch self {
        case .rule: "智能分流"
        case .global: "全局代理"
        case .direct: "直连"
        }
    }
}

struct AppSettings: Codable, Equatable, Sendable {
    var routingMode: RoutingMode = .rule
    var preferredNodeID: UUID?
    var autoSwitchEnabled = false
    var updateIntervalHours = 12
    var subscriptionURLKey: String?
    var lastSubscriptionUpdateAt: Date?

    init() {}

    private enum CodingKeys: String, CodingKey {
        case routingMode
        case preferredNodeID
        case autoSwitchEnabled
        case updateIntervalHours
        case subscriptionURLKey
        case lastSubscriptionUpdateAt
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        routingMode = try values.decodeIfPresent(RoutingMode.self, forKey: .routingMode) ?? .rule
        preferredNodeID = try values.decodeIfPresent(UUID.self, forKey: .preferredNodeID)
        autoSwitchEnabled = try values.decodeIfPresent(Bool.self, forKey: .autoSwitchEnabled) ?? false
        updateIntervalHours = try values.decodeIfPresent(Int.self, forKey: .updateIntervalHours) ?? 12
        subscriptionURLKey = try values.decodeIfPresent(String.self, forKey: .subscriptionURLKey)
        lastSubscriptionUpdateAt = try values.decodeIfPresent(Date.self, forKey: .lastSubscriptionUpdateAt)
    }

    func encode(to encoder: Encoder) throws {
        var values = encoder.container(keyedBy: CodingKeys.self)
        try values.encode(routingMode, forKey: .routingMode)
        try values.encodeIfPresent(preferredNodeID, forKey: .preferredNodeID)
        try values.encode(autoSwitchEnabled, forKey: .autoSwitchEnabled)
        try values.encode(updateIntervalHours, forKey: .updateIntervalHours)
        try values.encodeIfPresent(subscriptionURLKey, forKey: .subscriptionURLKey)
        try values.encodeIfPresent(lastSubscriptionUpdateAt, forKey: .lastSubscriptionUpdateAt)
    }
}

struct StoredConfiguration: Codable, Sendable {
    var nodes: [ProxyNode] = []
    var settings = AppSettings()
    var updatedAt = Date()
}
