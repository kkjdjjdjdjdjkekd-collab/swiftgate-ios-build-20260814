import Foundation

enum ProxyProtocol: String, Codable, CaseIterable, Sendable {
    case vless
    case vmess
    case trojan
    case shadowsocks
    case hysteria2
    case tuic
}

struct ProxyNode: Identifiable, Codable, Hashable, Sendable {
    var id: UUID
    var name: String
    var type: ProxyProtocol
    var server: String
    var port: UInt16
    var credential: String
    var transport: String?
    var tls: Bool
    var serverName: String?
    var host: String?
    var path: String?
    var query: [String: String]
    var tcpLatencyMilliseconds: Int?

    init(
        id: UUID = UUID(),
        name: String,
        type: ProxyProtocol,
        server: String,
        port: UInt16,
        credential: String,
        transport: String? = nil,
        tls: Bool = false,
        serverName: String? = nil,
        host: String? = nil,
        path: String? = nil,
        query: [String: String] = [:],
        tcpLatencyMilliseconds: Int? = nil
    ) {
        self.id = id
        self.name = name
        self.type = type
        self.server = server
        self.port = port
        self.credential = credential
        self.transport = transport
        self.tls = tls
        self.serverName = serverName
        self.host = host
        self.path = path
        self.query = query
        self.tcpLatencyMilliseconds = tcpLatencyMilliseconds
    }

    var stableIdentity: String {
        "\(type.rawValue)|\(server.lowercased())|\(port)|\(credential.lowercased())"
    }
}

