import XCTest
@testable import SwiftGate

final class SwiftGateCoreTests: XCTestCase {
    func testGivenVLESSLinkPreservesWebSocketTLSFields() throws {
        let link = "vless://00000000-0000-4000-8000-000000000001@edge.example.com:443?encryption=none&security=tls&sni=edge.example.com&fp=chrome&type=ws&host=edge.example.com&path=%2F#edgetunnel"
        let node = try XCTUnwrap(ShareLinkParser().parse(link).nodes.first)

        XCTAssertEqual(node.name, "edgetunnel")
        XCTAssertEqual(node.type, .vless)
        XCTAssertEqual(node.server, "edge.example.com")
        XCTAssertEqual(node.port, 443)
        XCTAssertEqual(node.transport, "ws")
        XCTAssertEqual(node.path, "/")
        XCTAssertEqual(node.serverName, "edge.example.com")
        XCTAssertEqual(node.host, "edge.example.com")
        XCTAssertEqual(node.query["fp"], "chrome")
    }

    func testDuplicateLinksAreDeduplicated() throws {
        let link = "trojan://password@example.com:443?security=tls#node"
        let result = try ShareLinkParser().parse("\(link)\n\(link)")

        XCTAssertEqual(result.nodes.count, 1)
        XCTAssertEqual(result.duplicateCount, 1)
    }

    func testUnsupportedKCPIsRejectedClearly() {
        XCTAssertThrowsError(
            try ShareLinkParser().parse("vless://00000000-0000-0000-0000-000000000001@example.com:443?type=kcp#node")
        )
    }

    func testClashYAMLImportsCommonVLESSWebSocketNode() throws {
        let yaml = """
        proxies:
          - name: example
            type: vless
            server: edge.example.com
            port: 443
            uuid: 00000000-0000-4000-8000-000000000001
            network: ws
            tls: true
            servername: edge.example.com
            client-fingerprint: chrome
            ws-opts:
              path: /
              headers:
                Host: edge.example.com
        proxy-groups:
          - name: PROXY
            type: select
            proxies: [example]
        """

        let node = try XCTUnwrap(ClashYAMLParser().parse(yaml).nodes.first)
        XCTAssertEqual(node.type, .vless)
        XCTAssertEqual(node.transport, "ws")
        XCTAssertEqual(node.host, "edge.example.com")
        XCTAssertEqual(node.query["fp"], "chrome")
    }

    func testRuntimeUsesSelectedNodeAndPrivateNetworkBypass() throws {
        let node = ProxyNode(
            name: "test",
            type: .vless,
            server: "example.com",
            port: 443,
            credential: "00000000-0000-0000-0000-000000000001",
            transport: "ws",
            tls: true,
            path: "/"
        )
        var settings = AppSettings()
        settings.preferredNodeID = node.id
        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [node], settings: settings)
        )

        XCTAssertTrue(runtime.contains("\"type\":\"tun\""))
        XCTAssertTrue(runtime.contains("\"ip_is_private\":true"))
        XCTAssertTrue(runtime.contains("\"auto_detect_interface\":true"))
        XCTAssertTrue(runtime.contains("\"default_domain_resolver\""))
        XCTAssertTrue(runtime.contains("\"server\":\"local\""))
        XCTAssertTrue(runtime.contains("\"strategy\":\"prefer_ipv4\""))
        XCTAssertFalse(runtime.contains("\"mtu\":1500"))
        XCTAssertFalse(runtime.contains("172.16.0.0/12"))
        XCTAssertFalse(runtime.contains("fc00::/7"))
        XCTAssertTrue(runtime.contains("\"action\":\"hijack-dns\""))
        XCTAssertTrue(runtime.contains("\"action\":\"sniff\""))
    }

    func testDirectModeCanStartWithoutAnyProxyNode() throws {
        var settings = AppSettings()
        settings.routingMode = .direct
        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [], settings: settings)
        )

        XCTAssertTrue(runtime.contains("\"final\":\"direct\""))
        XCTAssertTrue(runtime.contains("\"hijack-dns\""))
    }

    func testGlobalModeStillBypassesPrivateNetworks() throws {
        let node = ProxyNode(
            name: "global",
            type: .trojan,
            server: "global.example.com",
            port: 443,
            credential: "secret",
            tls: true
        )
        var settings = AppSettings()
        settings.routingMode = .global
        settings.preferredNodeID = node.id

        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [node], settings: settings)
        )

        XCTAssertTrue(runtime.contains("\"ip_is_private\":true"))
        XCTAssertTrue(runtime.contains("\"outbound\":\"direct\""))
        XCTAssertTrue(runtime.contains("\"final\":\"node-"))
    }

    func testRuntimeOnlyIncludesSelectedNodeAndNoRemovedBlockOutbound() throws {
        let selected = ProxyNode(
            name: "selected",
            type: .vless,
            server: "selected.example.com",
            port: 443,
            credential: "00000000-0000-4000-8000-000000000001",
            transport: "ws",
            tls: true,
            path: "/"
        )
        let unused = ProxyNode(
            name: "unused",
            type: .trojan,
            server: "unused.example.com",
            port: 443,
            credential: "secret",
            tls: true
        )
        var settings = AppSettings()
        settings.preferredNodeID = selected.id

        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [selected, unused], settings: settings)
        )

        XCTAssertTrue(runtime.contains("selected.example.com"))
        XCTAssertFalse(runtime.contains("unused.example.com"))
        XCTAssertFalse(runtime.contains("\"type\":\"block\""))
        XCTAssertTrue(runtime.contains("\"cache_capacity\":4096"))
    }

    func testRuntimePreservesUserRequestedFastTransportOptions() throws {
        let node = ProxyNode(
            name: "tuic",
            type: .tuic,
            server: "tuic.example.com",
            port: 443,
            credential: "00000000-0000-4000-8000-000000000001",
            tls: true,
            query: [
                "password": "secret",
                "congestion_control": "bbr",
                "udp_relay_mode": "native",
                "heartbeat": "10s",
                "alpn": "h3",
            ]
        )
        var settings = AppSettings()
        settings.preferredNodeID = node.id

        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [node], settings: settings)
        )

        XCTAssertTrue(runtime.contains("\"congestion_control\":\"bbr\""))
        XCTAssertTrue(runtime.contains("\"udp_relay_mode\":\"native\""))
        XCTAssertTrue(runtime.contains("\"heartbeat\":\"10s\""))
        XCTAssertTrue(runtime.contains("\"alpn\":[\"h3\"]"))
    }

    func testTunnelPayloadRoundTrip() throws {
        let payload = try TunnelPayloadCodec.encode(runtimeConfiguration: "{\"test\":true}")
        let decoded = try TunnelPayloadCodec.decode(payload)

        XCTAssertEqual(decoded["configContent"] as? String, "{\"test\":true}")
    }

    func testRedactorRemovesCredentials() {
        let unsafe = """
        vless://00000000-0000-4000-8000-000000000001@example.com:443?token=secret
        https://subscription.example.com/api/list?token=query-secret&user=alice
        https://alice:authority-secret@example.com/status
        Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.payload.signature
        password=plain-secret api_key='api-secret'
        {"server":"private.example.com","uuid":"00000000-0000-4000-8000-000000000002"}
        """
        let safe = Redactor.clean(unsafe)

        XCTAssertFalse(safe.contains("00000000-0000-4000-8000-000000000001"))
        XCTAssertFalse(safe.contains("00000000-0000-4000-8000-000000000002"))
        XCTAssertFalse(safe.contains("query-secret"))
        XCTAssertFalse(safe.contains("authority-secret"))
        XCTAssertFalse(safe.contains("eyJhbGciOiJIUzI1NiJ9"))
        XCTAssertFalse(safe.contains("plain-secret"))
        XCTAssertFalse(safe.contains("api-secret"))
        XCTAssertFalse(safe.contains("private.example.com"))
    }

    func testFailureMessageIncludesErrorIdentityAndRedactsUnderlyingError() {
        let underlying = NSError(
            domain: "Libbox.Start",
            code: 23,
            userInfo: [
                NSLocalizedDescriptionKey:
                    "invalid vless://00000000-0000-4000-8000-000000000001@example.com:443?token=secret",
            ]
        )
        let error = NSError(
            domain: "NEPacketTunnelProvider",
            code: 5,
            userInfo: [
                NSLocalizedDescriptionKey: "provider failed",
                NSUnderlyingErrorKey: underlying,
            ]
        )

        let message = SensitiveTextRedactor.failureMessage(error)

        XCTAssertTrue(message.contains("NEPacketTunnelProvider:5"))
        XCTAssertTrue(message.contains("Libbox.Start:23"))
        XCTAssertFalse(message.contains("00000000-0000-4000-8000-000000000001"))
        XCTAssertFalse(message.contains("token=secret"))
    }
}
