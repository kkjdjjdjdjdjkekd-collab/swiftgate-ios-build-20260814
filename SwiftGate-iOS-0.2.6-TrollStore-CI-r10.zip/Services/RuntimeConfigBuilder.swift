import Foundation

enum RuntimeConfigurationError: LocalizedError {
    case noNodes
    case preferredNodeMissing
    case unsupportedTransport(String, String)
    case invalidNode(String, String)

    var errorDescription: String? {
        switch self {
        case .noNodes: "请先导入至少一个节点"
        case .preferredNodeMissing: "选择的节点已不在当前配置中"
        case .unsupportedTransport(let name, let transport):
            "节点“\(name)”使用 iPhone 版暂不支持的 \(transport) 传输"
        case .invalidNode(let name, let reason):
            "节点“\(name)”的配置不兼容：\(reason)"
        }
    }
}

enum RuntimeDNSProfile: Sendable, Equatable {
    case local
    case proxiedHTTPS

    var canFallbackToCompatibleDNS: Bool { self == .local }
}

struct RuntimeConfigBuilder: Sendable {
    func validate(_ node: ProxyNode) throws {
        _ = try outbound(node, tag: "validation")
    }

    func build(
        _ stored: StoredConfiguration,
        dnsProfile: RuntimeDNSProfile = .local
    ) throws -> String {
        let preferred: ProxyNode?
        if stored.settings.routingMode == .direct {
            preferred = stored.settings.preferredNodeID.flatMap { selectedID in
                stored.nodes.first(where: { $0.id == selectedID })
            } ?? stored.nodes.first
        } else {
            guard !stored.nodes.isEmpty else { throw RuntimeConfigurationError.noNodes }
            if let id = stored.settings.preferredNodeID {
                guard let selected = stored.nodes.first(where: { $0.id == id }) else {
                    throw RuntimeConfigurationError.preferredNodeMissing
                }
                preferred = selected
            } else {
                preferred = stored.nodes[0]
            }
        }

        // Only the selected outbound belongs in the live tunnel. Keeping every imported
        // node here makes first connection and every reload parse credentials that cannot
        // be selected by the current route anyway.
        let configuredNodes = stored.settings.routingMode == .direct ? [] : preferred.map { [$0] } ?? []
        let nodeTags = configuredNodes.map { "node-\($0.id.uuidString.lowercased())" }
        let nodeOutbounds: [[String: Any]] = try configuredNodes.enumerated().map { index, node in
            try outbound(node, tag: nodeTags[index])
        }
        let builtInOutbounds: [[String: Any]] = [["type": "direct", "tag": "direct"]]
        let outbounds = nodeOutbounds + builtInOutbounds
        let preferredTag = preferred.map { "node-\($0.id.uuidString.lowercased())" } ?? "direct"
        // Direct mode deliberately omits every proxy outbound. Keep the actual egress tag
        // separate so DNS and route references can never point at an outbound that was not
        // emitted into this runtime configuration.
        let egressTag = stored.settings.routingMode == .direct ? "direct" : preferredTag

        let routeRules: [[String: Any]]
        let final: String
        let sniffRule: [String: Any] = ["action": "sniff"]
        // Match DNS by its destination port instead of sniffing every connection first.
        // This keeps the synthetic TUN DNS endpoints on the
        // fast path and avoids protocol inspection overhead in direct/global modes.
        let dnsRule: [String: Any] = ["port": 53, "action": "hijack-dns"]
        switch stored.settings.routingMode {
        case .direct:
            routeRules = [dnsRule]
            final = "direct"
        case .global:
            routeRules = [
                dnsRule,
                ["ip_is_private": true, "action": "route", "outbound": "direct"],
            ]
            final = egressTag
        case .rule:
            routeRules = [
                dnsRule,
                ["ip_is_private": true, "action": "route", "outbound": "direct"],
                sniffRule,
                ["domain_suffix": [".cn"], "action": "route", "outbound": "direct"],
            ]
            final = egressTag
        }

        // Resolve the proxy server itself through Apple's current network. The compatibility
        // profile may move application lookups to encrypted DNS carried by the selected
        // egress, while keeping the proxy-server bootstrap outside that dependency cycle.
        var dnsServers: [[String: Any]] = [["type": "local", "tag": "bootstrap"]]
        if dnsProfile == .proxiedHTTPS {
            dnsServers.append([
                "type": "https",
                "tag": "remote",
                "server": "1.1.1.1",
                "server_port": 443,
                "path": "/dns-query",
                "tls": [
                    "enabled": true,
                    "server_name": "cloudflare-dns.com",
                ],
                "detour": egressTag,
            ])
        }
        let dnsFinal = dnsProfile == .proxiedHTTPS ? "remote" : "bootstrap"

        let root: [String: Any] = [
            "log": ["level": "warn", "timestamp": true],
            "dns": [
                "servers": dnsServers,
                "final": dnsFinal,
                "strategy": "prefer_ipv4",
                "cache_capacity": 4096,
            ],
            "inbounds": [[
                "type": "tun",
                "tag": "tun-in",
                "address": ["172.19.0.1/30", "fdfe:dcba:9876::1/126"],
                "dns_mode": "hijack",
                "dns_address": ["172.19.0.2", "fdfe:dcba:9876::2"],
                "mtu": 1500,
                "auto_route": true,
                "strict_route": false,
                "stack": "system",
            ]],
            "outbounds": outbounds,
            "route": [
                "rules": routeRules,
                "final": final,
                "auto_detect_interface": true,
                "default_domain_resolver": [
                    "server": "bootstrap",
                    "strategy": "prefer_ipv4",
                ],
            ],
        ]
        let data = try JSONSerialization.data(withJSONObject: root, options: [.sortedKeys])
        return String(decoding: data, as: UTF8.self)
    }

    private func outbound(_ node: ProxyNode, tag: String) throws -> [String: Any] {
        let rawTransportName = node.transport?.lowercased()
        let transportName: String?
        switch rawTransportName {
        case "h2": transportName = "http"
        case "raw": transportName = "tcp"
        default: transportName = rawTransportName
        }
        let supportedTransports: Set<String?> = [
            nil, "", "tcp", "ws", "http", "httpupgrade", "grpc", "quic",
        ]
        guard supportedTransports.contains(transportName) else {
            let displayName: String
            if let transportName, ["kcp", "mkcp"].contains(transportName) {
                displayName = "mKCP（当前 iOS 内核不支持，请换用同服务的 TCP、WS 或 VLESS 节点）"
            } else {
                displayName = transportName ?? "未知"
            }
            throw RuntimeConfigurationError.unsupportedTransport(node.name, displayName)
        }
        var output: [String: Any] = [
            "type": node.type.rawValue,
            "tag": tag,
            "server": node.server,
            "server_port": Int(node.port),
        ]
        switch node.type {
        case .vless, .vmess:
            output["uuid"] = node.credential
            if node.type == .vmess {
                guard UUID(uuidString: node.credential) != nil else {
                    throw RuntimeConfigurationError.invalidNode(node.name, "VMess UUID 无效")
                }
                let security = (node.query["scy"] ?? "auto").lowercased()
                let supportedSecurity: Set<String> = [
                    "auto", "none", "zero", "aes-128-ctr", "aes-128-gcm", "chacha20-poly1305",
                ]
                guard supportedSecurity.contains(security) else {
                    throw RuntimeConfigurationError.invalidNode(node.name, "VMess 加密方式 \(security) 不受内核支持")
                }
                guard let alterID = Int(node.query["aid"] ?? "0"), alterID >= 0 else {
                    throw RuntimeConfigurationError.invalidNode(node.name, "alterId 必须是非负整数")
                }
                let headerType = (
                    firstQueryValue(node.query, keys: ["vmess_header_type", "header_type"]) ?? "none"
                ).lowercased()
                if [nil, "", "tcp"].contains(transportName), !["", "none"].contains(headerType) {
                    throw RuntimeConfigurationError.unsupportedTransport(
                        node.name,
                        "VMess TCP \(headerType) 伪装"
                    )
                }
                if transportName == "quic", !node.tls {
                    throw RuntimeConfigurationError.invalidNode(
                        node.name,
                        "此内核的 QUIC 传输必须启用 TLS"
                    )
                }
                if transportName == "quic" {
                    let quicSecurity = node.host?.lowercased()
                    if (![nil, "", "none"].contains(quicSecurity)
                        || node.path?.isEmpty == false
                        || !["", "none"].contains(headerType)) {
                        throw RuntimeConfigurationError.invalidNode(
                            node.name,
                            "固定内核不兼容 Xray QUIC 附加加密或伪装"
                        )
                    }
                }
                output["security"] = security
                output["alter_id"] = alterID
                if let value = runtimeBoolean(node.query["global_padding"]) {
                    output["global_padding"] = value
                }
                if let value = runtimeBoolean(node.query["authenticated_length"]) {
                    output["authenticated_length"] = value
                }
                if let networkValue = firstQueryValue(node.query, keys: ["network"]) {
                    let networks = networkValue
                        .split(separator: ",")
                        .map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
                        .filter { !$0.isEmpty }
                    guard !networks.isEmpty,
                          networks.allSatisfy({ ["tcp", "udp"].contains($0) }) else {
                        throw RuntimeConfigurationError.invalidNode(
                            node.name,
                            "network 只能是 tcp、udp 或二者"
                        )
                    }
                    if networks.count == 1 {
                        output["network"] = networks[0]
                    } else {
                        output["network"] = networks
                    }
                }
            }
            if node.type == .vless,
               let flow = node.query["flow"],
               !flow.isEmpty {
                output["flow"] = flow
            }
            if let packetEncoding = firstQueryValue(
                node.query,
                keys: ["packetencoding", "packet_encoding", "packet-encoding"]
            ), !packetEncoding.isEmpty {
                let normalized = packetEncoding.lowercased()
                guard ["packetaddr", "xudp"].contains(normalized) else {
                    throw RuntimeConfigurationError.invalidNode(
                        node.name,
                        "UDP 编码 \(normalized) 不受内核支持"
                    )
                }
                output["packet_encoding"] = normalized
            }
        case .trojan, .hysteria2:
            output["password"] = node.credential
        case .tuic:
            output["uuid"] = node.credential
            output["password"] = node.query["password"] ?? node.credential
        case .shadowsocks:
            output["method"] = node.query["method"] ?? "aes-128-gcm"
            output["password"] = node.credential
        }
        if node.tls {
            var tls: [String: Any] = ["enabled": true]
            tls["server_name"] = node.serverName ?? node.host ?? node.server
            let insecureValue = firstQueryValue(
                node.query,
                keys: ["allowinsecure", "allow_insecure", "insecure", "skip-cert-verify"]
            )?.lowercased() ?? ""
            if ["1", "true", "yes"].contains(insecureValue) {
                tls["insecure"] = true
            }
            if let fingerprint = node.query["fp"], !fingerprint.isEmpty {
                tls["utls"] = ["enabled": true, "fingerprint": fingerprint]
            }
            if let alpn = firstQueryValue(node.query, keys: ["alpn"]), !alpn.isEmpty {
                let protocols = alpn
                    .split(separator: ",")
                    .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }
                if !protocols.isEmpty { tls["alpn"] = protocols }
            }
            if node.query["security"]?.lowercased() == "reality",
               let publicKey = node.query["pbk"], !publicKey.isEmpty {
                tls["reality"] = [
                    "enabled": true,
                    "public_key": publicKey,
                    "short_id": node.query["sid"] ?? "",
                ]
            }
            output["tls"] = tls
        }
        if node.transport?.lowercased() == "ws" {
            var transport: [String: Any] = ["type": "ws", "path": node.path ?? "/"]
            if let host = node.host, !host.isEmpty { transport["headers"] = ["Host": host] }
            if let earlyData = firstQueryValue(
                node.query,
                keys: ["ed", "max_early_data", "max-early-data"]
            ).flatMap(Int.init), earlyData > 0 {
                transport["max_early_data"] = earlyData
                if let header = firstQueryValue(
                    node.query,
                    keys: ["eh", "early_data_header_name", "early-data-header-name"]
                ), !header.isEmpty {
                    transport["early_data_header_name"] = header
                }
            }
            output["transport"] = transport
        } else if let transportName, ["http", "httpupgrade", "grpc"].contains(transportName) {
            var transport: [String: Any] = ["type": transportName]
            if let host = node.host, !host.isEmpty {
                let hosts = host
                    .split(separator: ",")
                    .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }
                if !hosts.isEmpty {
                    transport["host"] = transportName == "httpupgrade" ? hosts[0] : hosts
                }
            }
            if let path = node.path, !path.isEmpty {
                if transportName == "grpc" {
                    transport["service_name"] = path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                } else {
                    transport["path"] = path
                }
            }
            output["transport"] = transport
        } else if transportName == "quic" {
            output["transport"] = ["type": "quic"]
        }
        if node.type == .hysteria2 {
            if let obfs = node.query["obfs"], !obfs.isEmpty {
                output["obfs"] = ["type": obfs, "password": node.query["obfs-password"] ?? ""]
            }
            if let up = Int(node.query["upmbps"] ?? "") { output["up_mbps"] = up }
            if let down = Int(node.query["downmbps"] ?? "") { output["down_mbps"] = down }
        }
        if node.type == .tuic {
            if let congestion = firstQueryValue(
                node.query,
                keys: ["congestion_control", "congestion-control"]
            ), !congestion.isEmpty {
                output["congestion_control"] = congestion
            }
            if let relayMode = firstQueryValue(
                node.query,
                keys: ["udp_relay_mode", "udp-relay-mode"]
            ), !relayMode.isEmpty {
                output["udp_relay_mode"] = relayMode
            }
            if let heartbeat = firstQueryValue(node.query, keys: ["heartbeat"]), !heartbeat.isEmpty {
                output["heartbeat"] = heartbeat
            }
        }
        if node.type == .shadowsocks, let plugin = node.query["plugin"], !plugin.isEmpty {
            let parts = plugin.split(separator: ";", maxSplits: 1).map(String.init)
            output["plugin"] = parts[0]
            if parts.count > 1 { output["plugin_opts"] = parts[1] }
        }
        return output
    }

    private func firstQueryValue(_ query: [String: String], keys: [String]) -> String? {
        for key in keys {
            if let value = query[key], !value.isEmpty { return value }
        }
        return nil
    }

    private func runtimeBoolean(_ value: String?) -> Bool? {
        switch value?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
        case "1", "true", "yes", "on": return true
        case "0", "false", "no", "off": return false
        default: return nil
        }
    }
}
