import Foundation
import Network
import Darwin

actor LatencyService {
    private let httpSession: URLSession
    private let tcpQueue = DispatchQueue(
        label: "SwiftGate.Latency.TCP",
        qos: .userInitiated,
        attributes: .concurrent
    )

    init() {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 8
        configuration.timeoutIntervalForResource = 10
        httpSession = URLSession(configuration: configuration)
    }

    func test(_ node: ProxyNode, timeout: TimeInterval = 5) async throws -> Int {
        // Match the desktop definition: resolve first, then time only the TCP handshake.
        // Racing the resolved addresses also avoids a slow first address dominating the
        // displayed value on dual-stack or multi-CDN networks.
        let addresses = try await resolveAddresses(
            host: node.server,
            timeout: min(timeout, 3)
        )
        try Task.checkCancellation()
        return try await measureFirstReady(
            addresses: addresses,
            port: node.port,
            timeout: timeout
        )
    }

    func testCurrentTunnel(timeout: TimeInterval = 8) async throws -> Int {
        let urls = [
            URL(string: "https://cp.cloudflare.com/generate_204")!,
            URL(string: "https://www.gstatic.com/generate_204")!,
        ]
        var lastError: Error = URLError(.cannotConnectToHost)
        for url in urls {
            try Task.checkCancellation()
            do {
                return try await measureHTTP(url, timeout: timeout)
            } catch {
                if Self.isCancellation(error) { throw CancellationError() }
                lastError = error
            }
        }
        try Task.checkCancellation()
        throw lastError
    }

    /// Returns a stable end-to-end HTTPS response measurement. The first request may
    /// include a cold DNS/TCP/TLS setup, so three samples and a median describe normal
    /// page loading more honestly than a single cold value.
    func testStableCurrentTunnel(
        timeout: TimeInterval = 5,
        samples: Int = 3
    ) async throws -> Int {
        let sampleCount = max(1, samples)
        var values: [Int] = []
        var lastError: Error = URLError(.cannotConnectToHost)
        for _ in 0..<sampleCount {
            try Task.checkCancellation()
            do {
                values.append(try await testCurrentTunnel(timeout: timeout))
            } catch {
                if Self.isCancellation(error) { throw CancellationError() }
                lastError = error
            }
        }
        try Task.checkCancellation()
        guard values.count >= (sampleCount / 2 + 1) else { throw lastError }
        return Self.median(values)
    }

    /// Sends a real DNS packet to the synthetic DNS endpoint installed on the TUN. The
    /// random subdomain avoids passing from a stale process/core cache. NOERROR and
    /// NXDOMAIN both prove that the DNS request crossed the tunnel and got a response.
    func testTunnelDNS(timeout: TimeInterval = 5) async throws -> Int {
        let nonce = String(UInt64.random(in: 0...UInt64.max), radix: 16)
        return try await measureDNS(
            server: "172.19.0.2",
            hostname: "swiftgate-\(nonce).cloudflare.com",
            timeout: timeout
        )
    }

    static func median(_ values: [Int]) -> Int {
        let sorted = values.sorted()
        guard !sorted.isEmpty else { return 0 }
        return sorted[sorted.count / 2]
    }

    /// Verifies that packets can leave the active tunnel without relying on DNS.
    /// A successful VPN status alone only means NetworkExtension accepted the TUN.
    func testTunnelRoute(timeout: TimeInterval = 5) async throws -> Int {
        try await measure(host: "1.1.1.1", port: 443, timeout: timeout)
    }

    private func measureHTTP(_ url: URL, timeout: TimeInterval) async throws -> Int {
        let start = DispatchTime.now().uptimeNanoseconds
        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.timeoutInterval = timeout
        let (_, response) = try await httpSession.data(for: request)
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse, [200, 204].contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        return Int((DispatchTime.now().uptimeNanoseconds - start) / 1_000_000)
    }

    private func resolveAddresses(host: String, timeout: TimeInterval) async throws -> [String] {
        try Task.checkCancellation()
        let attempt = AddressResolutionAttempt()
        let timeoutSeconds = max(0.1, timeout)
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                guard attempt.install(continuation) else { return }
                tcpQueue.async {
                    var result: UnsafeMutablePointer<addrinfo>?
                    let status = host.withCString { hostPointer in
                        getaddrinfo(hostPointer, nil, nil, &result)
                    }
                    defer {
                        if let result { freeaddrinfo(result) }
                    }
                    guard status == 0, let first = result else {
                        _ = attempt.finish(.failure(URLError(.dnsLookupFailed)))
                        return
                    }

                    var addresses: [(family: Int32, value: String)] = []
                    var seen = Set<String>()
                    var cursor: UnsafeMutablePointer<addrinfo>? = first
                    while let current = cursor {
                        let info = current.pointee
                        if (info.ai_family == AF_INET || info.ai_family == AF_INET6),
                           let socketAddress = info.ai_addr {
                            var buffer = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                            let nameStatus = buffer.withUnsafeMutableBufferPointer { pointer in
                                getnameinfo(
                                    socketAddress,
                                    info.ai_addrlen,
                                    pointer.baseAddress,
                                    socklen_t(pointer.count),
                                    nil,
                                    0,
                                    NI_NUMERICHOST
                                )
                            }
                            if nameStatus == 0 {
                                let value = String(cString: buffer)
                                if seen.insert(value).inserted {
                                    addresses.append((info.ai_family, value))
                                }
                            }
                        }
                        cursor = info.ai_next
                    }
                    // Prefer IPv4 while keeping IPv6 in the first racing batch. Grouping
                    // every A record before every AAAA record can falsely fail on NAT64.
                    let ipv4 = addresses.filter { $0.family == AF_INET }.map { $0.value }
                    let ipv6 = addresses.filter { $0.family == AF_INET6 }.map { $0.value }
                    var ordered: [String] = []
                    let pairCount = max(ipv4.count, ipv6.count)
                    for index in 0..<pairCount {
                        if index < ipv4.count { ordered.append(ipv4[index]) }
                        if index < ipv6.count { ordered.append(ipv6[index]) }
                    }
                    guard !ordered.isEmpty else {
                        _ = attempt.finish(.failure(URLError(.dnsLookupFailed)))
                        return
                    }
                    _ = attempt.finish(.success(ordered))
                }
                tcpQueue.asyncAfter(deadline: .now() + timeoutSeconds) {
                    _ = attempt.finish(.failure(URLError(.timedOut)))
                }
            }
        } onCancel: {
            _ = attempt.finish(.failure(CancellationError()))
        }
    }

    private func measureFirstReady(
        addresses: [String],
        port: UInt16,
        timeout: TimeInterval
    ) async throws -> Int {
        let value: Int? = await withTaskGroup(of: Int?.self) { group in
            for address in addresses.prefix(4) {
                group.addTask { [self] in
                    try? await measure(host: address, port: port, timeout: timeout)
                }
            }
            for await result in group {
                if let result {
                    group.cancelAll()
                    return result
                }
            }
            return nil
        }
        try Task.checkCancellation()
        guard let value else { throw URLError(.cannotConnectToHost) }
        return value
    }

    private static func isCancellation(_ error: Error) -> Bool {
        if error is CancellationError { return true }
        return (error as? URLError)?.code == .cancelled
    }

    private func measureDNS(
        server: String,
        hostname: String,
        timeout: TimeInterval
    ) async throws -> Int {
        try Task.checkCancellation()
        let queryID = UInt16.random(in: 0...UInt16.max)
        let query = Self.dnsQuery(id: queryID, hostname: hostname)
        let start = DispatchTime.now().uptimeNanoseconds
        let connection = NWConnection(
            host: NWEndpoint.Host(server),
            port: NWEndpoint.Port(rawValue: 53)!,
            using: .udp
        )
        let attempt = DNSProbeAttempt()
        let timeoutSeconds = max(0.1, timeout)
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                guard attempt.install(continuation) else { return }
                connection.stateUpdateHandler = { state in
                    switch state {
                    case .ready:
                        guard attempt.begin() else { return }
                        connection.send(content: query, completion: .contentProcessed { error in
                            if let error {
                                if attempt.finish(.failure(error)) { connection.cancel() }
                                return
                            }
                            connection.receiveMessage { data, _, _, error in
                                if let error {
                                    if attempt.finish(.failure(error)) { connection.cancel() }
                                    return
                                }
                                guard let data,
                                      Self.isValidDNSResponse(data, expectedID: queryID)
                                else {
                                    if attempt.finish(.failure(URLError(.dnsLookupFailed))) {
                                        connection.cancel()
                                    }
                                    return
                                }
                                let milliseconds = Int(
                                    (DispatchTime.now().uptimeNanoseconds - start) / 1_000_000
                                )
                                if attempt.finish(.success(milliseconds)) { connection.cancel() }
                            }
                        })
                    case .failed(let error):
                        _ = attempt.finish(.failure(error))
                    case .cancelled:
                        _ = attempt.finish(.failure(CancellationError()))
                    default:
                        break
                    }
                }
                tcpQueue.asyncAfter(deadline: .now() + timeoutSeconds) {
                    if attempt.finish(.failure(URLError(.timedOut))) { connection.cancel() }
                }
                connection.start(queue: tcpQueue)
            }
        } onCancel: {
            _ = attempt.finish(.failure(CancellationError()))
            connection.cancel()
        }
    }

    static func dnsQuery(id: UInt16, hostname: String) -> Data {
        var bytes: [UInt8] = [
            UInt8(id >> 8), UInt8(id & 0x00ff),
            0x01, 0x00,
            0x00, 0x01,
            0x00, 0x00,
            0x00, 0x00,
            0x00, 0x00,
        ]
        for label in hostname.split(separator: ".") {
            let encoded = Array(label.utf8.prefix(63))
            bytes.append(UInt8(encoded.count))
            bytes.append(contentsOf: encoded)
        }
        bytes.append(0)
        bytes.append(contentsOf: [0x00, 0x01, 0x00, 0x01])
        return Data(bytes)
    }

    static func isValidDNSResponse(_ data: Data, expectedID: UInt16) -> Bool {
        guard data.count >= 12 else { return false }
        let bytes = [UInt8](data.prefix(12))
        let responseID = UInt16(bytes[0]) << 8 | UInt16(bytes[1])
        let flags = UInt16(bytes[2]) << 8 | UInt16(bytes[3])
        let responseCode = flags & 0x000f
        return responseID == expectedID
            && (flags & 0x8000) != 0
            && (responseCode == 0 || responseCode == 3)
    }

    private func measure(host: String, port: UInt16, timeout: TimeInterval) async throws -> Int {
        try Task.checkCancellation()
        let start = DispatchTime.now().uptimeNanoseconds
        let connection = NWConnection(
            host: NWEndpoint.Host(host),
            port: NWEndpoint.Port(rawValue: port)!,
            using: .tcp
        )
        let attempt = LatencyAttempt()
        let timeoutSeconds = max(0.1, timeout)
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                guard attempt.install(continuation) else { return }
                connection.stateUpdateHandler = { state in
                    switch state {
                    case .ready:
                        let milliseconds = Int(
                            (DispatchTime.now().uptimeNanoseconds - start) / 1_000_000
                        )
                        if attempt.finish(.success(milliseconds)) { connection.cancel() }
                    case .failed(let error):
                        _ = attempt.finish(.failure(error))
                    case .cancelled:
                        _ = attempt.finish(.failure(CancellationError()))
                    default:
                        break
                    }
                }
                tcpQueue.asyncAfter(deadline: .now() + timeoutSeconds) {
                    if attempt.finish(.failure(URLError(.timedOut))) { connection.cancel() }
                }
                connection.start(queue: tcpQueue)
            }
        } onCancel: {
            _ = attempt.finish(.failure(CancellationError()))
            connection.cancel()
        }
    }
}

private final class DNSProbeAttempt: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Int, Error>?
    private var earlyResult: Result<Int, Error>?
    private var started = false
    private var finished = false

    @discardableResult
    func install(_ continuation: CheckedContinuation<Int, Error>) -> Bool {
        lock.lock()
        if finished, let earlyResult {
            lock.unlock()
            continuation.resume(with: earlyResult)
            return false
        }
        self.continuation = continuation
        lock.unlock()
        return true
    }

    func begin() -> Bool {
        lock.lock()
        defer { lock.unlock() }
        guard !started, !finished else { return false }
        started = true
        return true
    }

    @discardableResult
    func finish(_ result: Result<Int, Error>) -> Bool {
        lock.lock()
        guard !finished else {
            lock.unlock()
            return false
        }
        finished = true
        if let continuation {
            self.continuation = nil
            lock.unlock()
            continuation.resume(with: result)
        } else {
            earlyResult = result
            lock.unlock()
        }
        return true
    }
}

private final class AddressResolutionAttempt: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<[String], Error>?
    private var earlyResult: Result<[String], Error>?
    private var finished = false

    @discardableResult
    func install(_ continuation: CheckedContinuation<[String], Error>) -> Bool {
        lock.lock()
        if finished, let earlyResult {
            lock.unlock()
            continuation.resume(with: earlyResult)
            return false
        }
        self.continuation = continuation
        lock.unlock()
        return true
    }

    @discardableResult
    func finish(_ result: Result<[String], Error>) -> Bool {
        lock.lock()
        guard !finished else {
            lock.unlock()
            return false
        }
        finished = true
        if let continuation {
            self.continuation = nil
            lock.unlock()
            continuation.resume(with: result)
            return true
        }
        earlyResult = result
        lock.unlock()
        return true
    }
}

private final class LatencyAttempt: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Int, Error>?
    private var earlyResult: Result<Int, Error>?
    private var finished = false

    @discardableResult
    func install(_ continuation: CheckedContinuation<Int, Error>) -> Bool {
        lock.lock()
        if finished, let earlyResult {
            lock.unlock()
            continuation.resume(with: earlyResult)
            return false
        }
        self.continuation = continuation
        lock.unlock()
        return true
    }

    @discardableResult
    func finish(_ result: Result<Int, Error>) -> Bool {
        lock.lock()
        guard !finished else {
            lock.unlock()
            return false
        }
        finished = true
        if let continuation {
            self.continuation = nil
            lock.unlock()
            continuation.resume(with: result)
        } else {
            earlyResult = result
            lock.unlock()
        }
        return true
    }
}
