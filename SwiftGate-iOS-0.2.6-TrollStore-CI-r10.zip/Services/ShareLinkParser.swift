import Foundation

enum ImportError: LocalizedError {
    case empty
    case unsupported(String)
    case malformed(String)

    var errorDescription: String? {
        switch self {
        case .empty: "没有找到可导入的内容"
        case .unsupported(let value): "暂不支持：\(Redactor.clean(value))"
        case .malformed(let value): "链接格式不正确：\(Redactor.clean(value))"
        }
    }
}

struct ImportResult: Sendable {
    let nodes: [ProxyNode]
    let duplicateCount: Int
    let rejectedCount: Int
}

struct ShareLinkParser: Sendable {
    func parse(_ text: String) throws -> ImportResult {
        let candidates = text
            .split(whereSeparator: { $0.isWhitespace })
            .map(String.init)
            .filter { !$0.isEmpty }
        guard !candidates.isEmpty else { throw ImportError.empty }

        var nodes: [ProxyNode] = []
        var rejected = 0
        var firstError: ImportError?
        for candidate in candidates {
            do {
                nodes.append(try parseLink(candidate))
            } catch let error as ImportError {
                rejected += 1
                if firstError == nil { firstError = error }
            } catch {
                rejected += 1
            }
        }
        guard !nodes.isEmpty else { throw firstError ?? ImportError.unsupported(candidates[0]) }

        var identities = Set<String>()
        var unique: [ProxyNode] = []
        for node in nodes where identities.insert(node.stableIdentity).inserted {
            unique.append(node)
        }
        return ImportResult(
            nodes: unique,
            duplicateCount: nodes.count - unique.count,
            rejectedCount: rejected
        )
    }

    private func parseLink(_ value: String) throws -> ProxyNode {
        guard let scheme = URLComponents(string: value)?.scheme?.lowercased() else {
            throw ImportError.malformed(value)
        }
        if scheme == "vmess" { return try parseVMess(value) }
        if scheme == "ss" { return try parseShadowsocks(value) }
        guard let components = URLComponents(string: value),
              let host = components.host,
              let portValue = components.port,
              let port = UInt16(exactly: portValue),
              port > 0
        else { throw ImportError.malformed(value) }

        let query = Dictionary(
            components.queryItems?.map { ($0.name.lowercased(), $0.value ?? "") } ?? [],
            uniquingKeysWith: { _, last in last }
        )
        if let transport = (query["type"] ?? query["network"])?.lowercased(),
           !["", "tcp", "ws", "http", "httpupgrade", "grpc"].contains(transport) {
            throw ImportError.unsupported("\(scheme.uppercased()) / \(transport)")
        }
        let name = components.fragment?.removingPercentEncoding?.nonEmpty
            ?? "\(scheme.uppercased()) · \(host)"
        let credential = components.user?.removingPercentEncoding ?? ""
        let type: ProxyProtocol
        switch scheme {
        case "vless": type = .vless
        case "trojan": type = .trojan
        case "hysteria2", "hy2": type = .hysteria2
        case "tuic": type = .tuic
        default: throw ImportError.unsupported(scheme)
        }
        guard !credential.isEmpty else { throw ImportError.malformed(value) }
        var normalizedQuery = query
        if type == .tuic,
           let password = components.password?.removingPercentEncoding,
           !password.isEmpty {
            normalizedQuery["password"] = password
        }
        return ProxyNode(
            name: name,
            type: type,
            server: host,
            port: port,
            credential: credential,
            transport: query["type"] ?? query["network"],
            tls: ["tls", "reality"].contains(query["security"]?.lowercased() ?? "")
                || type == .hysteria2 || type == .tuic,
            serverName: query["sni"],
            host: query["host"],
            path: (query["path"] ?? query["servicename"] ?? query["service_name"])?
                .removingPercentEncoding,
            query: normalizedQuery
        )
    }

    private func parseShadowsocks(_ value: String) throws -> ProxyNode {
        let parts = value.split(separator: "#", maxSplits: 1)
        let fragment = parts.count > 1 ? String(parts[1]).removingPercentEncoding : nil
        let withoutFragment = String(parts[0])
        guard var body = withoutFragment.split(separator: ":", maxSplits: 1).dropFirst().first.map(String.init) else {
            throw ImportError.malformed(value)
        }
        body = body.removingLeadingSlashes

        let queryText: String?
        if let index = body.firstIndex(of: "?") {
            queryText = String(body[body.index(after: index)...])
            body = String(body[..<index])
        } else {
            queryText = nil
        }

        let decodedAuthority: String
        if body.contains("@") {
            decodedAuthority = body
        } else if let decoded = Data(base64Encoded: body.base64Padded)
            .flatMap({ String(data: $0, encoding: .utf8) }) {
            decodedAuthority = decoded
        } else {
            throw ImportError.malformed(value)
        }

        guard let at = decodedAuthority.lastIndex(of: "@") else { throw ImportError.malformed(value) }
        var credentials = String(decodedAuthority[..<at])
        let endpoint = String(decodedAuthority[decodedAuthority.index(after: at)...])
        if !credentials.contains(":"),
           let decoded = Data(base64Encoded: credentials.base64Padded)
            .flatMap({ String(data: $0, encoding: .utf8) }) {
            credentials = decoded
        }
        guard let separator = credentials.firstIndex(of: ":") else { throw ImportError.malformed(value) }
        let method = String(credentials[..<separator]).removingPercentEncoding ?? ""
        let password = String(credentials[credentials.index(after: separator)...]).removingPercentEncoding ?? ""
        guard !method.isEmpty, !password.isEmpty,
              let endpointComponents = URLComponents(string: "ss://placeholder@\(endpoint)"),
              let host = endpointComponents.host,
              let portValue = endpointComponents.port,
              let port = UInt16(exactly: portValue),
              port > 0
        else { throw ImportError.malformed(value) }

        var query = Dictionary(
            URLComponents(string: "ss://x.invalid/?\(queryText ?? "")")?.queryItems?
                .map { ($0.name.lowercased(), $0.value ?? "") } ?? [],
            uniquingKeysWith: { _, last in last }
        )
        query["method"] = method
        return ProxyNode(
            name: fragment?.nonEmpty ?? "SS · \(host)",
            type: .shadowsocks,
            server: host,
            port: port,
            credential: password,
            query: query
        )
    }

    private func parseVMess(_ value: String) throws -> ProxyNode {
        guard let rawPayload = value.split(separator: ":", maxSplits: 1).last else {
            throw ImportError.malformed(value)
        }
        let payload = String(rawPayload).removingLeadingSlashes
        guard let data = Data(base64Encoded: payload.base64Padded, options: .ignoreUnknownCharacters),
              let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let host = vmessText(json, keys: ["add", "server"]),
              let id = vmessText(json, keys: ["id", "uuid"]),
              UUID(uuidString: id) != nil,
              let portValue = vmessInteger(json["port"]),
              let port = UInt16(exactly: portValue),
              port > 0
        else { throw ImportError.malformed(value) }

        let rawTransport = vmessText(json, keys: ["net"])?.lowercased() ?? "tcp"
        let transport: String
        switch rawTransport {
        case "", "tcp", "raw":
            transport = "tcp"
        case "h2":
            transport = "http"
        case "ws", "http", "httpupgrade", "grpc", "quic":
            transport = rawTransport
        case "kcp", "mkcp":
            // The pinned sing-box V2Ray transport implementation has no mKCP
            // constructor or option type. Silently treating it as TCP would create
            // a node that imports successfully but can never reach an mKCP server.
            throw ImportError.unsupported(
                "VMess / mKCP（当前 iOS 内核不支持，请换用同服务的 TCP、WS 或 VLESS 节点）"
            )
        default:
            throw ImportError.unsupported("VMess / \(rawTransport)")
        }

        let headerType = vmessText(json, keys: ["type"])?.lowercased() ?? "none"
        if transport == "tcp", !["", "none"].contains(headerType) {
            // sing-box intentionally has no V2Ray TCP-header transport. Ignoring
            // this legacy field results in a TCP connection that the server drops.
            throw ImportError.unsupported("VMess / TCP \(headerType) 伪装")
        }

        let tlsMode = vmessText(json, keys: ["tls"])?.lowercased() ?? ""
        guard ["", "none", "tls"].contains(tlsMode) else {
            throw ImportError.unsupported("VMess / \(tlsMode.uppercased()) 安全层")
        }
        let tls = tlsMode == "tls"
        if transport == "quic", !tls {
            // This sing-box revision's QUIC transport requires an explicit TLS
            // configuration and is not compatible with legacy Xray QUIC crypto.
            throw ImportError.unsupported("VMess / 无 TLS QUIC")
        }
        if transport == "quic" {
            let quicSecurity = vmessText(json, keys: ["host"])?.lowercased()
            let quicKey = vmessText(json, keys: ["path"])
            if (![nil, "", "none"].contains(quicSecurity)
                || quicKey != nil
                || !["", "none"].contains(headerType)) {
                throw ImportError.unsupported("VMess / Xray QUIC 附加加密或伪装")
            }
        }

        let security = (vmessText(json, keys: ["scy", "security"]) ?? "auto").lowercased()
        let supportedSecurity: Set<String> = [
            "auto", "none", "zero", "aes-128-ctr", "aes-128-gcm", "chacha20-poly1305",
        ]
        guard supportedSecurity.contains(security) else {
            throw ImportError.unsupported("VMess / \(security) 加密")
        }
        let alterID = vmessInteger(json["aid"] ?? json["alterId"] ?? 0) ?? -1
        guard alterID >= 0 else { throw ImportError.malformed(value) }

        let packetEncoding = (
            vmessText(json, keys: ["packetEncoding", "packet_encoding"]) ?? ""
        ).lowercased()
        guard ["", "packetaddr", "xudp"].contains(packetEncoding) else {
            throw ImportError.unsupported("VMess / \(packetEncoding) UDP 编码")
        }

        var query: [String: String] = [
            "scy": security,
            "aid": String(alterID),
            "vmess_header_type": headerType,
        ]
        copyVMessText(json, keys: ["fp"], to: "fp", into: &query)
        if let alpn = vmessStringList(json["alpn"]), !alpn.isEmpty {
            query["alpn"] = alpn.joined(separator: ",")
        }
        if !packetEncoding.isEmpty { query["packet_encoding"] = packetEncoding }
        if let value = vmessBoolean(json["globalPadding"] ?? json["global_padding"]) {
            query["global_padding"] = value ? "true" : "false"
        }
        if let value = vmessBoolean(json["authenticatedLength"] ?? json["authenticated_length"]) {
            query["authenticated_length"] = value ? "true" : "false"
        }
        if let networks = vmessStringList(json["network"]), !networks.isEmpty {
            let normalized = networks.map { $0.lowercased() }
            guard normalized.allSatisfy({ ["tcp", "udp"].contains($0) }) else {
                throw ImportError.unsupported("VMess / network 参数")
            }
            query["network"] = normalized.joined(separator: ",")
        }
        if let insecure = vmessBoolean(
            json["allowInsecure"] ?? json["allow_insecure"] ?? json["insecure"]
        ) {
            query["allowinsecure"] = insecure ? "true" : "false"
        }

        return ProxyNode(
            name: vmessText(json, keys: ["ps"]) ?? "VMess · \(host)",
            type: .vmess,
            server: host,
            port: port,
            credential: id,
            transport: transport,
            tls: tls,
            serverName: vmessText(json, keys: ["sni", "serverName", "servername"]),
            host: vmessText(json, keys: ["host"]),
            path: vmessText(json, keys: ["path", "serviceName", "service_name"]),
            query: query
        )
    }

    private func vmessText(_ json: [String: Any], keys: [String]) -> String? {
        for key in keys {
            let value: String?
            switch json[key] {
            case let text as String:
                value = text
            case let number as NSNumber:
                value = number.stringValue
            default:
                value = nil
            }
            if let normalized = value?.trimmingCharacters(in: .whitespacesAndNewlines),
               !normalized.isEmpty {
                return normalized
            }
        }
        return nil
    }

    private func vmessInteger(_ value: Any?) -> Int? {
        switch value {
        case is Bool:
            return nil
        case let value as Int:
            return value
        case let value as NSNumber:
            return Int(value.stringValue)
        case let value as String:
            return Int(value.trimmingCharacters(in: .whitespacesAndNewlines))
        default:
            return nil
        }
    }

    private func vmessBoolean(_ value: Any?) -> Bool? {
        switch value {
        case let value as Bool:
            return value
        case let value as NSNumber:
            return value.boolValue
        case let value as String:
            switch value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
            case "1", "true", "yes", "on": return true
            case "0", "false", "no", "off": return false
            default: return nil
            }
        default:
            return nil
        }
    }

    private func vmessStringList(_ value: Any?) -> [String]? {
        let values: [String]
        if let value = value as? String {
            values = value.split(separator: ",").map(String.init)
        } else if let value = value as? [Any] {
            values = value.compactMap { item in
                if let item = item as? String { return item }
                if let item = item as? NSNumber { return item.stringValue }
                return nil
            }
        } else {
            return nil
        }
        let normalized = values
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        return normalized.isEmpty ? nil : normalized
    }

    private func copyVMessText(
        _ json: [String: Any],
        keys: [String],
        to destination: String,
        into query: inout [String: String]
    ) {
        if let value = vmessText(json, keys: keys) { query[destination] = value }
    }
}

private extension String {
    var nonEmpty: String? { isEmpty ? nil : self }
    var removingLeadingSlashes: String { String(drop(while: { $0 == "/" })) }
    var base64Padded: String {
        let normalized = replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let remainder = normalized.count % 4
        return remainder == 0 ? normalized : normalized + String(repeating: "=", count: 4 - remainder)
    }
}
