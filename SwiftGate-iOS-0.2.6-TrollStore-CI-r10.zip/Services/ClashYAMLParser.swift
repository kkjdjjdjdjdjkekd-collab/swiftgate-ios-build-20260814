import Foundation
import Yams

struct ClashYAMLParser: Sendable {
    static func looksLikeClashConfiguration(_ value: String) -> Bool {
        value.range(
            of: #"(?m)^\s*proxies\s*:"#,
            options: .regularExpression
        ) != nil
    }

    func parse(_ value: String) throws -> ImportResult {
        let document: [String: Any]
        do {
            guard let loaded = try Yams.load(yaml: value) as? [String: Any] else {
                throw ImportError.malformed("Clash/Mihomo YAML")
            }
            document = loaded
        } catch {
            throw ImportError.malformed("Clash/Mihomo YAML")
        }

        guard let rawValues = document["proxies"] as? [Any], !rawValues.isEmpty else {
            throw ImportError.empty
        }

        var nodes: [ProxyNode] = []
        var rejected = 0
        var firstError: ImportError?
        for rawValue in rawValues {
            guard let raw = rawValue as? [String: Any] else {
                rejected += 1
                continue
            }
            do {
                guard let node = try node(from: raw) else {
                    rejected += 1
                    continue
                }
                nodes.append(node)
            } catch let error as ImportError {
                rejected += 1
                if firstError == nil { firstError = error }
            } catch {
                rejected += 1
            }
        }
        guard !nodes.isEmpty else {
            throw firstError ?? ImportError.unsupported("Clash/Mihomo YAML 中的节点类型")
        }

        var identities = Set<String>()
        let unique = nodes.filter { identities.insert($0.stableIdentity).inserted }
        return ImportResult(
            nodes: unique,
            duplicateCount: nodes.count - unique.count,
            rejectedCount: rejected
        )
    }

    private func node(from raw: [String: Any]) throws -> ProxyNode? {
        guard let name = text(raw, "name"),
              let typeName = text(raw, "type")?.lowercased(),
              let type = protocolType(typeName),
              let server = text(raw, "server"),
              let portValue = integer(raw["port"]),
              let port = UInt16(exactly: portValue),
              port > 0
        else { return nil }

        let credential: String
        switch type {
        case .vless, .vmess, .tuic:
            guard let value = text(raw, "uuid"), !value.isEmpty else { return nil }
            credential = value
        case .trojan, .shadowsocks, .hysteria2:
            guard let value = text(raw, "password"), !value.isEmpty else { return nil }
            credential = value
        }

        var transport = text(raw, "network")?.lowercased()
        let ws = map(raw["ws-opts"])
        let grpc = map(raw["grpc-opts"])
        let http = map(raw["http-opts"])
        if grpc != nil { transport = "grpc" }

        let headers = map(ws?["headers"])
        let host = text(raw, "host")
            ?? caseInsensitiveText(headers, "host")
            ?? firstText(http?["host"])
        let path = text(ws ?? [:], "path")
            ?? text(grpc ?? [:], "grpc-service-name", "service-name")
            ?? firstText(http?["path"])
            ?? text(raw, "path")

        var query: [String: String] = [:]
        copy(raw, keys: ["flow"], to: "flow", into: &query)
        copy(raw, keys: ["cipher"], to: "scy", into: &query)
        copy(raw, keys: ["alterId", "alter-id"], to: "aid", into: &query)
        copy(raw, keys: ["global-padding", "global_padding"], to: "global_padding", into: &query)
        copy(
            raw,
            keys: ["authenticated-length", "authenticated_length"],
            to: "authenticated_length",
            into: &query
        )
        copy(raw, keys: ["client-fingerprint", "fingerprint"], to: "fp", into: &query)
        copy(raw, keys: ["security"], to: "security", into: &query)
        copy(raw, keys: ["plugin"], to: "plugin", into: &query)
        copy(raw, keys: ["plugin-opts"], to: "plugin-opts", into: &query)
        copy(raw, keys: ["obfs"], to: "obfs", into: &query)
        copy(raw, keys: ["obfs-password"], to: "obfs-password", into: &query)
        copy(raw, keys: ["up", "up-mbps"], to: "upmbps", into: &query)
        copy(raw, keys: ["down", "down-mbps"], to: "downmbps", into: &query)
        copy(raw, keys: ["packet-encoding", "packet_encoding"], to: "packet_encoding", into: &query)
        copy(raw, keys: ["congestion-control", "congestion_control"], to: "congestion_control", into: &query)
        copy(raw, keys: ["udp-relay-mode", "udp_relay_mode"], to: "udp_relay_mode", into: &query)
        copy(raw, keys: ["heartbeat"], to: "heartbeat", into: &query)
        copy(ws ?? [:], keys: ["max-early-data", "max_early_data"], to: "max_early_data", into: &query)
        copy(
            ws ?? [:],
            keys: ["early-data-header-name", "early_data_header_name"],
            to: "early_data_header_name",
            into: &query
        )
        if let values = raw["alpn"] as? [Any] {
            let protocols = values.compactMap { scalarText($0) }.filter { !$0.isEmpty }
            if !protocols.isEmpty { query["alpn"] = protocols.joined(separator: ",") }
        } else {
            copy(raw, keys: ["alpn"], to: "alpn", into: &query)
        }
        if boolean(raw["skip-cert-verify"]) == true { query["allowinsecure"] = "true" }
        if boolean(raw["insecure"]) == true { query["allowinsecure"] = "true" }
        if type == .shadowsocks, let cipher = text(raw, "cipher") { query["method"] = cipher }
        if type == .tuic, let password = text(raw, "password") { query["password"] = password }

        if let reality = map(raw["reality-opts"]) {
            query["security"] = "reality"
            if let key = text(reality, "public-key") { query["pbk"] = key }
            if let id = text(reality, "short-id") { query["sid"] = id }
        }

        let tls = boolean(raw["tls"]) == true
            || [ProxyProtocol.hysteria2, .tuic].contains(type)
            || ["tls", "reality"].contains(query["security"]?.lowercased() ?? "")

        let node = ProxyNode(
            name: name,
            type: type,
            server: server,
            port: port,
            credential: credential,
            transport: transport,
            tls: tls,
            serverName: text(raw, "servername", "sni", "peer"),
            host: host,
            path: path,
            query: query
        )
        do {
            try RuntimeConfigBuilder().validate(node)
        } catch let error as RuntimeConfigurationError {
            throw ImportError.unsupported(error.localizedDescription)
        }
        return node
    }

    private func protocolType(_ value: String) -> ProxyProtocol? {
        switch value {
        case "vless": .vless
        case "vmess": .vmess
        case "trojan": .trojan
        case "ss", "shadowsocks": .shadowsocks
        case "hysteria2", "hy2": .hysteria2
        case "tuic": .tuic
        default: nil
        }
    }

    private func map(_ value: Any?) -> [String: Any]? {
        value as? [String: Any]
    }

    private func text(_ map: [String: Any], _ keys: String...) -> String? {
        text(map, keys: keys)
    }

    private func text(_ map: [String: Any], keys: [String]) -> String? {
        for key in keys {
            if let value = scalarText(map[key]), !value.isEmpty { return value }
        }
        return nil
    }

    private func scalarText(_ value: Any?) -> String? {
        switch value {
        case let value as String: value
        case let value as NSNumber: value.stringValue
        default: nil
        }
    }

    private func firstText(_ value: Any?) -> String? {
        if let value = scalarText(value) { return value }
        if let values = value as? [Any] { return values.lazy.compactMap { scalarText($0) }.first }
        return nil
    }

    private func integer(_ value: Any?) -> Int? {
        switch value {
        case let value as Int: value
        case let value as NSNumber: value.intValue
        case let value as String: Int(value)
        default: nil
        }
    }

    private func boolean(_ value: Any?) -> Bool? {
        switch value {
        case let value as Bool: value
        case let value as NSNumber: value.boolValue
        case let value as String: ["true", "yes", "1"].contains(value.lowercased())
        default: nil
        }
    }

    private func caseInsensitiveText(_ map: [String: Any]?, _ key: String) -> String? {
        guard let map else { return nil }
        return map.first(where: { $0.key.caseInsensitiveCompare(key) == .orderedSame })
            .flatMap { scalarText($0.value) }
    }

    private func copy(
        _ raw: [String: Any],
        keys: [String],
        to destination: String,
        into query: inout [String: String]
    ) {
        if let value = text(raw, keys: keys) { query[destination] = value }
    }
}
