#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_ROOT="${SWIFTGATE_BUILD_ROOT:-$ROOT/.build/ipa}"
DERIVED_DATA="$BUILD_ROOT/DerivedData"
SOURCE_PACKAGES="$BUILD_ROOT/SourcePackages"
STAGING="$BUILD_ROOT/staging"
OUTPUT_DIR="${SWIFTGATE_OUTPUT_DIR:-$ROOT/.build/artifacts}"
APP_PATH="$DERIVED_DATA/Build/Products/Release-iphoneos/SwiftGate.app"
IPA_PATH="$OUTPUT_DIR/SwiftGate-TrollStore.ipa"
APPLE_REF="${SWIFTGATE_APPLE_REF:-b1daf888efa6a5b80d668257ba540e600384d626}"
CORE_REF="${SWIFTGATE_CORE_REF:-3e16ce764818796996c1be3f12b0c6008808cf34}"
CORE_DIR="$ROOT/.build/core/sing-box"
APPLE_DIR="$ROOT/.build/core/sing-box-for-apple"
REVISION_FILE="$ROOT/Frameworks/SOURCE-REVISIONS.txt"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "A real iPhone IPA requires macOS, Xcode and the iOS SDK." >&2
  exit 1
fi

for tool in git xcodebuild xcodegen ditto shasum lipo unzip codesign; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "Missing required tool: $tool" >&2
    exit 1
  fi
done

core_cache_matches_requested_revisions() {
  [[ -d "$ROOT/Frameworks/Libbox.xcframework" ]] || return 1
  [[ -d "$APPLE_DIR/Library" ]] || return 1
  [[ -d "$CORE_DIR/.git" && -d "$APPLE_DIR/.git" ]] || return 1
  [[ -f "$REVISION_FILE" ]] || return 1

  local core_head apple_head requested_core_head requested_apple_head
  core_head="$(git -C "$CORE_DIR" rev-parse HEAD 2>/dev/null)" || return 1
  apple_head="$(git -C "$APPLE_DIR" rev-parse HEAD 2>/dev/null)" || return 1
  requested_core_head="$(git -C "$CORE_DIR" rev-parse "$CORE_REF^{commit}" 2>/dev/null)" || return 1
  requested_apple_head="$(git -C "$APPLE_DIR" rev-parse "$APPLE_REF^{commit}" 2>/dev/null)" || return 1
  [[ "$core_head" == "$requested_core_head" ]] || return 1
  [[ "$apple_head" == "$requested_apple_head" ]] || return 1
  grep -Fqx "sing-box $core_head" "$REVISION_FILE" || return 1
  grep -Fqx "sing-box-for-apple $apple_head" "$REVISION_FILE" || return 1
  grep -Fqx "requested-sing-box-ref $CORE_REF" "$REVISION_FILE" || return 1
  grep -Fqx "requested-sing-box-for-apple-ref $APPLE_REF" "$REVISION_FILE" || return 1
}

if ! core_cache_matches_requested_revisions; then
  echo "Building the native iPhone tunnel core (device slice only)..."
  SWIFTGATE_LIBBOX_PLATFORMS="${SWIFTGATE_LIBBOX_PLATFORMS:-ios}" \
    bash "$ROOT/Scripts/prepare-core.sh"
else
  bash "$ROOT/Scripts/generate-project.sh"
fi

echo "Validating generated VLESS and VMess runtime schemas with the pinned core..."
(
  cd "$ROOT/.build/core/sing-box"
  for fixture in \
    "$ROOT/Tests/Fixtures/vless-ws-runtime.json" \
    "$ROOT/Tests/Fixtures/vmess-ws-runtime.json"
  do
    go run -tags with_gvisor,with_utls ./cmd/sing-box check -c "$fixture"
  done
)

rm -rf "$BUILD_ROOT"
mkdir -p "$DERIVED_DATA" "$SOURCE_PACKAGES" "$STAGING/Payload" "$OUTPUT_DIR"

echo "Resolving pinned Swift package dependencies..."
xcodebuild \
  -resolvePackageDependencies \
  -project "$ROOT/SwiftGateiOS.xcodeproj" \
  -scheme SwiftGate \
  -derivedDataPath "$DERIVED_DATA" \
  -clonedSourcePackagesDirPath "$SOURCE_PACKAGES"

echo "Building SwiftGate for a generic iPhone without code signing..."
xcodebuild \
  -project "$ROOT/SwiftGateiOS.xcodeproj" \
  -scheme SwiftGate \
  -configuration Release \
  -sdk iphoneos \
  -destination "generic/platform=iOS" \
  -derivedDataPath "$DERIVED_DATA" \
  -clonedSourcePackagesDirPath "$SOURCE_PACKAGES" \
  -disableAutomaticPackageResolution \
  ARCHS=arm64 \
  ONLY_ACTIVE_ARCH=NO \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  DEVELOPMENT_TEAM="" \
  PROVISIONING_PROFILE_SPECIFIER="" \
  COMPILER_INDEX_STORE_ENABLE=NO \
  IPHONEOS_DEPLOYMENT_TARGET=15.0 \
  OTHER_LDFLAGS='$(inherited) -lresolv -framework SystemConfiguration' \
  build

if [[ ! -d "$APP_PATH" ]]; then
  echo "SwiftGate.app was not produced at the expected path: $APP_PATH" >&2
  exit 1
fi
if [[ ! -d "$APP_PATH/PlugIns/PacketTunnel.appex" ]]; then
  echo "The Packet Tunnel extension is missing from the app bundle." >&2
  exit 1
fi
if [[ ! -f "$APP_PATH/SwiftGate" || ! -f "$APP_PATH/PlugIns/PacketTunnel.appex/PacketTunnel" ]]; then
  echo "The app or Packet Tunnel executable is missing." >&2
  exit 1
fi
if [[ ! -f "$APP_PATH/Assets.car" ]]; then
  echo "The compiled app icon and asset catalog are missing." >&2
  exit 1
fi
for license_file in GPL-3.0.txt Yams-MIT.txt; do
  if ! find "$APP_PATH" -type f -name "$license_file" -print -quit | grep -q .; then
    echo "Required third-party license is missing: $license_file" >&2
    exit 1
  fi
done
if ! lipo -archs "$APP_PATH/SwiftGate" | grep -qw arm64 || \
   ! lipo -archs "$APP_PATH/PlugIns/PacketTunnel.appex/PacketTunnel" | grep -qw arm64; then
  echo "The app or Packet Tunnel executable is missing the arm64 device slice." >&2
  exit 1
fi

APP_ID="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP_PATH/Info.plist")"
EXT_ID="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP_PATH/PlugIns/PacketTunnel.appex/Info.plist")"
APP_GROUP="$(/usr/libexec/PlistBuddy -c 'Print :AppGroupIdentifier' "$APP_PATH/Info.plist")"
EXT_APP_GROUP="$(/usr/libexec/PlistBuddy -c 'Print :AppGroupIdentifier' "$APP_PATH/PlugIns/PacketTunnel.appex/Info.plist")"
EXT_BASE_ID="$(/usr/libexec/PlistBuddy -c 'Print :BasePackageIdentifier' "$APP_PATH/PlugIns/PacketTunnel.appex/Info.plist")"
EXT_POINT="$(/usr/libexec/PlistBuddy -c 'Print :NSExtension:NSExtensionPointIdentifier' "$APP_PATH/PlugIns/PacketTunnel.appex/Info.plist")"
EXT_PRINCIPAL="$(/usr/libexec/PlistBuddy -c 'Print :NSExtension:NSExtensionPrincipalClass' "$APP_PATH/PlugIns/PacketTunnel.appex/Info.plist")"
if [[ "$APP_ID" != "com.swiftgate.ios" || "$EXT_ID" != "com.swiftgate.ios.PacketTunnel" ]]; then
  echo "Unexpected bundle identifiers: app=$APP_ID extension=$EXT_ID" >&2
  exit 1
fi
if [[ "$EXT_ID" != "$APP_ID.PacketTunnel" || "$EXT_BASE_ID" != "$APP_ID" ]]; then
  echo "Packet Tunnel base identifier mismatch: app=$APP_ID extension=$EXT_ID base=$EXT_BASE_ID" >&2
  exit 1
fi
if [[ "$APP_GROUP" != "group.com.swiftgate.shared" || "$EXT_APP_GROUP" != "$APP_GROUP" ]]; then
  echo "App Group mismatch: app=$APP_GROUP extension=$EXT_APP_GROUP" >&2
  exit 1
fi
if [[ "$EXT_POINT" != "com.apple.networkextension.packet-tunnel" || "$EXT_PRINCIPAL" != "PacketTunnel.PacketTunnelProvider" ]]; then
  echo "Packet Tunnel extension metadata is invalid: point=$EXT_POINT principal=$EXT_PRINCIPAL" >&2
  exit 1
fi

ditto "$APP_PATH" "$STAGING/Payload/SwiftGate.app"
find "$STAGING/Payload" -type d -name _CodeSignature -prune -exec rm -rf {} +
find "$STAGING/Payload" -type f -name embedded.mobileprovision -delete
STAGED_APP="$STAGING/Payload/SwiftGate.app"
STAGED_EXTENSION="$STAGED_APP/PlugIns/PacketTunnel.appex"

echo "Embedding TrollStore-compatible entitlements..."
codesign --force --sign - --timestamp=none --generate-entitlement-der \
  --entitlements "$ROOT/Config/PacketTunnel-TrollStore.entitlements" \
  "$STAGED_EXTENSION"
codesign --force --sign - --timestamp=none --generate-entitlement-der \
  --entitlements "$ROOT/Config/SwiftGate-TrollStore.entitlements" \
  "$STAGED_APP"
codesign --verify --deep --strict "$STAGED_APP"

APP_ENTITLEMENTS="$BUILD_ROOT/app-entitlements.plist"
EXT_ENTITLEMENTS="$BUILD_ROOT/extension-entitlements.plist"
codesign -d --entitlements :- "$STAGED_APP" >"$APP_ENTITLEMENTS" 2>/dev/null
codesign -d --entitlements :- "$STAGED_EXTENSION" >"$EXT_ENTITLEMENTS" 2>/dev/null

plist_value() {
  /usr/libexec/PlistBuddy -c "Print :$2" "$1"
}

if [[ "$(plist_value "$APP_ENTITLEMENTS" application-identifier)" != "TROLLTROLL.com.swiftgate.ios" || \
      "$(plist_value "$EXT_ENTITLEMENTS" application-identifier)" != "TROLLTROLL.com.swiftgate.ios.PacketTunnel" ]]; then
  echo "The app and Packet Tunnel must have distinct, exact TrollStore application identifiers." >&2
  exit 1
fi
if [[ "$(plist_value "$APP_ENTITLEMENTS" com.apple.developer.team-identifier)" != "TROLLTROLL" || \
      "$(plist_value "$EXT_ENTITLEMENTS" com.apple.developer.team-identifier)" != "TROLLTROLL" ]]; then
  echo "Unexpected TrollStore team identifier." >&2
  exit 1
fi
if [[ "$(plist_value "$APP_ENTITLEMENTS" com.apple.developer.networking.networkextension:0)" != "packet-tunnel-provider" || \
      "$(plist_value "$EXT_ENTITLEMENTS" com.apple.developer.networking.networkextension:0)" != "packet-tunnel-provider" ]]; then
  echo "The Packet Tunnel entitlement is missing from the app or extension." >&2
  exit 1
fi
if [[ "$(plist_value "$APP_ENTITLEMENTS" com.apple.security.application-groups:0)" != "group.com.swiftgate.shared" || \
      "$(plist_value "$EXT_ENTITLEMENTS" com.apple.security.application-groups:0)" != "group.com.swiftgate.shared" ]]; then
  echo "The shared App Group entitlement is missing or inconsistent." >&2
  exit 1
fi
if [[ "$(plist_value "$APP_ENTITLEMENTS" keychain-access-groups:0)" != "TROLLTROLL.com.swiftgate.ios" ]]; then
  echo "The app Keychain access group does not match its TrollStore identity." >&2
  exit 1
fi
if /usr/libexec/PlistBuddy -c 'Print :keychain-access-groups' "$EXT_ENTITLEMENTS" >/dev/null 2>&1; then
  echo "The Packet Tunnel must not carry an unused Keychain access group." >&2
  exit 1
fi
for entitlement_file in "$APP_ENTITLEMENTS" "$EXT_ENTITLEMENTS"; do
  if /usr/libexec/PlistBuddy -c 'Print :get-task-allow' "$entitlement_file" >/dev/null 2>&1; then
    echo "TrollStore build must not require Developer Mode (get-task-allow found)." >&2
    exit 1
  fi
done

rm -f "$IPA_PATH" "$IPA_PATH.sha256" "$OUTPUT_DIR/Build-Info.txt"
(
  cd "$STAGING"
  ditto -c -k --sequesterRsrc --keepParent Payload "$IPA_PATH"
)

shasum -a 256 "$IPA_PATH" > "$IPA_PATH.sha256"
unzip -tq "$IPA_PATH"
{
  echo "artifact SwiftGate-TrollStore.ipa"
  echo "signing ad-hoc with embedded Packet Tunnel and App Group entitlements"
  echo "configuration Release"
  echo "sdk iphoneos"
  echo "built-at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  if [[ -f "$ROOT/Frameworks/SOURCE-REVISIONS.txt" ]]; then
    cat "$ROOT/Frameworks/SOURCE-REVISIONS.txt"
  fi
} > "$OUTPUT_DIR/Build-Info.txt"

echo "TrollStore-ready IPA: $IPA_PATH"
echo "The main app and PacketTunnel extension contain their required entitlements without get-task-allow."
