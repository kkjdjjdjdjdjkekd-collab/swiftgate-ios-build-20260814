import Foundation

extension ProxyNode {
    var protocolTitle: String {
        switch type {
        case .vless: return "VLESS"
        case .vmess: return "VMess"
        case .trojan: return "Trojan"
        case .shadowsocks: return "Shadowsocks"
        case .hysteria2: return "Hysteria 2"
        case .tuic: return "TUIC"
        }
    }

    var endpointSummary: String {
        "\(server):\(port)"
    }

    var latencyText: String {
        guard let latency = tcpLatencyMilliseconds else { return "TCP 测速" }
        return "TCP \(latency) ms"
    }
}
