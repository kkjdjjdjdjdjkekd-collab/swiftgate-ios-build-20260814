# SwiftGate for iPhone

这是与 Windows 版完全隔离的原生 SwiftUI / Network Extension 工程。Windows
0.1.6 已冻结在 `../outputs/SwiftGate-Windows-0.1.6-FROZEN`，本工程不得引用或
修改该目录中的文件。

## 已实现

- iOS 15+ 原生 SwiftUI：首页、节点、导入、设置、诊断。
- 连接状态严格来自 `NEVPNStatus`，不会显示假连接。
- 断开时可选择节点；连接时先让 Packet Tunnel 重载成功，再显示“当前”。
- 断开 VPN 时可做单节点和最多 4 路并发端点 TCP 测速；连接时不会让测速
  绕回当前隧道并显示虚假的高延迟。
- Clash/Mihomo YAML、HTTPS 订阅、VLESS、VMess、Trojan、Shadowsocks、
  Hysteria 2、TUIC 导入与去重。
- HTTPS 订阅手动更新；App 在前台时按 6/12/24 小时检查，失败自动保留旧配置。
- 完整配置由 AES-GCM 加密，密钥和订阅地址保存在 Keychain。
- 智能分流对 DNS 正确接管和嗅探，私网与 `.cn` 默认直连；全局和直连模式独立。
- 自动故障切换默认关闭；开启后必须连续 3 次真实链路检查失败才切换。
- 诊断包自动遮盖分享链接、UUID、密码、令牌和 URL 参数。
- 第三方许可在“设置 → 第三方许可”中可查看。

## 为什么不能直接在 Windows 生成 IPA

iOS 不允许像 Windows 一样启动独立的 `mihomo.exe`。全机流量必须由
`NEPacketTunnelProvider` 扩展接管，代理核心也必须编译成 iOS Framework。
Windows 没有 Xcode、iOS SDK、签名工具和真机权限，因此本目录可以完成源码、
工程描述与静态检查，但不能诚实地声称已经生成可安装 IPA。

真实隧道使用官方 sing-box `Libbox.xcframework`，并把固定版本的官方 Apple
桥接源码直接编进 Packet Tunnel。缺少核心时仍可编译 UI 外壳，但点连接会明确报告
“核心尚未嵌入”，不会制造假 VPN。

## 在 Mac 上生成并运行

需要最新稳定版 Xcode、Go、XcodeGen、一台 iPhone，以及已开通 Network
Extension 能力的付费 Apple Developer Program 账号。

1. 把整个 `ios` 目录复制到 Mac。
2. 如这些标识不可注册，统一修改以下三处：
   - `com.swiftgate.ios`
   - `com.swiftgate.ios.PacketTunnel`
   - `group.com.swiftgate.shared`
   对应文件是 `project.yml`、`Config/AppConfiguration.swift` 和两个 entitlements。
3. 安装 XcodeGen：`brew install xcodegen`。
4. 构建官方核心和桥接框架：`bash Scripts/prepare-core.sh`。
5. 脚本会生成 `SwiftGateiOS.xcodeproj`。用 Xcode 打开，给 App 与 PacketTunnel
   选择同一个开发团队，并确认 App Groups 与 Packet Tunnel Provider 权限。
6. 选择真机运行；首次点连接时 iOS 会显示系统“添加 VPN 配置”授权。
7. 在 Mac 上执行 `bash Scripts/verify-on-mac.sh` 运行模拟器构建与单元测试。

### 生成 TrollStore 专用 IPA

在 Mac 上执行：

```bash
brew install xcodegen
bash Scripts/build-unsigned-ipa.sh
```

文件会生成到 `.build/artifacts/SwiftGate-TrollStore.ipa`，同时附带 SHA-256 和核心
提交信息。它是已经预嵌 VPN、App Group 与 Keychain 权限的 TrollStore 专用包；
请直接交给 TrollStore 安装，不要再用其他签名工具改写 Bundle ID。

如果没有 Mac，可把本目录内容放到一个 GitHub 仓库根目录，在 Actions 页面手动运行
`Build TrollStore iPhone IPA`。工作流使用苹果构建机，只编译 iPhone 真机需要的 arm64
核心，并把结果作为 `SwiftGate-TrollStore-IPA` 下载项保存 14 天。工作流不接收证书、
密码或描述文件。

重新签名时必须同时处理宿主 App、`PacketTunnel.appex` 和嵌入框架；宿主与扩展的
描述文件都必须包含 Packet Tunnel Provider 权限，并使用同一个 App Group。若修改
宿主 Bundle ID，扩展必须同步为 `<新 Bundle ID>.PacketTunnel`，同时更新两个
Info.plist、两个 entitlements 和签名描述文件中的 App Group。

只想先看界面时，可执行 `bash Scripts/generate-project.sh`；没有核心框架时它会
自动使用 `project.yml`。有两个框架时会使用 `project-with-core.yml`。

## 核心版本与可重复构建

`Scripts/prepare-core.sh` 默认固定 Apple 桥到提交
`b1daf888efa6a5b80d668257ba540e600384d626`，并固定核心到
`3e16ce764818796996c1be3f12b0c6008808cf34`，避免上游接口在无人注意时漂移。
构建完成后会写入 `Frameworks/SOURCE-REVISIONS.txt`，记录实际两个提交。
可通过 `SWIFTGATE_APPLE_REF` 和 `SWIFTGATE_CORE_REF` 显式指定其他版本。

## 速度策略

- 数据面直接运行原生 arm64 Libbox，不经过 SwiftUI 或本机二次转发。
- 运行配置只下发当前节点，减少首连、切换时的 JSON 传输、解析和扩展内存。
- 三种路由模式统一接管 DNS，并启用 4096 项 DNS 缓存；智能分流让私网和 `.cn`
  直连。
- 端点测速先解析地址、再只计算数字 IP 的 TCP 握手，并竞速多个地址；首页把
  经代理的 HTTPS 整体耗时明确标为“完整链路响应”，连续三次取中位数，避免
  首个冷连接夸大结果。
- Packet Tunnel 使用 MTU 1500、系统栈、IPv4 优先且保留 IPv6 回退；DNS 53 端口
  直接劫持，私网先直连再做公网域名嗅探，减少不必要的首包等待。
- 忠实传递节点声明的 ALPN、包编码、WebSocket early-data、TUIC 拥塞控制和心跳；
  不擅自开启服务端未支持的多路复用、0-RTT 或 TCP Fast Open。
- 完整链路测试复用连接，避免每次测速都重复制造一次 DNS/TCP/TLS 冷启动。

这些优化让客户端自身尽量不成为瓶颈，但最终速度仍由 iPhone 网络、节点、线路和
协议决定，不能承诺绝对等于直连速度。正式验收应在同一台 iPhone、同一节点与同一
核心版本下，对 Release 构建反复取中位数。

## 已知边界

- sing-box iOS 核心不支持 VMess/VLESS mKCP；导入时会明确拒绝，而不是静默降速。
- 自动订阅检查只保证 App 在前台时执行；普通 iOS App 不能任意常驻后台。
- TCP 延迟只代表服务器端口握手；连接后的“测试网址”才代表完整代理链路。
- 公开 App Store 发布 VPN App 还需要组织开发者账号、隐私披露、地区合规审核。

## 许可证

sing-box、Libbox 和 Apple 桥为 GPL-3.0。Yams / LibYAML 为 MIT。公开分发或
TestFlight 前，必须随构建提供完整对应源码、准确提交、构建脚本、修改说明和
许可证，并先完成 Apple 分发条款与 GPL-3.0 的合规审核。许可全文在 `Licenses/`。
