import Foundation
import Combine

@MainActor
final class AppModel: ObservableObject {
    private let store: AtomicConfigurationStore
    private let tunnel: TunnelManager
    private let importService: ImportService
    private let latency: LatencyService
    private let runtimeBuilder: RuntimeConfigBuilder
    private let keychain: KeychainStore
    private let diagnostics: DiagnosticService
    private var tunnelObservation: AnyCancellable?
    private var tunnelStateObservation: AnyCancellable?

    private var initialized = false
    private var settingsRevision = 0
    private var healthTask: Task<Void, Never>?
    private var networkVerificationTask: Task<Void, Never>?
    private var subscriptionTask: Task<Void, Never>?
    private var consecutiveHealthFailures = 0
    private var activeDNSProfile: RuntimeDNSProfile = .local
    private var runtimeGeneration = 0
    private var fallbackAttemptedGeneration: Int?
    private var fallbackRollbackState: (
        generation: Int,
        profile: RuntimeDNSProfile,
        runtime: String
    )?

    @Published var nodes: [ProxyNode] = []
    @Published var settings = AppSettings()
    @Published var importText = ""
    @Published var importSummary: String?
    @Published var diagnosticItems: [DiagnosticItem] = []
    @Published var diagnosticExportURL: URL?
    @Published var notice: String?
    @Published private(set) var isUpdatingSubscription = false
    @Published private(set) var tunnelNetworkAvailable: Bool?
    @Published private(set) var tunnelNetworkStatus: String?

    var connectionState: VPNConnectionState { tunnel.state }
    var connectionStatusText: String { tunnelNetworkStatus ?? tunnel.statusMessage }
    var hasSavedSubscription: Bool { settings.subscriptionURLKey != nil }

    var preferredNode: ProxyNode? {
        guard let id = settings.preferredNodeID else { return nil }
        return nodes.first(where: { $0.id == id })
    }

    var currentNode: ProxyNode? {
        guard settings.routingMode != .direct else { return nil }
        switch connectionState {
        case .connected, .reasserting:
            return preferredNode
        default:
            return nil
        }
    }

    private var canReloadTunnel: Bool {
        connectionState == .connected || connectionState == .reasserting
    }

    init(
        store: AtomicConfigurationStore? = nil,
        tunnel: TunnelManager = TunnelManager(),
        importService: ImportService = ImportService(),
        latency: LatencyService = LatencyService(),
        runtimeBuilder: RuntimeConfigBuilder = RuntimeConfigBuilder(),
        keychain: KeychainStore = KeychainStore(),
        diagnostics: DiagnosticService = DiagnosticService()
    ) {
        self.store = store ?? AtomicConfigurationStore()
        self.tunnel = tunnel
        self.importService = importService
        self.latency = latency
        self.runtimeBuilder = runtimeBuilder
        self.keychain = keychain
        self.diagnostics = diagnostics
        tunnelObservation = tunnel.objectWillChange.sink { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.objectWillChange.send()
            }
        }
        tunnelStateObservation = tunnel.$state
            .removeDuplicates()
            .sink { [weak self] state in
                Task { @MainActor [weak self] in
                    self?.tunnelStateDidChange(state)
                }
            }
    }

    func initialize() async {
        guard !initialized else { return }
        initialized = true
        let signingNotice = AppConfiguration.isSharedContainerAvailable
            ? nil
            : "当前签名没有 App Group 权限，SwiftGate 已改用本机存储，因此不会再闪退；VPN 隧道仍需要签名工具保留 Network Extension 和 App Group 权限。"
        do {
            var configuration = try await store.load()
            if let id = configuration.settings.preferredNodeID,
               !configuration.nodes.contains(where: { $0.id == id }) {
                configuration.settings.preferredNodeID = configuration.nodes.first?.id
                configuration.updatedAt = Date()
                try await store.save(configuration)
            } else if configuration.settings.preferredNodeID == nil,
                      let first = configuration.nodes.first {
                configuration.settings.preferredNodeID = first.id
                configuration.updatedAt = Date()
                try await store.save(configuration)
            }
            nodes = configuration.nodes
            settings = configuration.settings
        } catch {
            notice = "读取配置失败：\(Redactor.clean(error.localizedDescription))"
        }
        await tunnel.load()
        if notice == nil {
            notice = signingNotice
        }
        restartHealthMonitor()
        restartSubscriptionMonitor()
    }

    func toggleConnection() async {
        do {
            switch connectionState {
            case .connected, .connecting, .reasserting:
                invalidateNetworkVerification()
                try await tunnel.toggle(runtimeConfiguration: "{}")
            case .disconnecting:
                return
            case .disconnected, .invalid, .unavailable:
                invalidateNetworkVerification()
                activeDNSProfile = .local
                let runtime = try buildRuntime(snapshot())
                try await tunnel.toggle(runtimeConfiguration: runtime)
            }
        } catch {
            notice = "连接失败：\(Redactor.clean(error.localizedDescription))"
        }
    }

    private func tunnelStateDidChange(_ state: VPNConnectionState) {
        networkVerificationTask?.cancel()
        networkVerificationTask = nil

        guard state == .connected else {
            tunnelNetworkAvailable = nil
            tunnelNetworkStatus = nil
            return
        }

        tunnelNetworkAvailable = nil
        tunnelNetworkStatus = "正在验证实际网络"
        networkVerificationTask = Task { [weak self] in
            guard let self else { return }
            await self.verifyConnectedTunnel()
        }
    }

    private func verifyConnectedTunnel() async {
        let verificationGeneration = runtimeGeneration
        // Allow iOS to publish the newly installed DNS and route settings before probing.
        do { try await Task.sleep(nanoseconds: 800_000_000) }
        catch { return }
        guard connectionState == .connected,
              !Task.isCancelled,
              verificationGeneration == runtimeGeneration
        else { return }

        do {
            _ = try await latency.testTunnelRoute(timeout: 5)
        } catch {
            guard connectionState == .connected,
                  !Task.isCancelled,
                  verificationGeneration == runtimeGeneration
            else { return }
            await rollbackCompatibleDNSIfNeeded(for: verificationGeneration)
            guard connectionState == .connected,
                  !Task.isCancelled,
                  verificationGeneration == runtimeGeneration
            else { return }
            tunnelNetworkAvailable = false
            tunnelNetworkStatus = "VPN 已连接，但节点流量不可用"
            notice = "实际网络检查失败：节点无法传输数据。断开 VPN 后会恢复原网络。"
            return
        }

        do {
            let delay = try await latency.testCurrentTunnel(timeout: 8)
            guard connectionState == .connected,
                  !Task.isCancelled,
                  verificationGeneration == runtimeGeneration
            else { return }
            if fallbackRollbackState?.generation == verificationGeneration {
                fallbackRollbackState = nil
            }
            tunnelNetworkAvailable = true
            tunnelNetworkStatus = "网络可用 · \(delay) ms"
        } catch {
            guard connectionState == .connected,
                  !Task.isCancelled,
                  verificationGeneration == runtimeGeneration
            else { return }
            guard activeDNSProfile.canFallbackToCompatibleDNS,
                  fallbackAttemptedGeneration != verificationGeneration
            else {
                await rollbackCompatibleDNSIfNeeded(for: verificationGeneration)
                guard connectionState == .connected,
                      !Task.isCancelled,
                      verificationGeneration == runtimeGeneration
                else { return }
                tunnelNetworkAvailable = false
                tunnelNetworkStatus = "VPN 已连接，但 DNS 或 HTTPS 不可用"
                notice = "实际网络检查失败：兼容 DNS 仍未通过，已停止重试。"
                return
            }
            fallbackAttemptedGeneration = verificationGeneration
            tunnelNetworkStatus = "正在切换兼容 DNS"
            let previousDNSProfile = activeDNSProfile
            let configuration = snapshot()
            let previousRuntime: String
            let fallbackRuntime: String
            do {
                previousRuntime = try runtimeBuilder.build(
                    configuration,
                    dnsProfile: previousDNSProfile
                )
                fallbackRuntime = try runtimeBuilder.build(
                    configuration,
                    dnsProfile: .proxiedHTTPS
                )
            } catch {
                guard connectionState == .connected,
                      !Task.isCancelled,
                      verificationGeneration == runtimeGeneration
                else { return }
                tunnelNetworkAvailable = false
                tunnelNetworkStatus = "VPN 已连接，但无法生成兼容 DNS 配置"
                notice = "实际网络检查失败：兼容 DNS 配置生成失败，已停止重试。"
                return
            }

            fallbackRollbackState = (
                generation: verificationGeneration,
                profile: previousDNSProfile,
                runtime: previousRuntime
            )
            activeDNSProfile = .proxiedHTTPS
            do {
                try await tunnel.reload(runtimeConfiguration: fallbackRuntime)
                try await Task.sleep(nanoseconds: 600_000_000)
                let fallbackDelay = try await latency.testCurrentTunnel(timeout: 8)
                guard connectionState == .connected,
                      !Task.isCancelled,
                      verificationGeneration == runtimeGeneration
                else { return }
                fallbackRollbackState = nil
                tunnelNetworkAvailable = true
                tunnelNetworkStatus = "网络可用 · 兼容 DNS · \(fallbackDelay) ms"
            } catch {
                // A successful reload normally reasserts the tunnel and cancels this task.
                // In that case the next connected-state verification owns the result.
                guard !Task.isCancelled,
                      verificationGeneration == runtimeGeneration
                else { return }

                await rollbackCompatibleDNSIfNeeded(for: verificationGeneration)
                guard connectionState == .connected,
                      !Task.isCancelled,
                      verificationGeneration == runtimeGeneration
                else { return }
                tunnelNetworkAvailable = false
                tunnelNetworkStatus = "VPN 已连接，但 DNS 或 HTTPS 不可用"
                notice = "实际网络检查失败：本机 DNS 与加密 DNS 均未通过。"
            }
        }
    }

    private func buildRuntime(_ configuration: StoredConfiguration) throws -> String {
        try runtimeBuilder.build(configuration, dnsProfile: activeDNSProfile)
    }

    private func rollbackCompatibleDNSIfNeeded(for generation: Int) async {
        guard generation == runtimeGeneration,
              let rollback = fallbackRollbackState,
              rollback.generation == generation
        else { return }

        // Consume this rollback before awaiting so a connected-state callback cannot
        // send the same restore message twice for one runtime generation.
        fallbackRollbackState = nil
        activeDNSProfile = rollback.profile
        if canReloadTunnel {
            try? await tunnel.reload(runtimeConfiguration: rollback.runtime)
        }
    }

    func selectNode(_ node: ProxyNode) async {
        guard nodes.contains(where: { $0.id == node.id }) else {
            notice = "该节点已不在当前配置中"
            return
        }
        invalidateNetworkVerification()
        let previous = snapshot()
        var candidate = previous
        candidate.settings.preferredNodeID = node.id
        candidate.updatedAt = Date()

        do {
            let runtime = try buildRuntime(candidate)
            if canReloadTunnel {
                try await tunnel.reload(runtimeConfiguration: runtime)
            }
            try await store.save(candidate)
            settingsRevision += 1
            settings = candidate.settings
            consecutiveHealthFailures = 0
            notice = canReloadTunnel
                ? "已切换到 \(node.name)"
                : "已选择 \(node.name)，下次连接时使用"
            restartNetworkVerificationIfConnected()
        } catch {
            if canReloadTunnel,
               let previousRuntime = try? buildRuntime(previous) {
                try? await tunnel.reload(runtimeConfiguration: previousRuntime)
            }
            restartNetworkVerificationIfConnected()
            notice = "无法切换节点：\(Redactor.clean(error.localizedDescription))"
        }
    }

    func testLatency(_ node: ProxyNode) async {
        do {
            let delay = try await latency.test(node)
            guard let index = nodes.firstIndex(where: { $0.id == node.id }) else { return }
            nodes[index].tcpLatencyMilliseconds = delay
            try await store.save(snapshot())
        } catch {
            notice = "\(node.name) 测速失败"
        }
    }

    func testAllLatencies() async {
        let results = await measureNodes(nodes)
        for index in nodes.indices {
            nodes[index].tcpLatencyMilliseconds = results[nodes[index].id]
        }
        do { try await store.save(snapshot()) }
        catch { notice = "测速完成，但保存结果失败" }
    }

    func importTextContent() async {
        let source = importText.trimmingCharacters(in: .whitespacesAndNewlines)
        do {
            let resolved = try await importService.resolve(source)
            try await applyImport(resolved)
            importText = ""
        } catch {
            notice = "导入失败：\(Redactor.clean(error.localizedDescription))"
        }
    }

    func importFile(_ url: URL) async {
        do {
            let service = importService
            let resolved = try await Task.detached(priority: .userInitiated) {
                try service.resolveFile(url)
            }.value
            try await applyImport(resolved)
        } catch {
            notice = "导入失败：\(Redactor.clean(error.localizedDescription))"
        }
    }

    func setRoutingMode(_ mode: RoutingMode) {
        updateSettings(reloadTunnel: true) { $0.routingMode = mode }
    }

    func setAutoSwitchEnabled(_ enabled: Bool) {
        updateSettings(reloadTunnel: false) { $0.autoSwitchEnabled = enabled }
        restartHealthMonitor()
    }

    func setUpdateInterval(_ hours: Int) {
        guard [6, 12, 24].contains(hours) else { return }
        updateSettings(reloadTunnel: false) { $0.updateIntervalHours = hours }
        restartSubscriptionMonitor()
    }

    func updateSubscription() async {
        await refreshSubscription(showSuccessNotice: true, onlyWhenDue: false)
    }

    func runDiagnostics() async {
        let raw = try? await store.rawConfigurationData()
        let encrypted = raw.map { !$0.isEmpty && $0.first != 0x7B } ?? false
        let output = await diagnostics.run(
            configuration: snapshot(),
            connectionState: connectionState,
            vpnConfigured: tunnel.isConfigured,
            encryptedStore: encrypted
        )
        diagnosticItems = output.items
        diagnosticExportURL = output.exportURL
    }

    func clearNotice() {
        notice = nil
    }

    private func applyImport(_ resolved: ResolvedImport, announce: Bool = true) async throws {
        invalidateNetworkVerification()
        let previous = snapshot()
        var candidate = previous
        var merged = nodes
        var added = 0

        for incoming in resolved.result.nodes {
            if let index = merged.firstIndex(where: { $0.stableIdentity == incoming.stableIdentity }) {
                var replacement = incoming
                replacement.id = merged[index].id
                replacement.tcpLatencyMilliseconds = merged[index].tcpLatencyMilliseconds
                merged[index] = replacement
            } else {
                merged.append(incoming)
                added += 1
            }
        }

        candidate.nodes = merged
        if candidate.settings.preferredNodeID == nil { candidate.settings.preferredNodeID = merged.first?.id }
        if let url = resolved.subscriptionURL {
            let key = "active-subscription-url"
            try keychain.set(url.absoluteString, for: key)
            candidate.settings.subscriptionURLKey = key
            candidate.settings.lastSubscriptionUpdateAt = Date()
        }
        candidate.updatedAt = Date()
        let runtime = try buildRuntime(candidate)

        if canReloadTunnel {
            try await tunnel.reload(runtimeConfiguration: runtime)
        }
        do {
            try await store.save(candidate)
        } catch {
            if canReloadTunnel,
               let previousRuntime = try? buildRuntime(previous) {
                try? await tunnel.reload(runtimeConfiguration: previousRuntime)
            }
            restartNetworkVerificationIfConnected()
            throw error
        }

        settingsRevision += 1
        nodes = candidate.nodes
        settings = candidate.settings
        restartNetworkVerificationIfConnected()
        let duplicates = resolved.result.duplicateCount
        let rejected = resolved.result.rejectedCount
        importSummary = "新增 \(added) 个，更新 \(resolved.result.nodes.count - added) 个，重复 \(duplicates) 个，不支持/无效 \(rejected) 个"
        if announce { notice = "导入成功" }
    }

    private func updateSettings(
        reloadTunnel: Bool,
        mutation: (inout AppSettings) -> Void
    ) {
        let previous = settings
        mutation(&settings)
        guard settings != previous else { return }
        if reloadTunnel { invalidateNetworkVerification() }
        settingsRevision += 1
        let revision = settingsRevision
        let candidate = snapshot()
        Task { [weak self] in
            await self?.commitSettings(
                candidate,
                previous: previous,
                revision: revision,
                reloadTunnel: reloadTunnel
            )
        }
    }

    private func commitSettings(
        _ candidate: StoredConfiguration,
        previous: AppSettings,
        revision: Int,
        reloadTunnel: Bool
    ) async {
        guard revision == settingsRevision else { return }
        var reloadAttempted = false
        do {
            if reloadTunnel, canReloadTunnel {
                reloadAttempted = true
                try await tunnel.reload(runtimeConfiguration: buildRuntime(candidate))
            }
            try await store.save(candidate)
            if reloadAttempted { restartNetworkVerificationIfConnected() }
        } catch {
            guard revision == settingsRevision else { return }
            settings = previous
            var rollback = snapshot()
            rollback.settings = previous
            rollback.updatedAt = Date()
            try? await store.save(rollback)
            if reloadAttempted, let runtime = try? buildRuntime(rollback) {
                try? await tunnel.reload(runtimeConfiguration: runtime)
            }
            if reloadAttempted { restartNetworkVerificationIfConnected() }
            notice = "设置未保存：\(Redactor.clean(error.localizedDescription))"
        }
    }

    private func restartHealthMonitor() {
        healthTask?.cancel()
        healthTask = nil
        consecutiveHealthFailures = 0
        guard settings.autoSwitchEnabled else { return }
        healthTask = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 30_000_000_000) }
                catch { return }
                guard let self else { return }
                await self.runHealthCheck()
            }
        }
    }

    private func restartSubscriptionMonitor() {
        subscriptionTask?.cancel()
        subscriptionTask = nil
        guard hasSavedSubscription else { return }
        subscriptionTask = Task { [weak self] in
            await self?.refreshSubscription(showSuccessNotice: false, onlyWhenDue: true)
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 900_000_000_000) }
                catch { return }
                guard let self else { return }
                await self.refreshSubscription(showSuccessNotice: false, onlyWhenDue: true)
            }
        }
    }

    private func refreshSubscription(showSuccessNotice: Bool, onlyWhenDue: Bool) async {
        guard !isUpdatingSubscription,
              let key = settings.subscriptionURLKey
        else { return }
        if onlyWhenDue,
           let lastUpdate = settings.lastSubscriptionUpdateAt,
           Date().timeIntervalSince(lastUpdate) < TimeInterval(settings.updateIntervalHours * 3600) {
            return
        }

        isUpdatingSubscription = true
        defer { isUpdatingSubscription = false }
        do {
            guard let source = try keychain.value(for: key), !source.isEmpty else {
                throw ImportError.malformed("已保存的订阅地址")
            }
            let resolved = try await importService.resolve(source)
            try await applyImport(resolved, announce: showSuccessNotice)
            if showSuccessNotice { notice = "订阅更新成功" }
        } catch {
            if showSuccessNotice {
                notice = "订阅更新失败，仍在使用上一份配置：\(Redactor.clean(error.localizedDescription))"
            }
        }
    }

    private func runHealthCheck() async {
        guard settings.autoSwitchEnabled,
              settings.routingMode != .direct,
              connectionState == .connected,
              let current = preferredNode
        else {
            consecutiveHealthFailures = 0
            return
        }

        do {
            _ = try await latency.testCurrentTunnel(timeout: 7)
            consecutiveHealthFailures = 0
            return
        } catch {
            consecutiveHealthFailures += 1
        }

        guard consecutiveHealthFailures >= 3 else { return }
        let originalID = current.id
        let candidates = nodes.filter { $0.id != originalID }
        let delays = await measureNodes(candidates)
        guard settings.autoSwitchEnabled,
              connectionState == .connected,
              preferredNode?.id == originalID,
              let replacement = candidates
                .filter({ delays[$0.id] != nil })
                .min(by: { (delays[$0.id] ?? .max) < (delays[$1.id] ?? .max) })
        else { return }
        consecutiveHealthFailures = 0
        await selectNode(replacement)
    }

    private func measureNodes(_ values: [ProxyNode]) async -> [UUID: Int] {
        var results: [UUID: Int] = [:]
        for start in stride(from: 0, to: values.count, by: 4) {
            let end = min(start + 4, values.count)
            let batch = Array(values[start..<end])
            await withTaskGroup(of: (UUID, Int?).self) { group in
                for node in batch {
                    group.addTask { [latency] in
                        (node.id, try? await latency.test(node))
                    }
                }
                for await (id, delay) in group {
                    if let delay { results[id] = delay }
                }
            }
        }
        return results
    }

    private func snapshot() -> StoredConfiguration {
        StoredConfiguration(nodes: nodes, settings: settings, updatedAt: Date())
    }

    private func invalidateNetworkVerification() {
        runtimeGeneration &+= 1
        fallbackRollbackState = nil
        networkVerificationTask?.cancel()
        networkVerificationTask = nil
        tunnelNetworkAvailable = nil
        tunnelNetworkStatus = nil
    }

    private func restartNetworkVerificationIfConnected() {
        guard connectionState == .connected else { return }
        tunnelStateDidChange(.connected)
    }
}
