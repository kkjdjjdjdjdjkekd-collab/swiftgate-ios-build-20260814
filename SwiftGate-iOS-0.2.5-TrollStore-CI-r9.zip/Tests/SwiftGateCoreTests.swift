import XCTest
@testable import SwiftGate

final class SwiftGateCoreTests: XCTestCase {
    func testCompatibleDNSFallbackRunsOnlyOnce() {
        XCTAssertTrue(RuntimeDNSProfile.local.canFallbackToCompatibleDNS)
        XCTAssertFalse(RuntimeDNSProfile.proxiedHTTPS.canFallbackToCompatibleDNS)
    }

    func testGivenVLESSLinkPreservesWebSocketTLSFields() throws {
        let link = "vless://00000000-0000-4000-8000-000000000001@edge.example.com:443?encryption=none&security=tls&sni=edge.example.com&fp=chrome&type=ws&host=edge.example.com&path=%2F#edgetunnel"
        let node = try XCTUnwrap(ShareLinkParser().parse(link).nodes.first)

        XCTAssertEqual(node.name, "edgetunnel")
        XCTAssertEqual(node.type, .vless)
        XCTAssertEqual(node.server, "edge.example.com")
        XCTAssertEqual(node.port, 443)
        XCTAssertEqual(node.transport, "ws")
        XCTAssertEqual(node.path, "/")
        XCTAssertEqual(node.serverName, "edge.example.com")
        XCTAssertEqual(node.host, "edge.example.com")
        XCTAssertEqual(node.query["fp"], "chrome")
    }

    func testDuplicateLinksAreDeduplicated() throws {
        let link = "trojan://password@example.com:443?security=tls#node"
        let result = try ShareLinkParser().parse("\(link)\n\(link)")

        XCTAssertEqual(result.nodes.count, 1)
        XCTAssertEqual(result.duplicateCount, 1)
    }

    func testUnsupportedKCPIsRejectedClearly() {
        XCTAssertThrowsError(
            try ShareLinkParser().parse("vless://00000000-0000-0000-0000-000000000001@example.com:443?type=kcp#node")
        )
    }

    func testVMessMKCPShareIsRejectedWithActionableCoreMessage() throws {
        let link = try vmessLink([
            "v": "2",
            "ps": "legacy-kcp",
            "add": "kcp.example.com",
            "port": "31575",
            "id": "00000000-0000-4000-8000-000000000001",
            "aid": "0",
            "scy": "auto",
            "net": "kcp",
            "type": "none",
            "tls": "",
        ])

        do {
            _ = try ShareLinkParser().parse(link)
            XCTFail("mKCP must not be imported as a false-compatible TCP node")
        } catch let error as ImportError {
            let message = try XCTUnwrap(error.errorDescription)
            XCTAssertTrue(message.contains("mKCP"))
            XCTAssertTrue(message.contains("当前 iOS 内核不支持"))
            XCTAssertTrue(message.contains("TCP、WS 或 VLESS"))
        }
    }

    func testVMessWebSocketShareMapsPinnedCoreFields() throws {
        let link = try vmessLink([
            "v": "2",
            "ps": "vmess-ws",
            "add": "edge.example.com",
            "port": 443,
            "id": "00000000-0000-4000-8000-000000000002",
            "aid": "0",
            "scy": "auto",
            "net": "ws",
            "type": "none",
            "host": "cdn.example.com",
            "path": "/vmess",
            "tls": "tls",
            "sni": "edge.example.com",
            "fp": "chrome",
            "alpn": ["h2", "http/1.1"],
            "packetEncoding": "xudp",
            "globalPadding": true,
            "authenticatedLength": true,
            "network": ["tcp", "udp"],
        ])
        let node = try XCTUnwrap(ShareLinkParser().parse(link).nodes.first)

        XCTAssertEqual(node.type, .vmess)
        XCTAssertEqual(node.transport, "ws")
        XCTAssertEqual(node.host, "cdn.example.com")
        XCTAssertEqual(node.path, "/vmess")
        XCTAssertEqual(node.serverName, "edge.example.com")
        XCTAssertEqual(node.query["scy"], "auto")
        XCTAssertEqual(node.query["aid"], "0")
        XCTAssertEqual(node.query["packet_encoding"], "xudp")
        XCTAssertEqual(node.query["global_padding"], "true")
        XCTAssertEqual(node.query["authenticated_length"], "true")
        XCTAssertEqual(node.query["network"], "tcp,udp")

        let outbound = try vmessOutbound(for: node)
        XCTAssertEqual(outbound["type"] as? String, "vmess")
        XCTAssertEqual(outbound["security"] as? String, "auto")
        XCTAssertEqual(outbound["alter_id"] as? Int, 0)
        XCTAssertEqual(outbound["global_padding"] as? Bool, true)
        XCTAssertEqual(outbound["authenticated_length"] as? Bool, true)
        XCTAssertEqual(outbound["packet_encoding"] as? String, "xudp")
        XCTAssertEqual(outbound["network"] as? [String], ["tcp", "udp"])

        let transport = try XCTUnwrap(outbound["transport"] as? [String: Any])
        XCTAssertEqual(transport["type"] as? String, "ws")
        XCTAssertEqual(transport["path"] as? String, "/vmess")
        let headers = try XCTUnwrap(transport["headers"] as? [String: Any])
        XCTAssertEqual(headers["Host"] as? String, "cdn.example.com")

        let tls = try XCTUnwrap(outbound["tls"] as? [String: Any])
        XCTAssertEqual(tls["server_name"] as? String, "edge.example.com")
        XCTAssertEqual(tls["alpn"] as? [String], ["h2", "http/1.1"])
        let utls = try XCTUnwrap(tls["utls"] as? [String: Any])
        XCTAssertEqual(utls["fingerprint"] as? String, "chrome")
    }

    func testVMessCipherWhitelistMatchesPinnedCore() throws {
        let base: [String: Any] = [
            "v": "2",
            "ps": "cipher-check",
            "add": "cipher.example.com",
            "port": "443",
            "id": "00000000-0000-4000-8000-000000000006",
            "aid": "0",
            "net": "ws",
            "type": "none",
            "path": "/",
            "tls": "tls",
        ]

        var supported = base
        supported["scy"] = "aes-128-ctr"
        let supportedNode = try XCTUnwrap(
            ShareLinkParser().parse(try vmessLink(supported)).nodes.first
        )
        XCTAssertEqual(try vmessOutbound(for: supportedNode)["security"] as? String, "aes-128-ctr")

        var unsupported = base
        unsupported["scy"] = "aes-128-cfb"
        XCTAssertThrowsError(try ShareLinkParser().parse(try vmessLink(unsupported)))
    }

    func testVMessSupportedTransportAliasesAndQUICMapExactly() throws {
        let cases: [(input: String, expected: String)] = [
            ("tcp", "tcp"),
            ("raw", "tcp"),
            ("h2", "http"),
            ("http", "http"),
            ("ws", "ws"),
            ("grpc", "grpc"),
            ("httpupgrade", "httpupgrade"),
            ("quic", "quic"),
        ]

        for item in cases {
            let link = try vmessLink([
                "v": "2",
                "ps": item.input,
                "add": "transport.example.com",
                "port": "443",
                "id": "00000000-0000-4000-8000-000000000003",
                "aid": "0",
                "net": item.input,
                "type": "none",
                "host": item.input == "h2" ? "one.example.com,two.example.com" : "",
                "path": item.input == "grpc"
                    ? "TunService"
                    : (item.input == "quic" ? "" : "/transport"),
                "tls": item.input == "quic" ? "tls" : "",
            ])
            let node = try XCTUnwrap(ShareLinkParser().parse(link).nodes.first)
            XCTAssertEqual(node.transport, item.expected, "input transport: \(item.input)")

            let outbound = try vmessOutbound(for: node)
            if item.expected == "tcp" {
                XCTAssertNil(outbound["transport"], "plain TCP/raw must not emit a V2Ray transport object")
            } else {
                let transport = try XCTUnwrap(outbound["transport"] as? [String: Any])
                XCTAssertEqual(transport["type"] as? String, item.expected)
                if item.input == "h2" {
                    XCTAssertEqual(
                        transport["host"] as? [String],
                        ["one.example.com", "two.example.com"]
                    )
                }
            }
        }
    }

    func testPersistedVMessMKCPNodeStillFailsBeforeCoreStartup() {
        let node = ProxyNode(
            name: "old-kcp",
            type: .vmess,
            server: "kcp.example.com",
            port: 31575,
            credential: "00000000-0000-4000-8000-000000000004",
            transport: "kcp",
            query: ["aid": "0", "scy": "auto"]
        )
        var settings = AppSettings()
        settings.preferredNodeID = node.id

        XCTAssertThrowsError(
            try RuntimeConfigBuilder().build(
                StoredConfiguration(nodes: [node], settings: settings)
            )
        ) { error in
            XCTAssertTrue(error.localizedDescription.contains("mKCP"))
            XCTAssertTrue(error.localizedDescription.contains("当前 iOS 内核不支持"))
        }
    }

    func testClashYAMLImportsCommonVLESSWebSocketNode() throws {
        let yaml = """
        proxies:
          - name: example
            type: vless
            server: edge.example.com
            port: 443
            uuid: 00000000-0000-4000-8000-000000000001
            network: ws
            tls: true
            servername: edge.example.com
            client-fingerprint: chrome
            ws-opts:
              path: /
              headers:
                Host: edge.example.com
        proxy-groups:
          - name: PROXY
            type: select
            proxies: [example]
        """

        let node = try XCTUnwrap(ClashYAMLParser().parse(yaml).nodes.first)
        XCTAssertEqual(node.type, .vless)
        XCTAssertEqual(node.transport, "ws")
        XCTAssertEqual(node.host, "edge.example.com")
        XCTAssertEqual(node.query["fp"], "chrome")
    }

    func testClashYAMLVMessFieldsReachPinnedCoreOutbound() throws {
        let yaml = """
        proxies:
          - name: vmess-yaml
            type: vmess
            server: edge.example.com
            port: 443
            uuid: 00000000-0000-4000-8000-000000000005
            alterId: 0
            cipher: auto
            network: ws
            tls: true
            servername: edge.example.com
            global-padding: true
            authenticated-length: true
            packet-encoding: xudp
            ws-opts:
              path: /yaml
              headers:
                Host: cdn.example.com
        """

        let node = try XCTUnwrap(ClashYAMLParser().parse(yaml).nodes.first)
        let outbound = try vmessOutbound(for: node)

        XCTAssertEqual(outbound["security"] as? String, "auto")
        XCTAssertEqual(outbound["alter_id"] as? Int, 0)
        XCTAssertEqual(outbound["global_padding"] as? Bool, true)
        XCTAssertEqual(outbound["authenticated_length"] as? Bool, true)
        XCTAssertEqual(outbound["packet_encoding"] as? String, "xudp")
        let transport = try XCTUnwrap(outbound["transport"] as? [String: Any])
        XCTAssertEqual(transport["type"] as? String, "ws")
    }

    func testClashYAMLRejectsVMessMKCPBeforeSaving() {
        let yaml = """
        proxies:
          - name: legacy-kcp
            type: vmess
            server: kcp.example.com
            port: 31575
            uuid: 00000000-0000-4000-8000-000000000007
            alterId: 0
            cipher: auto
            network: kcp
        """

        XCTAssertThrowsError(try ClashYAMLParser().parse(yaml)) { error in
            XCTAssertTrue(error.localizedDescription.contains("mKCP"))
            XCTAssertTrue(error.localizedDescription.contains("当前 iOS 内核不支持"))
        }
    }

    func testRuntimeUsesSelectedNodeAndPrivateNetworkBypass() throws {
        let node = ProxyNode(
            name: "test",
            type: .vless,
            server: "example.com",
            port: 443,
            credential: "00000000-0000-0000-0000-000000000001",
            transport: "ws",
            tls: true,
            path: "/"
        )
        var settings = AppSettings()
        settings.preferredNodeID = node.id
        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [node], settings: settings)
        )

        XCTAssertTrue(runtime.contains("\"type\":\"tun\""))
        XCTAssertTrue(runtime.contains("\"ip_is_private\":true"))
        XCTAssertTrue(runtime.contains("\"auto_detect_interface\":true"))
        XCTAssertTrue(runtime.contains("\"default_domain_resolver\""))
        XCTAssertTrue(runtime.contains("\"server\":\"bootstrap\""))
        XCTAssertTrue(runtime.contains("\"strategy\":\"ipv4_only\""))
        XCTAssertTrue(runtime.contains("\"mtu\":1400"))
        XCTAssertFalse(runtime.contains("172.16.0.0/12"))
        XCTAssertFalse(runtime.contains("fc00::/7"))
        XCTAssertTrue(runtime.contains("\"action\":\"hijack-dns\""))
        XCTAssertTrue(runtime.contains("\"action\":\"sniff\""))
        XCTAssertLessThan(
            try XCTUnwrap(runtime.range(of: "\"action\":\"sniff\"")).lowerBound,
            try XCTUnwrap(runtime.range(of: "\"action\":\"hijack-dns\"")).lowerBound
        )
    }

    func testDirectModeCanStartWithoutAnyProxyNode() throws {
        var settings = AppSettings()
        settings.routingMode = .direct
        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [], settings: settings)
        )

        XCTAssertTrue(runtime.contains("\"final\":\"direct\""))
        XCTAssertTrue(runtime.contains("\"hijack-dns\""))
    }

    func testGlobalModeStillBypassesPrivateNetworks() throws {
        let node = ProxyNode(
            name: "global",
            type: .trojan,
            server: "global.example.com",
            port: 443,
            credential: "secret",
            tls: true
        )
        var settings = AppSettings()
        settings.routingMode = .global
        settings.preferredNodeID = node.id

        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [node], settings: settings)
        )

        XCTAssertTrue(runtime.contains("\"ip_is_private\":true"))
        XCTAssertTrue(runtime.contains("\"outbound\":\"direct\""))
        XCTAssertTrue(runtime.contains("\"final\":\"node-"))
    }

    func testRuntimeOnlyIncludesSelectedNodeAndNoRemovedBlockOutbound() throws {
        let selected = ProxyNode(
            name: "selected",
            type: .vless,
            server: "selected.example.com",
            port: 443,
            credential: "00000000-0000-4000-8000-000000000001",
            transport: "ws",
            tls: true,
            path: "/"
        )
        let unused = ProxyNode(
            name: "unused",
            type: .trojan,
            server: "unused.example.com",
            port: 443,
            credential: "secret",
            tls: true
        )
        var settings = AppSettings()
        settings.preferredNodeID = selected.id

        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [selected, unused], settings: settings)
        )

        XCTAssertTrue(runtime.contains("selected.example.com"))
        XCTAssertFalse(runtime.contains("unused.example.com"))
        XCTAssertFalse(runtime.contains("\"type\":\"block\""))
        XCTAssertTrue(runtime.contains("\"cache_capacity\":4096"))
    }

    func testRuntimePreservesUserRequestedFastTransportOptions() throws {
        let node = ProxyNode(
            name: "tuic",
            type: .tuic,
            server: "tuic.example.com",
            port: 443,
            credential: "00000000-0000-4000-8000-000000000001",
            tls: true,
            query: [
                "password": "secret",
                "congestion_control": "bbr",
                "udp_relay_mode": "native",
                "heartbeat": "10s",
                "alpn": "h3",
            ]
        )
        var settings = AppSettings()
        settings.preferredNodeID = node.id

        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [node], settings: settings)
        )

        XCTAssertTrue(runtime.contains("\"congestion_control\":\"bbr\""))
        XCTAssertTrue(runtime.contains("\"udp_relay_mode\":\"native\""))
        XCTAssertTrue(runtime.contains("\"heartbeat\":\"10s\""))
        XCTAssertTrue(runtime.contains("\"alpn\":[\"h3\"]"))
    }

    func testTunnelPayloadRoundTrip() throws {
        let payload = try TunnelPayloadCodec.encode(runtimeConfiguration: "{\"test\":true}")
        let decoded = try TunnelPayloadCodec.decode(payload)

        XCTAssertEqual(decoded["configContent"] as? String, "{\"test\":true}")
    }

    func testRedactorRemovesCredentials() {
        let unsafe = """
        vless://00000000-0000-4000-8000-000000000001@example.com:443?token=secret
        https://subscription.example.com/api/list?token=query-secret&user=alice
        https://alice:authority-secret@example.com/status
        Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.payload.signature
        password=plain-secret api_key='api-secret'
        {"server":"private.example.com","uuid":"00000000-0000-4000-8000-000000000002"}
        """
        let safe = Redactor.clean(unsafe)

        XCTAssertFalse(safe.contains("00000000-0000-4000-8000-000000000001"))
        XCTAssertFalse(safe.contains("00000000-0000-4000-8000-000000000002"))
        XCTAssertFalse(safe.contains("query-secret"))
        XCTAssertFalse(safe.contains("authority-secret"))
        XCTAssertFalse(safe.contains("eyJhbGciOiJIUzI1NiJ9"))
        XCTAssertFalse(safe.contains("plain-secret"))
        XCTAssertFalse(safe.contains("api-secret"))
        XCTAssertFalse(safe.contains("private.example.com"))
    }

    func testFailureMessageIncludesErrorIdentityAndRedactsUnderlyingError() {
        let underlying = NSError(
            domain: "Libbox.Start",
            code: 23,
            userInfo: [
                NSLocalizedDescriptionKey:
                    "invalid vless://00000000-0000-4000-8000-000000000001@example.com:443?token=secret",
            ]
        )
        let error = NSError(
            domain: "NEPacketTunnelProvider",
            code: 5,
            userInfo: [
                NSLocalizedDescriptionKey: "provider failed",
                NSUnderlyingErrorKey: underlying,
            ]
        )

        let message = SensitiveTextRedactor.failureMessage(error)

        XCTAssertTrue(message.contains("NEPacketTunnelProvider:5"))
        XCTAssertTrue(message.contains("Libbox.Start:23"))
        XCTAssertFalse(message.contains("00000000-0000-4000-8000-000000000001"))
        XCTAssertFalse(message.contains("token=secret"))
    }

    private func vmessLink(_ object: [String: Any]) throws -> String {
        let data = try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
        return "vmess://\(data.base64EncodedString())"
    }

    private func vmessOutbound(for node: ProxyNode) throws -> [String: Any] {
        var settings = AppSettings()
        settings.preferredNodeID = node.id
        let runtime = try RuntimeConfigBuilder().build(
            StoredConfiguration(nodes: [node], settings: settings)
        )
        let data = try XCTUnwrap(runtime.data(using: .utf8))
        let root = try XCTUnwrap(
            try JSONSerialization.jsonObject(with: data) as? [String: Any]
        )
        let outbounds = try XCTUnwrap(root["outbounds"] as? [[String: Any]])
        return try XCTUnwrap(outbounds.first(where: { ($0["type"] as? String) == "vmess" }))
    }
}
