import Foundation
import Network
import XCTest
@testable import SwiftGate

/// Regression contracts for the most damaging tunnel failure mode: NetworkExtension
/// reports "connected", but no packet can reach the Internet.
final class RuntimeNetworkContractTests: XCTestCase {
    func testCIDRGuardRecognizesOverlappingTunnelRanges() throws {
        XCTAssertTrue(
            try validNetwork("172.19.0.1/30").overlaps(validNetwork("172.16.0.0/12"))
        )
        XCTAssertTrue(
            try validNetwork("fdfe:dcba:9876::1/126").overlaps(validNetwork("fc00::/7"))
        )
        XCTAssertFalse(
            try validNetwork("172.19.0.1/30").overlaps(validNetwork("192.168.0.0/16"))
        )
        XCTAssertFalse(
            try validNetwork("fdfe:dcba:9876::1/126").overlaps(validNetwork("fe80::/10"))
        )
    }

    func testTUNAddressesAreNeverCoveredByAnExcludedRoute() throws {
        let root = try runtimeRootForUserVLESSFixture()
        let tun = try tunInbound(in: root)

        XCTAssertEqual(tun["auto_route"] as? Bool, true)
        XCTAssertEqual(tun["strict_route"] as? Bool, false)
        XCTAssertEqual(tun["stack"] as? String, "system")
        XCTAssertEqual(tun["mtu"] as? Int, 1400)
        XCTAssertEqual(
            tun["address"] as? [String],
            ["172.19.0.1/30", "fdfe:dcba:9876::1/126"]
        )
        XCTAssertNil(tun["route_exclude_address"])

        let addresses = try XCTUnwrap(tun["address"] as? [String])
        let exclusions = (tun["route_exclude_address"] as? [String]) ?? []
        XCTAssertFalse(addresses.isEmpty, "TUN must have at least one interface address")

        let tunNetworks = try addresses.map(validNetwork)
        let excludedNetworks = try exclusions.map(validNetwork)
        for address in tunNetworks {
            for excluded in excludedNetworks where address.bytes.count == excluded.bytes.count {
                XCTAssertFalse(
                    address.overlaps(excluded),
                    "TUN address \(address.source) is swallowed by route exclusion \(excluded.source)"
                )
            }
        }
    }

    func testDNSHijackAndResolverReferencesFormACompleteChain() throws {
        let root = try runtimeRootForUserVLESSFixture()
        let tun = try tunInbound(in: root)
        let dns = try XCTUnwrap(root["dns"] as? JSONObject)
        let route = try XCTUnwrap(root["route"] as? JSONObject)

        // The pinned 1.14-era Apple core can install native per-interface DNS. Keep this
        // explicit so an apparently connected tunnel cannot silently inherit unusable DNS.
        XCTAssertEqual(tun["dns_mode"] as? String, "hijack")
        let dnsAddresses = try XCTUnwrap(tun["dns_address"] as? [String])
        XCTAssertFalse(dnsAddresses.isEmpty)

        let tunNetworks = try XCTUnwrap(tun["address"] as? [String]).map(validNetwork)
        let excludedNetworks = try ((tun["route_exclude_address"] as? [String]) ?? []).map(validNetwork)
        let parsedDNSAddresses = try dnsAddresses.map(validNetwork)
        for tunNetwork in tunNetworks {
            XCTAssertTrue(
                parsedDNSAddresses.contains(where: { tunNetwork.contains($0) }),
                "Every configured TUN address family needs an in-subnet DNS endpoint"
            )
        }
        for dnsAddress in parsedDNSAddresses {
            XCTAssertTrue(
                tunNetworks.contains(where: { $0.contains(dnsAddress) }),
                "DNS address \(dnsAddress.source) must be reachable inside a TUN subnet"
            )
            XCTAssertFalse(
                tunNetworks.contains(where: { $0.bytes == dnsAddress.bytes }),
                "DNS endpoint \(dnsAddress.source) must not reuse the TUN interface address"
            )
            XCTAssertFalse(
                excludedNetworks.contains(where: { $0.contains(dnsAddress) }),
                "DNS address \(dnsAddress.source) must not be excluded from the tunnel"
            )
        }

        let servers = try XCTUnwrap(dns["servers"] as? [JSONObject])
        let serverTags = Set(servers.compactMap { $0["tag"] as? String })
        XCTAssertFalse(servers.isEmpty)
        XCTAssertEqual(serverTags.count, servers.count, "Every DNS server needs a unique tag")

        let dnsFinal = try XCTUnwrap(dns["final"] as? String)
        XCTAssertTrue(serverTags.contains(dnsFinal), "dns.final must name a configured DNS server")

        let resolver = try XCTUnwrap(route["default_domain_resolver"] as? JSONObject)
        let resolverServer = try XCTUnwrap(resolver["server"] as? String)
        XCTAssertTrue(
            serverTags.contains(resolverServer),
            "route.default_domain_resolver.server must name a configured DNS server"
        )
        XCTAssertEqual(resolver["strategy"] as? String, "ipv4_only")

        XCTAssertEqual(dns["strategy"] as? String, "ipv4_only")
        XCTAssertEqual(dnsFinal, "bootstrap")
        XCTAssertEqual(servers.count, 1)
        XCTAssertEqual(servers.first?["type"] as? String, "local")

        let rules = try XCTUnwrap(route["rules"] as? [JSONObject])
        let sniffIndex = rules.firstIndex(where: { rule in
            (rule["action"] as? String) == "sniff"
        })
        let dnsHijackIndex = rules.firstIndex(where: { rule in
            (rule["action"] as? String) == "hijack-dns" && protocolIncludesDNS(rule["protocol"])
        })
        let privateRouteIndex = rules.firstIndex(where: { rule in
            (rule["ip_is_private"] as? Bool) == true
                && (rule["action"] as? String) == "route"
                && (rule["outbound"] as? String) == "direct"
        })
        XCTAssertEqual(sniffIndex, rules.indices.first)
        XCTAssertEqual(dnsHijackIndex, rules.index(after: rules.startIndex))
        XCTAssertLessThan(
            try XCTUnwrap(sniffIndex),
            try XCTUnwrap(dnsHijackIndex),
            "DNS must be sniffed before protocol=dns can match and hijack the flow"
        )
        XCTAssertLessThan(
            try XCTUnwrap(dnsHijackIndex),
            try XCTUnwrap(privateRouteIndex),
            "Synthetic TUN DNS must be hijacked before private-address routing can send it DIRECT"
        )
    }

    func testProxiedHTTPSDNSFallbackUsesTheSelectedEgress() throws {
        let root = try runtimeRootForUserVLESSFixture(dnsProfile: .proxiedHTTPS)
        let dns = try XCTUnwrap(root["dns"] as? JSONObject)
        let servers = try XCTUnwrap(dns["servers"] as? [JSONObject])
        XCTAssertEqual(dns["final"] as? String, "remote")

        let remote = try XCTUnwrap(servers.first(where: { ($0["tag"] as? String) == "remote" }))
        XCTAssertEqual(remote["type"] as? String, "https")
        XCTAssertEqual(remote["server"] as? String, "1.1.1.1")
        XCTAssertEqual(remote["server_port"] as? Int, 443)
        XCTAssertEqual(remote["path"] as? String, "/dns-query")
        let remoteTLS = try XCTUnwrap(remote["tls"] as? JSONObject)
        XCTAssertEqual(remoteTLS["enabled"] as? Bool, true)
        XCTAssertEqual(remoteTLS["server_name"] as? String, "cloudflare-dns.com")

        let route = try XCTUnwrap(root["route"] as? JSONObject)
        XCTAssertEqual(remote["detour"] as? String, route["final"] as? String)
    }

    func testDNSFallbackRollbackReconstructsTheOriginalRuntimeExactly() throws {
        let link = try fixtureText(named: "vless-ws-tls-user-link.txt")
        let node = try XCTUnwrap(ShareLinkParser().parse(link).nodes.first)
        var settings = AppSettings()
        settings.preferredNodeID = node.id
        let configuration = StoredConfiguration(nodes: [node], settings: settings)
        let builder = RuntimeConfigBuilder()

        let originalRuntime = try builder.build(configuration, dnsProfile: .local)
        let fallbackRuntime = try builder.build(configuration, dnsProfile: .proxiedHTTPS)
        let rolledBackRuntime = try builder.build(configuration, dnsProfile: .local)

        XCTAssertNotEqual(fallbackRuntime, originalRuntime)
        XCTAssertEqual(rolledBackRuntime, originalRuntime)

        let rolledBackRoot = try runtimeRoot(configuration, dnsProfile: .local)
        let dns = try XCTUnwrap(rolledBackRoot["dns"] as? JSONObject)
        XCTAssertEqual(dns["final"] as? String, "bootstrap")
        XCTAssertEqual((dns["servers"] as? [JSONObject])?.count, 1)
    }

    func testUserVLESSWebSocketTLSFixtureBuildsAnExactUsableOutbound() throws {
        let link = try fixtureText(named: "vless-ws-tls-user-link.txt")
        let expected = try fixtureJSONObject(named: "vless-ws-tls-expected.json")
        let node = try XCTUnwrap(ShareLinkParser().parse(link).nodes.first)

        XCTAssertEqual(node.name, expected["name"] as? String)
        XCTAssertEqual(node.type.rawValue, expected["type"] as? String)
        XCTAssertEqual(node.server, expected["server"] as? String)
        XCTAssertEqual(Int(node.port), expected["server_port"] as? Int)
        XCTAssertEqual(node.credential, expected["uuid"] as? String)
        XCTAssertEqual(node.transport, expected["transport"] as? String)
        XCTAssertEqual(node.path, expected["path"] as? String)
        XCTAssertEqual(node.serverName, expected["tls_server_name"] as? String)
        XCTAssertEqual(node.host, expected["host"] as? String)
        XCTAssertEqual(node.query["security"], "tls")
        XCTAssertEqual(node.query["encryption"], "none")
        XCTAssertEqual(node.query["fp"], expected["fingerprint"] as? String)
        XCTAssertTrue(node.tls)

        var settings = AppSettings()
        settings.preferredNodeID = node.id
        let root = try runtimeRoot(
            StoredConfiguration(nodes: [node], settings: settings)
        )
        let outbounds = try XCTUnwrap(root["outbounds"] as? [JSONObject])
        let outbound = try XCTUnwrap(outbounds.first(where: { ($0["type"] as? String) == "vless" }))
        let tls = try XCTUnwrap(outbound["tls"] as? JSONObject)
        let utls = try XCTUnwrap(tls["utls"] as? JSONObject)
        let transport = try XCTUnwrap(outbound["transport"] as? JSONObject)
        let headers = try XCTUnwrap(transport["headers"] as? JSONObject)

        XCTAssertEqual(outbound["server"] as? String, expected["server"] as? String)
        XCTAssertEqual(outbound["server_port"] as? Int, expected["server_port"] as? Int)
        XCTAssertEqual(outbound["uuid"] as? String, expected["uuid"] as? String)
        XCTAssertEqual(tls["enabled"] as? Bool, true)
        XCTAssertEqual(tls["server_name"] as? String, expected["tls_server_name"] as? String)
        XCTAssertEqual(utls["enabled"] as? Bool, true)
        XCTAssertEqual(utls["fingerprint"] as? String, expected["fingerprint"] as? String)
        XCTAssertEqual(transport["type"] as? String, expected["transport"] as? String)
        XCTAssertEqual(transport["path"] as? String, expected["path"] as? String)
        XCTAssertEqual(headers["Host"] as? String, expected["host"] as? String)

        let selectedTag = try XCTUnwrap(outbound["tag"] as? String)
        let route = try XCTUnwrap(root["route"] as? JSONObject)
        XCTAssertEqual(route["final"] as? String, selectedTag)
    }

    func testDirectModeDNSNeverReferencesAnOmittedProxyOutbound() throws {
        let link = try fixtureText(named: "vless-ws-tls-user-link.txt")
        let node = try XCTUnwrap(ShareLinkParser().parse(link).nodes.first)
        var settings = AppSettings()
        settings.preferredNodeID = node.id
        settings.routingMode = .direct

        let root = try runtimeRoot(
            StoredConfiguration(nodes: [node], settings: settings),
            dnsProfile: .proxiedHTTPS
        )
        let outbounds = try XCTUnwrap(root["outbounds"] as? [JSONObject])
        XCTAssertEqual(outbounds.compactMap { $0["tag"] as? String }, ["direct"])

        let route = try XCTUnwrap(root["route"] as? JSONObject)
        XCTAssertEqual(route["final"] as? String, "direct")

        let dns = try XCTUnwrap(root["dns"] as? JSONObject)
        let servers = try XCTUnwrap(dns["servers"] as? [JSONObject])
        let remote = try XCTUnwrap(servers.first(where: { ($0["tag"] as? String) == "remote" }))
        XCTAssertEqual(remote["detour"] as? String, "direct")
    }
}

private typealias JSONObject = [String: Any]

private func runtimeRootForUserVLESSFixture(
    dnsProfile: RuntimeDNSProfile = .local
) throws -> JSONObject {
    let link = try fixtureText(named: "vless-ws-tls-user-link.txt")
    let node = try XCTUnwrap(ShareLinkParser().parse(link).nodes.first)
    var settings = AppSettings()
    settings.preferredNodeID = node.id
    return try runtimeRoot(
        StoredConfiguration(nodes: [node], settings: settings),
        dnsProfile: dnsProfile
    )
}

private func runtimeRoot(
    _ configuration: StoredConfiguration,
    dnsProfile: RuntimeDNSProfile = .local
) throws -> JSONObject {
    let runtime = try RuntimeConfigBuilder().build(configuration, dnsProfile: dnsProfile)
    let data = try XCTUnwrap(runtime.data(using: .utf8))
    return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? JSONObject)
}

private func tunInbound(in root: JSONObject) throws -> JSONObject {
    let inbounds = try XCTUnwrap(root["inbounds"] as? [JSONObject])
    return try XCTUnwrap(inbounds.first(where: { ($0["type"] as? String) == "tun" }))
}

private func fixtureText(named name: String) throws -> String {
    let url = URL(fileURLWithPath: #filePath)
        .deletingLastPathComponent()
        .appendingPathComponent("Fixtures", isDirectory: true)
        .appendingPathComponent(name)
    return try String(contentsOf: url, encoding: .utf8)
        .trimmingCharacters(in: .whitespacesAndNewlines)
}

private func fixtureJSONObject(named name: String) throws -> JSONObject {
    let text = try fixtureText(named: name)
    let data = try XCTUnwrap(text.data(using: .utf8))
    return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? JSONObject)
}

private func protocolIncludesDNS(_ value: Any?) -> Bool {
    if let value = value as? String { return value == "dns" }
    if let value = value as? [String] { return value.contains("dns") }
    return false
}

private func validNetwork(_ source: String) throws -> IPNetwork {
    try XCTUnwrap(IPNetwork(source), "Invalid IP or CIDR in runtime configuration: \(source)")
}

private struct IPNetwork {
    let source: String
    let bytes: [UInt8]
    let prefixLength: Int

    init?(_ source: String) {
        let components = source.split(separator: "/", maxSplits: 1, omittingEmptySubsequences: false)
        guard let host = components.first.map(String.init) else { return nil }

        if let address = IPv4Address(host) {
            bytes = Array(address.rawValue)
        } else if let address = IPv6Address(host) {
            bytes = Array(address.rawValue)
        } else {
            return nil
        }

        let maximumPrefix = bytes.count * 8
        if components.count == 2 {
            guard let parsedPrefix = Int(components[1]), (0...maximumPrefix).contains(parsedPrefix) else {
                return nil
            }
            prefixLength = parsedPrefix
        } else {
            prefixLength = maximumPrefix
        }
        self.source = source
    }

    func contains(_ other: IPNetwork) -> Bool {
        guard bytes.count == other.bytes.count else { return false }
        return matchesPrefix(of: other, bitCount: prefixLength)
    }

    func overlaps(_ other: IPNetwork) -> Bool {
        guard bytes.count == other.bytes.count else { return false }
        return matchesPrefix(of: other, bitCount: min(prefixLength, other.prefixLength))
    }

    private func matchesPrefix(of other: IPNetwork, bitCount: Int) -> Bool {
        let wholeBytes = bitCount / 8
        if bytes.prefix(wholeBytes) != other.bytes.prefix(wholeBytes) { return false }

        let remainingBits = bitCount % 8
        guard remainingBits > 0 else { return true }
        let mask = UInt8.max << (8 - remainingBits)
        return (bytes[wholeBytes] & mask) == (other.bytes[wholeBytes] & mask)
    }
}
